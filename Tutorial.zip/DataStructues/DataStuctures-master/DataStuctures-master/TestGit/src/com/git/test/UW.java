package com.git.test;

public class UW {
	public static void main(String[] args) {
		System.out.println("In UW");
		
		
		System.out.println("Fixing IE11 issues...");
	}
	void tableRefChange(){
		System.out.println("tableRefChange1111");
	}
}
