package com.jrk.ds.set;

public class DisjointSet implements Set{

	@Override
	public void makeSet(int size) {
		
	}

	@Override
	public int find(int x) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void union(int root1, int root2) {
		// TODO Auto-generated method stub
		
	}
	
}
