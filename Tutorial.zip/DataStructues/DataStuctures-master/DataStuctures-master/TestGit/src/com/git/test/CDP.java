package com.git.test;

public class CDP {
	public static void main(String[] args) {
		System.out.println("In CDP");
	}
	void poc(){
		System.out.println("Started POC");
		System.out.println("Completed POC");
	}
	void tableRefChange(){
		System.out.println("tableRefChange111");
	}
}
