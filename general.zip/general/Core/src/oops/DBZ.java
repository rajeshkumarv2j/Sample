package oops;

public class DBZ {

	public void test(Number d) {
		System.out.println("Double...");
	}
}

class DBZ1 extends DBZ {

	public void test(Number d) {
		super.test(d);
	}

}
