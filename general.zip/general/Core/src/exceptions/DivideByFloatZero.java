package exceptions;
class DivideByFloatZero {
	public static void main(String args[]) {
		System.out.println(0 / 0);
	}
}

class B {
	public static void main(String args[]) {
		System.out.println(0 / 0.0);
	}
}