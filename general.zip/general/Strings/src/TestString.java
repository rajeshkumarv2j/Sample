import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Map;

public class TestString {

	private static final int N = 10;

	public static void test1() {
		String s1 = "Test";
		String s2 = "Test";
		String s3 = new String("Test");
		final String s4 = s3.intern();
		System.out.println(s1 == s2);// true
		System.out.println(s2 == s3);// false
		System.out.println(s3 == s4);// false
		System.out.println(s1 == s3);// false
		System.out.println(s1 == s4);// true
		System.out.println(s1.equals(s2));// true
		System.out.println(s2.equals(s3));// true
		System.out.println(s3.equals(s4));// true
		System.out.println(s1.equals(s4));// true
		System.out.println(s1.equals(s3));// true
	}

	public static void test2() {
		String s1 = "Hello";
		String s2 = s1;
		String s3 = new String("Hello");
		String s4 = "lo";

		System.out.println(s1 == "Hello"); // true
		System.out.println(s1 == s2); // true
		System.out.println(s1 == s3); // false

		// Strings computed by concatenation at
		// run-time are newly created and therefore distinct.
		System.out.println("Hello" == "Hel" + s4); // flase

		// s3 is not literal, so distinct
		System.out.println(s3 == ("Hel" + s4).intern()); // false

		// The result of explicitly interning a computed string is the same
		// string as any pre-existing literal string with the same contents.
		System.out.println(s1 == s3.intern()); // true
		System.out.println("Hello" == ("Hel" + s4).intern()); // true
		System.out.println(s1 == ("Hel" + s4).intern()); // true
		System.out.println(s3.intern() == ("Hel" + s4).intern()); // true
	}

	public static void mytest() {
		String s = "rajesh";
		String s1 = new String("rajesh");
		String s2 = new String("rajesh");
		System.out.println(s1 == s2);

		String s3 = new String("rajesh").intern();
		String s4 = new String("rajesh").intern();
		System.out.println(s3 == s4);

		String s5 = new String("rajesh1").intern();
		String s6 = new String("rajesh1").intern();
		System.out.println(s5 == s6);
	}

	public static void main(String[] args) {
		System.out.println("Hello World!");
		http: // Phi.Lho.free.fr
		System.out.println("Hi");
		
		ArrayList<Void> arrayList = new ArrayList<Void>();
		arrayList.add(new Object());
		
		
	}
	
	public static void main1(String[] args) {
		mytest();
		namesBlocks();
		// doSomething();
	}

	public static <A, B extends Collection<A> & Comparable<B>> boolean foo(
			B b1, B b2, A a) {
		return (b1.compareTo(b2) == 0) || b1.contains(a) || b2.contains(a);
	}

	static void namesBlocks() {

		getmeout: {
			Loop1: for (int i = 0; i < N; ++i) {
				Loop2: for (int j = i; j < N; ++j) {
					Loop3: for (int k = j; k < N; ++k) {
						break getmeout;
					}
				}
			}
		}

	}

	class Test {
		{

		}

		public Test() {
			L1: {

			}
		}
	}

	public static int doSomething() {
		int i = 0;
		try {
			i = 8 / 0;
			// do something
			throw new RuntimeException();
		} finally {
			return i;
		}
	}

	void method() {
		Map<String, Integer> s = Collections.<String, Integer> emptyMap();
	}

	public class ContainerClass {
		boolean sortAscending;

		public Comparator createComparator(final boolean sortAscending) {
			Comparator comparator = new Comparator<Integer>() {

				public int compare(Integer o1, Integer o2) {
					if (sortAscending || ContainerClass.this.sortAscending) {
						return o1 - o2;
					} else {
						return o2 - o1;
					}
				}

			};
			return comparator;
		}
	}
	
}