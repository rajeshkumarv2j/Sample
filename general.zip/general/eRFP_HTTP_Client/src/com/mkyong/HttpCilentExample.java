package com.mkyong;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.CookieHandler;
import java.net.CookieManager;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicNameValuePair;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class HttpCilentExample {

	private String cookies;
	private HttpClient client = HttpClientBuilder.create().build();
	private final String USER_AGENT = "Mozilla/5.0";

	public static void main(String[] args) throws Exception {
			
		String postUrl = "http://192.168.73.128:9080/erfp/signatureTransaction.do";
//		String getUrl = "http://192.168.73.128:9080/erfp/closedDealPackage.do?action=view";
		String jSession ="JSESSIONID=0000iHbkJoWkqJuuLyCNLKyixn4:-1";
		HttpCilentExample http = new HttpCilentExample();
		// make sure cookies is turn on
		CookieHandler.setDefault(new CookieManager());
		http.setCookies(jSession);
//		String referer = "http://192.168.73.128:9080/erfp/searchRfp.do?action=selectRfpId&rfpId=163474";
//		String page = http.GetPageContent(getUrl, jSession);

		List<NameValuePair> postParams = new ArrayList<NameValuePair>();//http.getFormParams(page);

		http.sendPost(postUrl, postParams, jSession);

//		String result = http.GetPageContent(gmail);
//		System.out.println(result);

		System.out.println("Done");
	}

	private void sendPost(String url, List<NameValuePair> postParams, String session)
			throws Exception {

		HttpPost post = new HttpPost(url);

		fillCreateTransactionFormData(postParams);
		
		// add header
		post.setHeader("Host", "accounts.google.com");
		post.setHeader("User-Agent", USER_AGENT);
		post.setHeader("Accept",
				"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
		post.setHeader("Accept-Language", "en-US,en;q=0.5");
		post.setHeader("Cookie", session);
		post.setHeader("Connection", "keep-alive");
		post.setHeader("Content-Type", "application/x-www-form-urlencoded");
//		post.setHeader("sigAction","createTransaction");
		
		
		post.setEntity(new UrlEncodedFormEntity(postParams));

		HttpResponse response = client.execute(post);

		int responseCode = response.getStatusLine().getStatusCode();

		System.out.println("\nSending 'POST' request to URL : " + url);
		System.out.println("Post parameters : " + postParams);
		System.out.println("Response Code : " + responseCode);

		BufferedReader rd = new BufferedReader(new InputStreamReader(response
				.getEntity().getContent()));

		StringBuffer result = new StringBuffer();
		String line = "";
		while ((line = rd.readLine()) != null) {
			result.append(line);
		}

		 System.out.println(result.toString());

	}

	private void fillCreateTransactionFormData(List<NameValuePair> postParams) {
		postParams.add(new BasicNameValuePair("signatureTransactionVo.signatureTransaction.name", "test"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.signatureTransaction.description","test"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[1].selected", "Y"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[0].emailAddress","RajeshKumar.Velishoju@ADP.com"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[0].orgName","Municipal Art Sociey"));
		postParams.add(new BasicNameValuePair("sigAction", "createTransaction"));
		
		postParams.add(new BasicNameValuePair("signatureTransactionVo.loggedInUserEmail","mallesh.bellapu@ADP.com"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[0].docType", "201"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[0].formName","Client Services Agreement"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[0].signatureTemplateID","7"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[0].documentCat", "R"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[0].cbeVersion", ""));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[0].sortOrder", "10"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[1].docType", "203"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[1].formName","Pricing Addendum"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[1].signatureTemplateID","7"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[1].documentCat", "R"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[1].cbeVersion", ""));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[1].sortOrder", "30"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[2].docType", "305"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[2].formName",	"ALE Acknowledgment & Election Form"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[2].signatureTemplateID","9"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[2].documentCat", "R"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[2].cbeVersion", ""));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[2].sortOrder", "31"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[3].docType", "308"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[3].formName","TALX Signature Form"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[3].signatureTemplateID",				"9"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[3].documentCat", "R"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[3].cbeVersion", ""));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[3].sortOrder", "34"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[4].docType", "202"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[4].formName",				"Prospect Acknowledgement"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[4].signatureTemplateID",				"7"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[4].documentCat", "R"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[4].cbeVersion", ""));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[4].sortOrder", "40"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[5].docType", "220"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[5].formName",				"Self Employed Individual Addendum"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[5].signatureTemplateID",				"9"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[5].documentCat","R"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[5].cbeVersion",""));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[5].sortOrder","60"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[6].docType","258"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[6].formName","Benefit Card Processing Delay Addendum"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[6].signatureTemplateID","7"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[6].documentCat","R"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[6].cbeVersion",""));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[6].sortOrder","80"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[7].docType","259"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[7].formName","TotalSource Select Addendum"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[7].signatureTemplateID","7"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[7].documentCat","R"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[7].cbeVersion",""));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[7].sortOrder","90"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[8].docType","260"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[8].formName","CA-RME Contractor Addendum"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[8].signatureTemplateID","7"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[8].documentCat","R"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[8].cbeVersion",""));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[8].sortOrder","100"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[9].docType","254"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[9].formName","Bonus Payroll Processing Addendum"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[9].signatureTemplateID","7"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[9].documentCat","R"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[9].cbeVersion",""));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[9].sortOrder","110"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[10].docType","206"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[10].formName","Client Benefit Election Form"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[10].signatureTemplateID","7"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[10].documentCat","R"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[10].cbeVersion",""));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.requiredDocs[10].sortOrder","20"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.setUpDocs[0].docType","223"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.setUpDocs[0].formName","Authorization to Debit with Voided Check"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.setUpDocs[0].signatureTemplateID","9"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.setUpDocs[0].documentCat","S"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.setUpDocs[0].sortOrder","10"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.setUpDocs[1].docType","237"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.setUpDocs[1].formName","Signed Proposal Authorization for Existing ADP Clients"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.setUpDocs[1].signatureTemplateID","9"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.setUpDocs[1].documentCat","S"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.setUpDocs[1].sortOrder","50"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.k401Docs[0].docType","229"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.k401Docs[0].formName","TS MEP Adoption Agreement"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.k401Docs[0].signatureTemplateID","8"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.k401Docs[0].documentCat","F"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.k401Docs[0].sortOrder","10"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.k401Docs[1].docType","231"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.k401Docs[1].formName","MEP 401(k) Setup Form"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.k401Docs[1].signatureTemplateID","8"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.k401Docs[1].documentCat","F"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.k401Docs[1].sortOrder","30"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.k401Docs[2].docType","233"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.k401Docs[2].formName","Client Own Plan 401k Worksheet (due at Conversion Meeting)"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.k401Docs[2].signatureTemplateID","9"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.k401Docs[2].documentCat","F"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.k401Docs[2].sortOrder","50"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.poaDocs[0].docType","277"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.poaDocs[0].formName","Power of Attorney (AK) (Corporate Seal & Witness)"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.poaDocs[0].signatureTemplateID","10"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.poaDocs[0].documentCat","P"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.poaDocs[0].sortOrder","110"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.poaDocs[1].docType","264"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.poaDocs[1].formName","Power of Attorney (CA) (Officers List)"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.poaDocs[1].signatureTemplateID","9"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.poaDocs[1].documentCat","P"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.poaDocs[1].sortOrder","112"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.poaDocs[2].docType","278"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.poaDocs[2].formName","Power of Attorney (CT) (Witness)"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.poaDocs[2].signatureTemplateID","12"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.poaDocs[2].documentCat","P"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.poaDocs[2].sortOrder","114"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.poaDocs[3].docType","283"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.poaDocs[3].formName","Power of Attorney (LA) (Witness)"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.poaDocs[3].signatureTemplateID","12"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.poaDocs[3].documentCat","P"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.poaDocs[3].sortOrder","121"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.poaDocs[4].docType","288"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.poaDocs[4].formName","Power of Attorney (SC) (Corporate Seal & Witness)"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.poaDocs[4].signatureTemplateID","14"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.poaDocs[4].documentCat","P"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.poaDocs[4].sortOrder","131"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.poaDocs[5].docType","245"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.poaDocs[5].formName","Power of Attorney (WA)"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.poaDocs[5].signatureTemplateID","9"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.poaDocs[5].documentCat","P"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.poaDocs[5].sortOrder","134"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.tlmDocs[0].docType","274"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.tlmDocs[0].formName","TLM Sales Order Form"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.tlmDocs[0].signatureTemplateID","9"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.tlmDocs[0].documentCat","T"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.tlmDocs[0].sortOrder","10"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.tlmDocs[1].docType","275"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.tlmDocs[1].formName","ADP TLM Transfer Contract"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.tlmDocs[1].signatureTemplateID","9"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.tlmDocs[1].documentCat","T"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.tlmDocs[1].sortOrder","20"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[0].tasks[0].templateTaskID","3"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[0].tasks[0].selected","Y"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[0].tasks[1].templateTaskID","3"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[0].tasks[1].selected","Y"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[0].tasks[2].templateTaskID","6"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[0].tasks[2].selected","Y"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[0].tasks[3].templateTaskID","6"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[0].tasks[3].selected","Y"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[0].tasks[4].templateTaskID","3"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[0].tasks[4].selected","Y"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[0].tasks[5].templateTaskID","6"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[0].tasks[5].selected","Y"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[0].tasks[6].templateTaskID","3"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[0].tasks[6].selected","Y"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[0].tasks[7].templateTaskID","3"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[0].tasks[7].selected","Y"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[0].tasks[8].templateTaskID","3"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[0].tasks[8].selected","Y"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[0].tasks[9].templateTaskID","3"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[0].tasks[9].selected","Y"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[0].tasks[10].templateTaskID","3"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[0].tasks[10].selected","Y"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[0].tasks[11].templateTaskID","6"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[0].tasks[11].selected","Y"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[0].tasks[12].templateTaskID","6"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[0].tasks[12].selected","Y"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[0].tasks[13].templateTaskID","7"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[0].tasks[13].selected","Y"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[0].tasks[14].templateTaskID","6"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[0].tasks[14].selected","Y"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[0].tasks[15].templateTaskID","11"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[0].tasks[15].selected","Y"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[0].tasks[16].templateTaskID","11"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[0].tasks[16].selected","Y"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[0].tasks[17].templateTaskID","13"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[0].tasks[17].selected","Y"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[0].tasks[18].templateTaskID","16"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[0].tasks[18].selected","Y"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[0].tasks[19].templateTaskID","14"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[0].tasks[19].selected","Y"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[0].tasks[20].templateTaskID","6"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[0].tasks[20].selected","Y"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[0].tasks[21].templateTaskID","1"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[0].tasks[21].selected","Y"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[0].tasks[22].templateTaskID","1"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[0].tasks[22].selected","Y"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[0].tasks[23].templateTaskID","6"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[0].tasks[23].selected","Y"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[0].tasks[24].templateTaskID","6"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[0].tasks[24].selected","Y"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[0].tasks[25].templateTaskID","6"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[0].tasks[25].selected","Y"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[0].roleValue","PROSPECT"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[0].esigUserId",""));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[0].seiContact","false"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[0].clientFullName","Robert Libbey"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[0].fullName","C"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[0].jobTitle","VP Finance"));
		
		
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[1].tasks[0].templateTaskID","3"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[1].tasks[0].selected","Y"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[1].tasks[1].templateTaskID","3"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[1].tasks[1].selected","Y"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[1].tasks[2].templateTaskID","6"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[1].tasks[2].selected","Y"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[1].tasks[3].templateTaskID","6"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[1].tasks[3].selected","Y"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[1].tasks[4].templateTaskID","3"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[1].tasks[4].selected","Y"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[1].tasks[5].templateTaskID","6"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[1].tasks[5].selected","Y"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[1].tasks[6].templateTaskID","3"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[1].tasks[6].selected","Y"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[1].tasks[7].templateTaskID","3"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[1].tasks[7].selected","Y"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[1].tasks[8].templateTaskID","3"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[1].tasks[8].selected","Y"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[1].tasks[9].templateTaskID","3"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[1].tasks[9].selected","Y"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[1].tasks[10].templateTaskID","3"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[1].tasks[10].selected","Y"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[1].tasks[11].templateTaskID","6"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[1].tasks[11].selected","Y"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[1].tasks[12].templateTaskID","6"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[1].tasks[12].selected","Y"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[1].tasks[13].templateTaskID","7"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[1].tasks[13].selected","Y"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[1].tasks[14].templateTaskID","6"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[1].tasks[14].selected","Y"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[1].tasks[15].templateTaskID","11"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[1].tasks[15].selected","Y"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[1].tasks[16].templateTaskID","11"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[1].tasks[16].selected","Y"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[1].tasks[17].templateTaskID","13"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[1].tasks[17].selected","Y"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[1].tasks[18].templateTaskID","16"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[1].tasks[18].selected","Y"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[1].tasks[19].templateTaskID","14"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[1].tasks[19].selected","Y"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[1].tasks[20].templateTaskID","6"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[1].tasks[20].selected","Y"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[1].tasks[21].templateTaskID","1"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[1].tasks[21].selected","Y"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[1].tasks[22].templateTaskID","1"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[1].tasks[22].selected","Y"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[1].tasks[23].templateTaskID","6"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[1].tasks[23].selected","Y"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[1].tasks[24].templateTaskID","6"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[1].tasks[24].selected","Y"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[1].tasks[25].templateTaskID","6"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[1].tasks[25].selected","Y"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[1].roleValue","PROSPECT"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[1].esigUserId",""));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[1].seiContact","true"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.participantList[1].execId","0"));
		postParams.add(new BasicNameValuePair("signatureTransactionVo.inPerson","No"));
	}

	private String GetPageContent(String url, String jSession) throws Exception {

/*		DefaultHttpClient httpclient = new DefaultHttpClient();
		String url = "http://localhost";
		HttpPost httpPost = new HttpPost(url);

		httpPost.addHeader("header-name" , "header-value");

		HttpResponse response = httpclient.execute(httpPost);
*/		
		HttpGet request = new HttpGet(url);
		
		request.setHeader("User-Agent", USER_AGENT);
		request.setHeader("Accept","text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
		request.setHeader("Accept-Language", "en-US,en;q=0.5");
		request.setHeader("Accept-Encoding", "gzip, deflate, sdch");
		request.setHeader("Upgrade-Insecure-Requests", "gzip, deflate, sdch");
		request.setHeader("Connection", "keep-alive");
		request.setHeader("Host", "192.168.73.128:9080");
		request.setHeader("Cookie", jSession);
		
		HttpResponse response = client.execute(request);
		int responseCode = response.getStatusLine().getStatusCode();

		System.out.println("\nSending 'GET' request to URL : " + url);
		System.out.println("Response Code : " + responseCode);

		BufferedReader rd = new BufferedReader(new InputStreamReader(response
				.getEntity().getContent()));

		StringBuffer result = new StringBuffer();
		String line = "";
		while ((line = rd.readLine()) != null) {
			result.append(line);
		}
		
			
		// set cookies
//		setCookies("");

		return result.toString();

	}

	public List<NameValuePair> getFormParams(String html) throws UnsupportedEncodingException {

		System.out.println("Extracting form's data...");

		Document doc = Jsoup.parse(html);
		
		// Google form id
		/*Element loginform = doc.getElementById("closedDealPackageForm");
		Elements inputElements = loginform.getElementsByTag("input");*/
		Elements inputElements  = doc.getElementsByTag("input");
		List<NameValuePair> paramList = new ArrayList<NameValuePair>();

		for (Element inputElement : inputElements) {
			String key = inputElement.attr("name");
			String value = inputElement.attr("value");

			/*if (key.equals("Email"))
				value = username;
			else if (key.equals("Passwd"))
				value = password;*/

			paramList.add(new BasicNameValuePair(key, value));

		}

		return paramList;
	}

	public String getCookies() {
		return cookies;
	}

	public void setCookies(String cookies) {
		this.cookies = cookies;
	}

}