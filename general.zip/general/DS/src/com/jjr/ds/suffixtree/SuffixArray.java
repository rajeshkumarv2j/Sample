package com.jjr.ds.suffixtree;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Map.Entry;

/******************************************************************************
 *  Compilation:  javac SuffixArray.java
 *  Execution:    java SuffixArray < input.txt
 *  Dependencies: StdIn.java StdOut.java
 *
 *  A data type that computes the suffix array of a string.
 *
 *   % java SuffixArray < abra.txt
 *    i ind lcp rnk  select
 *   ---------------------------
 *    0  11   -   0  "!"
 *    1  10   0   1  "A!"
 *    2   7   1   2  "ABRA!"
 *    3   0   4   3  "ABRACADABRA!"
 *    4   3   1   4  "ACADABRA!"
 *    5   5   1   5  "ADABRA!"
 *    6   8   0   6  "BRA!"
 *    7   1   3   7  "BRACADABRA!"
 *    8   4   0   8  "CADABRA!"
 *    9   6   0   9  "DABRA!"
 *   10   9   0  10  "RA!"
 *   11   2   2  11  "RACADABRA!"
 *
 *  See SuffixArrayX.java for an optimized version that uses 3-way
 *  radix quicksort and does not use the nested class Suffix.
 *
 ******************************************************************************/

public class SuffixArray {
	// Naive algorithm for building suffix array of a given text
	// Structure to store information of a suffix
	class suffix
	{
	    int index;
	    char[] suff;
	}
	 
	// A comparison function used by sort() to compare two suffixes
	/*int cmp(struct suffix a, struct suffix b)
	{
	    return strcmp(a.suff, b.suff) < 0? 1 : 0;
	}*/
	 
	// This is the main function that takes a string 'txt' of size n as an
	// argument, builds and return the suffix array for the given string
	int[] buildSuffixArray(char txt[], int n)
	{
	    // A structure to store suffixes and their indexes
	    suffix[] suffixes = new suffix[n];
	 
	    // Store suffixes and their indexes in an array of structures.
	    // The structure is needed to sort the suffixes alphabatically
	    // and maintain their old indexes while sorting
	    for (int i = 0; i < n; i++)
	    {
	    	suffixes[i] = new suffix();
	        suffixes[i].index = i;
	        String s = new String(txt);
	        suffixes[i].suff = (s.substring(i, s.length())).toCharArray();
	    }
	 
	    // Sort the suffixes using the comparison function
	    // defined above.
//	    sort(suffixes, suffixes+n, cmp);
	    
	    sort(suffixes, new Comparator<suffix>() {
	    	public int compare(suffix sf1, suffix sf2){
	    		return new String(sf1.suff).compareTo(new String(sf2.suff));
	    	}
		});
	 
	    // Store indexes of all sorted suffixes in the suffix array
	    int []suffixArr = new int[n];
	    for (int i = 0; i < n; i++)
	        suffixArr[i] = suffixes[i].index;
	 
	    // Return the suffix array
	    return  suffixArr;
	}
	 
	// Driver program to test above functions
	public static void main(String[] args) {
	    char txt[] = "banana".toCharArray();
	    int n = txt.length;
	    int []suffixArr = new SuffixArray().buildSuffixArray(txt,  n);
	    System.out.println("Following is suffix array for " + new String(txt) );
	    for (int i : suffixArr) {
	    	System.out.print(i+" ");
		}
	}
	
/*	// A suffix array based search function to search a given pattern
	// 'pat' in given text 'txt' using suffix array suffArr[]
	void search(char []pat, char []txt, int []suffArr, int n)
	{
	    int m = pat.length;  // get length of pattern, needed for strncmp()
	 
	    // Do simple binary search for the pat in txt using the
	    // built suffix array
	    int l = 0, r = n-1;  // Initilize left and right indexes
	    while (l <= r)
	    {
	        // See if 'pat' is prefix of middle suffix in suffix array
	        int mid = l + (r - l)/2;
	        int res = strncmp(pat, txt+suffArr[mid], m);
	 
	        // If match found at the middle, print it and return
	        if (res == 0)
	        {
	            System.out.println("Pattern found at index " +suffArr[mid]);
	            return;
	        }
	 
	        // Move to left half if pattern is alphabtically less than
	        // the mid suffix
	        if (res < 0) r = mid - 1;
	 
	        // Otherwise move to right half
	        else l = mid + 1;
	    }
	 
	    // We reach here if return statement in loop is not executed
	    System.out.println( "Pattern not found");
	}
	 
	// Driver program to test above function
	int main()
	{
	    char txt[] = "banana";  // text
	    char pat[] = "nan";   // pattern to be searched in text
	 
	    // Build suffix array
	    int n = strlen(txt);
	    int *suffArr = buildSuffixArray(txt, n);
	 
	    // search pat in txt using the built suffix array
	    search(pat, txt, suffArr, n);
	 
	    return 0;
	}
*/	
	public static void main1(String[] args) {
		String s = "banana";
		Map<Integer, String> map = new HashMap<Integer, String>(); 
		for (int i = 0; i< s.length(); i++) {
			map.put(i, s.substring(i, s.length()));
		}
		List<Entry<Integer, String>> entries  = new ArrayList<Map.Entry<Integer,String>>(map.entrySet());
		sort(entries, new Comparator<Entry<Integer,String>>(){ 
			@Override
			public int compare(Entry<Integer, String> arg0,
					Entry<Integer, String> arg1) {
				return arg0.getValue().compareTo(arg1.getValue());
			}
		});
		for (Entry<Integer, String> entry : entries) {
			System.out.println(entry.getKey()+" "+entry.getValue());
		}
	}
	
	 public static <T> void sort(List<T> list, Comparator<? super T> comparator) {
	        T[] array = list.toArray((T[]) new Object[list.size()]);
	        sort(array, comparator);
	        int i = 0;
	        ListIterator<T> it = list.listIterator();
	        while (it.hasNext()) {
	            it.next();
	            it.set(array[i++]);
	        }
	    }
	 
	 public static <T> void sort(T[] array, Comparator<? super T> comparator) {
	        sort(0, array.length, array, comparator);
	    }
	 
	 
	 private static <T> void sort(int start, int end, T[] array,
	            Comparator<? super T> comparator) {
	            int length = end - start;
	            Object[] out = new Object[end];
	            System.arraycopy(array, start, out, start, length);
	            mergeSort(out, array, start, end, comparator);
	    }
	 
	 private static final int SIMPLE_LENGTH = 7;
	 
	 private static void mergeSort(Object[] in, Object[] out, int start,
	            int end, Comparator c) {
	        int len = end - start;
	        // use insertion sort for small arrays
	        if (len <= SIMPLE_LENGTH) {
	            for (int i = start + 1; i < end; i++) {
	                Object current = out[i];
	                Object prev = out[i - 1];
	                if (c.compare(prev, current) > 0) {
	                    int j = i;
	                    do {
	                        out[j--] = prev;
	                    } while (j > start
	                            && (c.compare(prev = out[j - 1], current) > 0));
	                    out[j] = current;
	                }
	            }
	            return;
	        }
	        int med = (end + start) >>> 1;
	        mergeSort(out, in, start, med, c);
	        mergeSort(out, in, med, end, c);

	        // merging

	        // if arrays are already sorted - no merge
	        if (c.compare(in[med - 1],in[med] ) <= 0) {
	            System.arraycopy(in, start, out, start, len);
	            return;
	        }
	        int r = med, i = start;

	        // use merging with exponential search
	        do {
	            Object fromVal = in[start];
	            Object rVal = in[r];
	            if (c.compare(fromVal, rVal) <= 0) {
	                int l_1 = find(in, rVal, -1, start + 1, med - 1, c);
	                int toCopy = l_1 - start + 1;
	                System.arraycopy(in, start, out, i, toCopy);
	                i += toCopy;
	                out[i++] = rVal;
	                r++;
	                start = l_1 + 1;
	            } else {
	                int r_1 = find(in, fromVal, 0, r + 1, end - 1, c);
	                int toCopy = r_1 - r + 1;
	                System.arraycopy(in, r, out, i, toCopy);
	                i += toCopy;
	                out[i++] = fromVal;
	                start++;
	                r = r_1 + 1;
	            }
	        } while ((end - r) > 0 && (med - start) > 0);

	        // copy rest of array
	        if ((end - r) <= 0) {
	            System.arraycopy(in, start, out, i, med - start);
	        } else {
	            System.arraycopy(in, r, out, i, end - r);
	        }
	    }
	 
	 private static int find(Object[] arr, Object val, int bnd, int l, int r,
	            Comparator c) {
	        int m = l;
	        int d = 1;
	        while (m <= r) {
	            if (c.compare(val, arr[m]) > bnd) {
	                l = m + 1;
	            } else {
	                r = m - 1;
	                break;
	            }
	            m += d;
	            d <<= 1;
	        }
	        while (l <= r) {
	            m = (l + r) >>> 1;
	            if (c.compare(val, arr[m]) > bnd) {
	                l = m + 1; 
	            } else {
	                r = m - 1;
	            }
	        }
	        return l - 1;
	    }
}