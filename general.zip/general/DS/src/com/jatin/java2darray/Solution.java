package com.jatin.java2darray;
import java.util.Scanner;

public class Solution {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int arr[][] = new int[6][6];
        for(int i=0; i < 6; i++){
            for(int j=0; j < 6; j++){
                arr[i][j] = in.nextInt();
            }
        }
        
/*      1 1 1 0 0 0
        0 1 0 0 0 0
        1 1 1 0 0 0
        0 9 2 -4 -4 0
        0 0 0 -2 0 0
        0 0 -1 -2 -4 0
*/
        int []list = new int[8];
        for(int i=0; i<4; i++){
        	for(int j=0; j<3; j++){
        		
        		for(int k=0; k<3; k++){
        			arr[i+j][k];
        		}
        	}
        }
    }
}
