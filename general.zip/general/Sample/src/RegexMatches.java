import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexMatches {
	private static String REGEX = "abcd*";
	private static String INPUT = "abv";
	private static String REPLACE = "-";

	public static void main1(String[] args) {
		Pattern p = Pattern.compile(REGEX);
		// get a matcher object
		Matcher m = p.matcher(INPUT);
		StringBuffer sb = new StringBuffer();
		while (m.find()) {
			m.appendReplacement(sb, REPLACE);
		}
		m.appendTail(sb);
		System.out.println(sb.toString());
	}

	public static void main2(String[] args) {
		String REGEX = "^[0-9]{1,8}([\\.][0-9]{0,2})?$";
		String REGEX1 = "^[0-9- \\.\\/]{9,15}$";
		String s = "111-11-1";
		System.out.println(s.matches(REGEX1));
	}

	public static void main(String[] args) {
		
		String actual = "123456789";
		final Pattern ssnFormat = Pattern.compile("^(\\d{3})(\\d{2})(\\d{4})$");
		Matcher m = ssnFormat.matcher(actual);
		if (m.find()) {
			String value = "xxx-xx-"+String.format("%s%n", m.group(3));
			System.out.println(value);
		}
	}
}