import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.lowagie.text.pdf.PdfReader;


public class Sample {
	
	public static void main2(String[] args) throws ParseException {
		
		Date date = new SimpleDateFormat("MM/dd/yyyy").parse("11/20/2015");
		String date1 = new SimpleDateFormat("MMM-dd-yyyy").format(date);
		System.out.println(date1);
		System.out.println(new Timestamp(new Date().getTime()));
		System.out.println(new Timestamp(date.getTime()));
  		if(new Timestamp(new Date().getTime()).after(date)){
  			System.out.println("Done");
  		}
	}
	public static void main1(String[] args) {
		InputStream is  = null;
		ByteArrayOutputStream os = null;
		try {
			File file = new File("C:/Rajeshkumar/pracise/general/Sample/224725-201.pdf");
			is = new FileInputStream(file);
			os = new ByteArrayOutputStream();
			PdfReader reader = new PdfReader(os.toByteArray());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		/*Calendar cal = Calendar.getInstance();
		Timestamp starttimeStamp = null;
		Timestamp endtimeStamp = null;
		String isSuccess = "Y";
		starttimeStamp = new Timestamp(cal.getTimeInMillis());
	  	System.out.println(starttimeStamp);   
	  	Thread.sleep(2000);
	  	endtimeStamp = new Timestamp(starttimeStamp.getTime());
	  	System.out.println(endtimeStamp);
	  	*/
	  	
		try{
			String s = null;
			System.out.println(s.replaceAll( "(.*),(.*)", "$2 $1" ) );
		}catch (ArrayIndexOutOfBoundsException e) {
			e.printStackTrace();
			System.out.println("In Catch");
		}finally{
			System.out.println("In Finally");
		}
	  	   System.out.println();
	}
}
