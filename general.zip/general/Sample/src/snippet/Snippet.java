package snippet;

public class Snippet {
	public static void main(String[] args) {
		String s = "a";
		System.out.println(s);
		System.out.println(s.intern());
	}
}