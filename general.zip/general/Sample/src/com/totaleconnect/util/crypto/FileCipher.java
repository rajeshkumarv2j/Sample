package com.totaleconnect.util.crypto;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.CipherOutputStream;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;

public class FileCipher {

//	private static final String KEY_DESCR = "FILE_ENCRYPTION_DES_KEY";
	private static final String ALGORITHM_DES = "DES";

	public static void encrypt(InputStream is, OutputStream os) throws Throwable {
		encryptOrDecrypt(Cipher.ENCRYPT_MODE, is, os);
	}
	public static void encrypt(byte[] bytes, OutputStream os) throws Throwable {
		InputStream is = new ByteArrayInputStream(bytes);
		encryptOrDecrypt(Cipher.ENCRYPT_MODE, is, os);
	}

	public static void encrypt(String inputFile, String outputFile) throws Throwable {
	    File inFile = new File(inputFile);
	    if (!inFile.exists()){
	        throw new Exception("File "+inputFile + " does not exist!");
	    }
        FileInputStream is = new FileInputStream(inFile);

        File dFile = new File(outputFile);
	    if (dFile.exists()){
	        throw new Exception("File "+outputFile + " already exists!");
	    }
        FileOutputStream os = new FileOutputStream(dFile);

        encryptOrDecrypt(Cipher.ENCRYPT_MODE, is, os);
	}

	public static void encrypt(InputStream is, String outputFile) throws Throwable {
	    File dFile = new File(outputFile);
	    if (dFile.exists()){
	        throw new Exception("File "+outputFile + " already exists!");
	    }
        FileOutputStream os = new FileOutputStream(dFile);
		
		encryptOrDecrypt(Cipher.ENCRYPT_MODE, is, os);
	}

	public static void decrypt(InputStream is, OutputStream os) throws Throwable {
		encryptOrDecrypt(Cipher.DECRYPT_MODE, is, os);
	}

	public static void decrypt(String inputFile, OutputStream os) throws Throwable {
	    File inFile = new File(inputFile);
	    if (!inFile.exists()){
	        throw new Exception("File "+inputFile + " does not exist!");
	    }
        FileInputStream is = new FileInputStream(inFile);

        encryptOrDecrypt(Cipher.DECRYPT_MODE, is, os);
	}

	public static void decrypt(InputStream is, String outputFile) throws Throwable {
	    File dFile = new File(outputFile);
	    if (dFile.exists()){
	        throw new Exception("File "+outputFile + " already exists!");
	    }
        FileOutputStream os = new FileOutputStream(dFile);

        encryptOrDecrypt(Cipher.DECRYPT_MODE, is, os);
	}

	private static void encryptOrDecrypt(int mode, InputStream is, OutputStream os) throws Throwable {
		String keyValue = "ADP-TS-5800-Tower-B-DES";//getKeyValue(KEY_DESCR);
//		if (keyValue == null) throw new Exception("Encryption Key cannot be located!");
		DESKeySpec dks = new DESKeySpec(keyValue.getBytes());
		SecretKeyFactory skf = SecretKeyFactory.getInstance(ALGORITHM_DES);
		SecretKey desKey = skf.generateSecret(dks);
		Cipher cipher = Cipher.getInstance(ALGORITHM_DES); // DES/ECB/PKCS5Padding for SunJCE

		if (mode == Cipher.ENCRYPT_MODE) {
			cipher.init(Cipher.ENCRYPT_MODE, desKey);
			CipherInputStream cis = new CipherInputStream(is, cipher);
			doCopy(cis, os);
		} else if (mode == Cipher.DECRYPT_MODE) {
			cipher.init(Cipher.DECRYPT_MODE, desKey);
			CipherOutputStream cos = new CipherOutputStream(os, cipher);
			doCopy(is, cos);
		}
	}

	private static void doCopy(InputStream is, OutputStream os) throws IOException {
		byte[] bytes = new byte[64];
		int numBytes;
		while ((numBytes = is.read(bytes)) != -1) {
			os.write(bytes, 0, numBytes);
		}
		os.flush();
		os.close();
		is.close();
	}
	
	/*private static String sql_SELECT_KEY_VALUE = "SELECT field_val FROM ps_ts_pt_work w WHERE descr50 = ? " +
    " AND effdt = (SELECT MAX (effdt) FROM ps_ts_pt_work w2 " +
                " WHERE w2.descr50 = w.descr50 AND w2.effdt <= ?) ";
	*/
	/*private static String getKeyValue(String keyId) throws Exception {        
        Connection conn = null;
		LoggableStatement stmt = null;
		ResultSet rs = null;
		String keyValue = null;

		try {
			conn = Dao.getDBConnectionUsingResourceRef();            
            stmt = new LoggableStatement(conn, sql_SELECT_KEY_VALUE);
            
            stmt.setString(1, keyId); 
            stmt.setDate(2, new Date( Calendar.getInstance().getTimeInMillis() )); 
            
            rs = stmt.executeQuery();
			
			if(rs.next()){
				keyValue = rs.getString("field_val");
			}  	        
			return keyValue;
			
       } catch (SQLException e) {
			  throw new Exception(e);
	   } finally {
		   Dao.close(conn, stmt, rs);
	   }
    }*/


}