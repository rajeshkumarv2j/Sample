import java.text.NumberFormat;


public class NumberFormatExamples {
	public static void main(String[] args) {
		NumberFormat nf2 = NumberFormat.getInstance();
		nf2.setMaximumFractionDigits(3);
	    nf2.setMinimumFractionDigits(3);
	    nf2.setGroupingUsed(false);
		System.out.println(nf2.format(0.21459));
		System.out.println("\u00ae");
		System.out.println("\u0C05");
		
	}
}
