package com.mypratise.authorization;


import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;


public abstract class Bytes {

    public static final Bytes.HashAlgorithm SHA256 = new HashAlgorithm("SHA-256");

    private static final int BYTE_MASK = 0xFF;
    private static final int HEX_RADIX = 16;

    public static final byte[] hexToBytes(String stHex) {
        int iHigh;
        int iLow;
        int i = 0;
        int iLen = stHex.length();
        int iNumBytes = iLen / 2;
        byte[] arByResult = new byte[iNumBytes];

        while (i < iLen) {
            iHigh = Character.digit(stHex.charAt(i++), HEX_RADIX) * HEX_RADIX;
            iLow = Character.digit(stHex.charAt(i++), HEX_RADIX);

            arByResult[(i / 2) - 1] = (byte) (iHigh + iLow);
        }

        return arByResult;
    }

    public static final String bytesToHex(byte[] arByData) {
        int i;
        int iByte;
        StringBuffer sbBuf = new StringBuffer(arByData.length * 2);

        for (i = 0; i < arByData.length; i++) {
            iByte = arByData[i] & BYTE_MASK;

            if (iByte < HEX_RADIX) {
                sbBuf.append('0').append(Character.forDigit(iByte, HEX_RADIX));
            } else {
                sbBuf.append(Character.forDigit(iByte / HEX_RADIX, HEX_RADIX));
                sbBuf.append(Character.forDigit(iByte % HEX_RADIX, HEX_RADIX));
            }
        }

        return sbBuf.toString();
    }

    public static final String hash(byte[] arByData, Bytes.HashAlgorithm oAlgorithm) {
        MessageDigest oDigest;

        try {
            oDigest = MessageDigest.getInstance(oAlgorithm.toString());
            return bytesToHex(oDigest.digest(arByData));
        } catch (NoSuchAlgorithmException e) // should NEVER happen
        {
            throw new RuntimeException(e.toString());
        }
    }

    public static class HashAlgorithm {
        String _stValue;

        HashAlgorithm(String stValue) {
            _stValue = stValue;
        }

        @Override
        public String toString() {
            return _stValue;
        }
    }
}

