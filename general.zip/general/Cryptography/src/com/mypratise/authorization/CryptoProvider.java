package com.mypratise.authorization;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Arrays;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;


public class CryptoProvider {
	
    private static final String AES_ALGORITHM = "AES/CFB/PKCS5Padding";
    private static final int IV_BYTES_LENGTH = 16;
    private static final int IV_STRING_LENGTH = 24;
	private static final String CLASS_NAME = CryptoProvider.class.getName();

    /**
     * Calculates the SHA-256 hash for the given input
     * 
     * @param input
     * @return SHA-256 hash
     */
    public static String calculateHash( String input ) {

        String hash = null;
        if (input != null) {

            try {
                byte[] defaultBytes = input.getBytes("UTF8");
                
                MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
                messageDigest.reset();
                messageDigest.update(defaultBytes);
                //hash = new String( messageDigest.digest(), "UTF8");
                
                //convert the byte to hex format method 1
                byte[] byteData = messageDigest.digest();
                StringBuffer sb = new StringBuffer();
                for (int i = 0; i < byteData.length; i++) {
                 sb.append(Integer.toString((byteData[i] & 0xff) + 0x100, 16).substring(1));
                }
                
                hash = sb.toString();

                
            } catch (NoSuchAlgorithmException nsae) {
            	nsae.printStackTrace();
            	
            } catch ( UnsupportedEncodingException uee ) {
            	uee.printStackTrace();
            }
        }
        
        return hash;
    }
    
    public static String encrypt(String data, String key) {
        String stResult = null;
        String stEncrypted = null;
        String stSalt = null;
        byte[] bSalt = new byte[IV_BYTES_LENGTH];
        IvParameterSpec IV = null;
        
        SecretKey AES_KEY = new SecretKeySpec(Bytes.hexToBytes(key), "AES");

        try {
            SecureRandom random = SecureRandom.getInstance("SHA1PRNG");
            random.nextBytes(bSalt);

            Cipher oEncryptor = null;
            oEncryptor = Cipher.getInstance(AES_ALGORITHM);
            IV = new IvParameterSpec(bSalt);
            oEncryptor.init(Cipher.ENCRYPT_MODE, AES_KEY, IV);

            byte[] bEncrypted = oEncryptor.doFinal(data.getBytes());

            
            stSalt = Base64.encodeBytes(bSalt, false);
            stEncrypted = Base64.encodeBytes(bEncrypted, false);
            stResult = stSalt + stEncrypted;
        } catch (Exception x) {
        	x.printStackTrace();
        }

        return stResult;
    }    
    
    public static String decrypt(String stData, String key) {
        String stResult = null;
        String stSalt = stData.substring(0, IV_STRING_LENGTH);
        String stEncrypted = stData.substring(IV_STRING_LENGTH);
        SecretKey oKey = new SecretKeySpec(Bytes.hexToBytes(key), "AES");
        
        byte[] bSalt;
        byte[] bEncrypted;

        bSalt = Base64.decode(stSalt);
        bEncrypted = Base64.decode(stEncrypted);

        try {
            Cipher oDecryptor = Cipher.getInstance(AES_ALGORITHM);
            IvParameterSpec IV = new IvParameterSpec(Arrays.copyOf(bSalt, IV_BYTES_LENGTH));

            oDecryptor.init(Cipher.DECRYPT_MODE, oKey, IV);
            stResult = new String(oDecryptor.doFinal(bEncrypted));
        } catch (Exception x) {
        	x.printStackTrace();
        }

        return stResult;
    }    
    
}
