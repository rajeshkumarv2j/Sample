package com.mypratise.authorization;

import java.io.IOException;
import java.io.InterruptedIOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

//public class Test {
/*	private static int empNo;
	private static String empName;
	public static String getEmpName() {
		empName = "adp";
		return empName;
	}
	public static int getEmpNo() {
		empNo = 20;
		return empNo;
	}
	public static void main(String[] args) {
		Test test = null;
		System.out.println(test.getEmpNo());
		System.out.println(test.getEmpName());
	}*/
	/*public static void main(String[] args) {
		Set<String> list = new HashSet<String>();
		list.add(" a");
		list.add(" a ");
		System.out.println(list.size());
		for (String string : list) {
			System.out.println(string);
		}
		for (String string : list) {
			list.remove(string);
		}
		System.out.println(list.size());
	}*/
	/*public static void main(String[] args) {
		Set<String> list = new HashSet<String>();
		list.add("a");
		list.add("a");
		System.out.println(list.size());
		for (String string : list) {
			list.remove(string);
		}
		System.out.println(list.size());
	}*/
	
	/*class Father{
		public String name;
		public Father(String string) {
			name = string;
		}
	}
	class Son extends Father{
		public Son(String string) {
			super(string);
		}
	}
	public class Test {
	public static void main(String[] args) {
		Father father = new Son("Ganesh");
		System.out.println(father.name);
		List<? extends Father> list = new ArrayList<Son>();
		list.add(father);
		for (Father father2 : list) {
			System.out.println(father2.name);
		}
	}*/
	
/*	class Father{
	public String name;
	public Father(String string) {
		name = string;
	}
}
class Son extends Father{
	public Son(String string) {
		super(string);
	}
}
public class Test {
public static void main(String[] args) {
	Son son = new Son("Ganesh");
	System.out.println(son.name);
	List<? super Son> list = new ArrayList<Father>();
	list.add(son);
	for (Father father2 : list) {
		System.out.println(father2.name);
	}
}*/

	/*public static void main(String[] args) {
		Set<String> list = new HashSet<String>();
		list.add("a");
		list.add("ab");
		System.out.println(list.size());
		for (String string : list) {
			list.remove(string);
		}
		System.out.println(list.size());
	}*/
	
	/*public static void main(String[] args) {
		try {
			badMethod();
			System.out.print("A");
		} catch (Exception ex) {
			System.out.print("B");
		} finally {
			System.out.print("C");
		}
		System.out.print("D");
	}
	public static void badMethod() {
		throw new Error();  Line 22 
	}*/
	/*
	public static void main(String[] args) {
		Short s1 = 10,s2 = 10;
		System.out.println(s1 == s2);
		System.out.println(s1.equals(s2));
	}
	*/
	/*public static void main(String[] args) {
		Set<String> list = new HashSet<String>();
		list.add(" a ");
		list.add(" a ");
		System.out.println(list.size());
		for (String string : list) {
			list.remove(string);
		}
		System.out.println(list.size());
	}*/
	
	public class Test {
		public static void main1(String[] args){//throws Exception {
			Short s1 = 10,s2 = 10;
			System.out.print(s1 == s2);
			System.out.print(s1.equals(s2));
			System.out.println();
			Short s3 = 500,s4 = 500;
			System.out.print(s3 == s4);
			System.out.print(s3.equals(s4));
//throw new NullPointerException();
//throw new Exception();
			/*try{
				
			}catch(IOException o){
				 
			}*/
		}
		public static void main(String[] args) {
			System.out.println("Rajeshkumar.V".substring(0, 5));
			System.out.println("Rajeshkumar.V-".indexOf(13));
		}
}
