
public class Sample {
public static void main(String[] args) {
	System.out.println("\u0C00");
	System.out.println("\u0C00");
}
}
