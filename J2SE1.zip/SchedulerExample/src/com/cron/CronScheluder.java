package com.cron;

import org.quartz.CronTrigger;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerFactory;
import org.quartz.impl.StdSchedulerFactory;

public class CronScheluder {

    public CronScheluder() throws Exception {

        SchedulerFactory sf = new StdSchedulerFactory();

        Scheduler sche = sf.getScheduler();

        sche.start();

        JobDetail jDetail = new JobDetail("Newsletter", "NJob", MyJob.class);

        //"0 0 12 * * ?" Fire at 12pm (noon) every day
        //"0/2 * * * * ?" Fire at every 2 seconds every day
        
        /*1. Seconds	0 to 59
        2. Minutes		0 to 59
        3. Hours		0 to 23
        4. Day-of-Month	1-31
        5. Month		0 and 11 or JAN, FEB, MAR, APR, MAY, JUN, JUL, AUG, SEP, OCT, NOV and DEC.
        6. Day-of-Week	1 and 7 (1 = Sunday) or SUN, MON, TUE, WED, THU, FRI and SAT
        7. Year (optional field)
        
        * The '?' character is allowed for the day-of-month and day-of-week fields means no specific value.
        * 
        * "L" in the day-of-month field means "the last day of the month" - day 31 for January, day 28 for 
        * February on non-leap years.
        * If used in the day-of-week field by itself, it simply means "7" or "SAT".
        * 
        * But if used in the day-of-week field after another value, it means "the last xxx day of the month"
        *  - for example "6L" or "FRIL" both mean "the last friday of the month".
        * 
        * You can also specify an offset from the last day of the month, such as "L-3" which would mean the 
        * third-to-last day of the calendar month.
        * 
        * The 'W' is used to specify the weekday (Monday-Friday) nearest the given day. As an example, if you were to
		* specify "15W" as the value for the day-of-month field, the meaning is: "the nearest weekday to the 15th of the month".
		* 
		* The '#' is used to specify "the nth" XXX weekday of the month. For example, the value of "6#3" or "FRI#3"
		* in the day-of-week field means "the third Friday of the month".
		* 
		* "10 0/5 * * * ?"  create a trigger that fires every 5 minutes, at 10 seconds after the minute (i.e. 10:00:10 am, 
		* 10:05:10 am, etc.).
		* 
		* "10 0/5 * * * ?" create a trigger that fires every 5 minutes, at 10 seconds after the minute
		* 
		* "0 38 10-12 ? * ?" create a trigger that fires at 10:30, 11:30, 12:30, and 13:30
		* 
		* "0 30 10-13 ? * WED,FRI" create a trigger that fires at 10:30, 11:30, 12:30, and 13:30, on
		* every Wednesday and Friday.
		* 
		* 0/5 means for every 5 minutes duration.(hours no is not required)
		* 
		* 50 means at the time of exact 50th minute. (hours no is required)
		* 
		* "0 0/30 8-9 5,20 * ?" create a trigger that fires every half hour between the hours of 8 am
		* and 10 am on the 5th and 20th of every month. Note that the trigger will NOT fire at 10:00 am, just at 8:00,
		* 8:30, 9:00 and 9:30
		* 
		* 
		* -------------------------------------------------------------
		* scheduled to run every 20 seconds 0/20 * * * * ?
		* 
		* scheduled to run every other minute, starting at 15 seconds past the minute. 15 0/2 * * * ?
		* 
		* scheduled to every other minute, between 8am and 5pm (17 o'clock). 0 0/2 8-17 * * ?
		* 
		* 
        */

 CronTrigger crTrigger = new CronTrigger("cronTrigger", "NJob", "0/5 * 23 * * ?");

        sche.scheduleJob(jDetail, crTrigger);
    }
}