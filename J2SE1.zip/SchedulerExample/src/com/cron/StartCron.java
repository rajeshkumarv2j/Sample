package com.cron;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

public class StartCron implements ServletContextListener{

    public void contextDestroyed(ServletContextEvent arg0)
    {
        System.out.println("Stopping Application successfully");
    }

    public void contextInitialized(ServletContextEvent arg0)
    {
       System.out.println("Initializing Application successfully");

       try{
         CronScheluder objPlugin = new CronScheluder();
       }
       catch(Exception e)
       {
           e.printStackTrace();
       }
     }
}