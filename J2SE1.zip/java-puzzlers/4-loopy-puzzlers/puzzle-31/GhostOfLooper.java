public class GhostOfLooper {
    public static void main(String[] args) {
        // Place your declaration for i here

        while (i != 0)
            i >>>= 1;
    }
}
