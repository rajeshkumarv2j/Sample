public class CurseOfLooper {
    public static void main(String[] args) {
        // Place your declarations for i and j here

        while (i <= j && j <= i && i != j) {
        }
    }
}
