public class Tweedledee {
    public static void main(String[] args) {
        // Put your declarations for x and i here

        x = x + i;  // Must be LEGAL
        x += i;     // Must be ILLEGAL
    }
}
