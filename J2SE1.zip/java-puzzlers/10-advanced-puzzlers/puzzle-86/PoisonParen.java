public class PoisonParen {
    /*
     * Add a declaration that initializes a field to some expression and
     * compile the program. It must compile without error. Now add a pair
     * of parentheses around a subexpression that serves merely to reinforce
     * the order of evaluation that was performed before you inserted the
     * parentheses.  Recompile the program. If it no longer compiles, then
     * you've solved the puzzle!
     */
}
