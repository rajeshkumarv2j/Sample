package com.sportsvite;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

public class Copy_2_of_AwesomeProcessor implements Job {

    public void execute(JobExecutionContext context)
     throws JobExecutionException {

      System.out.println("Copy_2_of_AwesomeProcessor executing ");
//      SendMailTLS sendMailTLS = new SendMailTLS();
//      sendMailTLS.doSend();

    }
}