package com.sportsvite;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

public class CopyOfAwesomeProcessor implements Job {

    public void execute(JobExecutionContext context)
     throws JobExecutionException {

      System.out.println("CopyOfAwesomeProcessor executing ");
//      SendMailTLS sendMailTLS = new SendMailTLS();
//      sendMailTLS.doSend();

    }
}