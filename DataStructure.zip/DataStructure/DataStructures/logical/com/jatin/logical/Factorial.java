package com.jatin.logical;

import java.util.Scanner;

public class Factorial {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int noOfTestCases = scanner.nextInt();
		int[] inputArr = new int[noOfTestCases];
		for (int i = 0; i < noOfTestCases; i++) {
			inputArr[i] = scanner.nextInt();
		}
		for (int i = 0; i < noOfTestCases; i++) {
			System.out.println(factorial(inputArr[i]));
			System.out.println(factorial1(inputArr[i]));
		}
	}

	private static int factorial(int i) {
		int result = i;
		while ((i - 1) > 1) {
			result = result * (i - 1);
			i--;
		}
		return result;
	}

	private static int factorial1(int k) {
		int result = k;
		for (int i = (k - 1); i > 1; i--) {
			result = result * i;
		}
		return result;
	}
}
