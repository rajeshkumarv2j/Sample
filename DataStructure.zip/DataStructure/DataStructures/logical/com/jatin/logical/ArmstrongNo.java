package com.jatin.logical;

import java.util.Scanner;

public class ArmstrongNo {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int from = scanner.nextInt();
		int to = scanner.nextInt();
		for (int i = from; i < to; i++) {
			isArmstrongNo(i);
		}
	}

	private static void isArmstrongNo(int i) {
		int sqr = 0;
		if (i / 10 == 0) {
			sqr = 1;
		} else if ((i / 10) > 0 && (i / 10) < 10) {
			sqr = 2;
		} else if ((i / 10) > 10 && (i / 10) < 100) {
			sqr = 3;
		} else if ((i / 10) > 100 && (i / 10) < 1000) {
			sqr = 4;
		}
		int result = 0;
		int ac = i;
		while (i > 0) {
			int r = i % 10;
			int y = 1;
			for (int j = 0; j < sqr; j++) {
				y = y * r;
			}
			result = result + y;// (Math.sqr);//(r * r * r);
			i = i / 10;
		}
		if (result == ac)
			System.out.print(ac + ",");
	}
}
