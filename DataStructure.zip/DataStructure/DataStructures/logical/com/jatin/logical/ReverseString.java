package com.jatin.logical;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class ReverseString {
	public static void main(String[] args) {
		// Scanner s = new Scanner(System.in);
		String s1 = "rajeshku";// s.next();
		System.out.println(withStringBuffer(s1));
		System.out.println(withStringBuilder(s1));
		System.out.println(withStringCharAt(s1));
		System.out.println(withCharArray(s1));
		System.out.println(withCharArrayRecursive(s1));
		System.out.println(reverseStringRecursive(s1, ""));
	}

	public static String reverseStringRecursive(String str, String reverse) {
		if (str.length() == 1) {
			return str;
		}
		reverse += str.charAt(str.length() - 1)
				+ reverseStringRecursive(str.substring(0, str.length() - 1),
						reverse);
		return reverse;
	}

	private static String withCharArrayRecursive(String s1) {
		char[] c = s1.toCharArray();
		revS(c, -1);
		return new String(c);
	}

	private static void revS(char[] c, int i) {
		if (((c.length - 1) / 2) == i++)
			return;
		revS(c, i);
		char tmp = c[(c.length - 1) - i];
		c[(c.length - 1) - i] = c[i];
		c[i] = tmp;
	}

	private static char[] withCharArray(String s1) {
		char[] a1 = s1.toCharArray();
		Character[] a = new Character[a1.length];
		for (int i = 0; i < a1.length; i++) {
			a[i] = a1[i];
		}
		List<Character> characters = new ArrayList<Character>(Arrays.asList(a));
		Collections.reverse(characters);
		for (int i = 0; i < a.length; i++) {
			a1[i] = characters.get(i);// [i];
		}
		return a1;
	}

	private static String withStringCharAt(String s1) {
		String c = "";
		for (int i = (s1.length() - 1); i >= 0; i--) {
			c = c.concat("" + s1.charAt(i));
		}
		return c;
	}

	private static String withStringBuffer(String s1) {
		return new StringBuffer(s1).reverse().toString();
	}

	private static String withStringBuilder(String s1) {
		return new StringBuilder(s1).reverse().toString();
	}
}
