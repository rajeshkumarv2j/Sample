package com.jatin.logical;
import java.util.ArrayList;
 
class Ideone
{
	public static void main (String[] args) throws java.lang.Exception
	{
		// your code goes here
		int []a=new int[]{1, 2, 3, 3, 4, 4, 5, 6, 130};
 
		int k=8;
		for(int i=0;i<a.length;i++){
			a[a[i]%k]+=k;
		}
 
		ArrayList<Integer> al=new ArrayList<Integer>();
 
		int max=0;
		for(int i=0;i<a.length;i++){
			if(a[i]/k>max){
				max=a[i]/k;
				al.clear();
				al.add(i);
			}
			else if(a[i]/k==max){
				al.add(i);
			}
			a[i]%=k;
		}
 
 
		for(int i=0;i<al.size();i++){
			System.out.print(al.get(i)+" ");
		}
	}
}