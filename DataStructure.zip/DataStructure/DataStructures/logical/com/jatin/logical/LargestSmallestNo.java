package com.jatin.logical;

public class LargestSmallestNo {
	public static void main(String[] args) {
		double[] arr = { 2, 22, 5, 77, 45, 98, 1, -22, -33.98, -33.99, 65, 90 };
		double smallest = Double.MAX_VALUE;
		double gretest = Double.MIN_VALUE;
		for (int i = 0; i < arr.length; i++) {
			if (smallest > arr[i]) {
				smallest = arr[i];
			}
			if (gretest < arr[i]) {
				gretest = arr[i];
			}
		}
		System.out.println(smallest);
		System.out.println(gretest);
	}
}
