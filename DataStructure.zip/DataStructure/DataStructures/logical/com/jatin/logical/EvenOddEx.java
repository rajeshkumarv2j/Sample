package com.jatin.logical;

import java.util.Scanner;

public class EvenOddEx {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int noTestCases = scanner.nextInt();
		int[] inputArr = new int[noTestCases];
		for (int i = 0; i < noTestCases; i++) {
			inputArr[i] = scanner.nextInt();
		}
		for (int i = 0; i < inputArr.length; i++) {
			System.out.println(evenOdd(inputArr[i]));
		}
	}

	private static String evenOdd(int a) {
		return (a % 2 == 0) ? "Even" : "Odd";
	}
}