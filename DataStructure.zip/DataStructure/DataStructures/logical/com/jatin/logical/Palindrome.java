package com.jatin.logical;

import java.util.Scanner;

public class Palindrome {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int noOfTestCases = scanner.nextInt();
		String[] inputArr = new String[noOfTestCases];
		for (int i = 0; i < noOfTestCases; i++) {
			inputArr[i] = scanner.next();
		}
		for (int i = 0; i < noOfTestCases; i++) {
			System.out.println((inputArr[i]
					.equals(reverse(inputArr[i])))?"It is Palindrome":"It is Not Palindrome");
		}
	}

	private static String reverse(String s) {
		char[] c = s.toCharArray();
		for (int i = 0; i < (c.length / 2); i++) {
			swap(i, c.length - (i + 1), c);
		}
		return new String(c);
	}

	private static void swap(int i, int j, char[] c) {
		char tmp = c[i];
		c[i] = c[j];
		c[j] = tmp;
	}
}
