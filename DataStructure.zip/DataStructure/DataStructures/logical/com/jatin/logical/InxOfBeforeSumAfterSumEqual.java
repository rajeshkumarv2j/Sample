package com.jatin.logical;

public class InxOfBeforeSumAfterSumEqual {
	public static void main(String[] args) {
//		int[] a = { 10, 11, 12, 10, 4, 3, 2, 11, 3, 56, 43, 10 };
		int[] a = { 10,10,2,3,5};
		int firstSum = 0;
		int lastSum = 0;
		for (int i = 1; i < a.length; i++) {
			lastSum = lastSum + a[i];
		}
		for (int i = 1; i < a.length; i++) {
			firstSum = firstSum + a[i - 1];
			lastSum = lastSum - a[i];
			if (firstSum == lastSum)
				System.out.print(i + " ");
		}

	}
}
