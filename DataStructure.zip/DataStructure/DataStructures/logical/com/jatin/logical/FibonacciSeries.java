package com.jatin.logical;

import java.util.Scanner;

/**
 * Fibonacci numbers below 100...
 * 
 * @author velishra
 * 
 */
public class FibonacciSeries {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int n = scanner.nextInt();
		int pN = 0;
		int cN = 1;
		while ((cN + pN) < n) {
			int tmp = cN;
			cN = pN + cN;
			System.out.print(cN + " ");
			pN = tmp;
		}
	}
}
