package com.jatin.logical;

import java.util.Scanner;

public class AreaOfCircle {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int noTestCase = scanner.nextInt();
		int[] inputArr = new int[noTestCase];
		for (int i = 0; i < noTestCase; i++) {
			inputArr[i] = scanner.nextInt();
		}
		for (int i = 0; i < noTestCase; i++) {
			System.out.print(areaOfCircle(inputArr[i]));
		}
	}

	private static double areaOfCircle(int k) {
		return (Math.PI * k * k);
	}
}
