package com.jatin.logical;

import java.util.Scanner;

public class DecimalToHexaDecimal {
	static char[] c = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E','F' };

	public static void main(String[] args) {
		int n = new Scanner(System.in).nextInt();
		int[] hd = decimalToHexaDecimal(n);
		hexaToDecimal(hd);
	}

	private static void hexaToDecimal(int[] hd) {
		int result = 0;
		for (int i = 0; i < hd.length; i++) {
			result += Math.pow(16, i) * hd[i];
		}
		System.out.println();
		System.out.println(result);
	}

	private static int[] decimalToHexaDecimal(int n) {
		int[] hexaIndexes = new int[25];
		int index = 0;
		while (n > 0) {
			hexaIndexes[index++] = n % 16;
			n = n / 16;
		}
		for (int i = index - 1; i >= 0; i--) {
			System.out.print(c[hexaIndexes[i]]+"");
		}
		return hexaIndexes;
	}
}
