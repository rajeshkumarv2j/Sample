package com.jatin.logical;

import java.util.Scanner;

/**
 * Write a Java program that prints the numbers from 1 to 50. But for multiples
 * of three print "Fizz" instead of the number and for the multiples of five
 * print "Buzz". For numbers which are multiples of both three and five print
 * "FizzBuzz" This is also one of the classical programming questions, which is
 * asked on any Java programming or technical interviews. This questions is very
 * basic but can be very trick for programmers, who can't code, that's why it is
 * used to differentiate programmers who can do coding and who can't. Here is a
 * sample Java program to solve FizzBuzz problem
 * 
 * @author velishra
 * 
 */
public class FizzBuzz {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int n = scanner.nextInt();
		for (int i = 1; i < n; i++) {
			String d = "";
			if (i % 3 == 0) {
				d = "Fuzz";
			}
			if (i % 5 == 0) {
				d = d + "Buzz";
			}
			System.out.print(d.isEmpty() ? (i + ",") : (d + ","));
		}
	}
}
