package com.jatin.logical;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class RupeeNoToCharacters {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int cases = scanner.nextInt();
		int[] arr = new int[cases];
		for (int i = 0; i < cases; i++) {
			arr[i] = scanner.nextInt();
		}
		for (int i = 0; i < cases; i++) {
			System.out.println(convertNoToDescription(arr[i])+"Ruppes Only!");
		}
	}

	private static String convertNoToDescription(int n) {
		int k = n / 10;
		if (k == 0) {
			return map.get(n);
		}
		if (k >= 1 && k < 10) {
			return getTwoDecimalDesc(n);
		}
		if (k >= 10 && k < 100) {
			return getThreeDecimalDesc(n);
		}
		if (k >= 100 && k < 10000) {
			return getFourDecimalDesc(n);
		}
		return null;
	}

	private static String getFourDecimalDesc(int n) {
		return map.get(n / 1000) + "thousand" + ((n%1000==0)?" ":getThreeDecimalDesc(n % 1000));
	}

	private static String getThreeDecimalDesc(int n) {
		return map.get(n / 100) + "hundreden" + ((n%100==0)?" ":getTwoDecimalDesc(n % 100));
	}

	private static String getTwoDecimalDesc(int n) {
		int k = n / 10;
		int r = n % 10;
		if (k == 1) {
			return map.get((10 + (r)));
		} else {
			return map.get(k * 10) + ((r==0)?"":map.get(r));
		}
	}

	private static Map<Integer, String> map = new HashMap<Integer, String>();
	static {
		map.put(1, " Zero ");
		map.put(1, " One ");
		map.put(2, " Two ");
		map.put(3, " Three ");
		map.put(4, " Four ");
		map.put(5, " Five ");
		map.put(6, " Six ");
		map.put(7, " Seven ");
		map.put(8, " Eight ");
		map.put(9, " Nine ");

		map.put(10, " Ten ");
		map.put(11, " Eleven ");
		map.put(12, " Twelve ");
		map.put(13, " Thirteen ");
		map.put(14, " Foueteen ");
		map.put(15, " Fifteen ");
		map.put(16, " Sixteen ");
		map.put(17, " Seventeen ");
		map.put(18, " Eightteen ");
		map.put(19, " Nineteen ");

		map.put(20, " Twenty ");
		map.put(30, " Thirty ");
		map.put(40, " Fourty ");
		map.put(50, " Fifty ");
		map.put(60, " Sixty ");
		map.put(70, " Seventy ");
		map.put(80, " Eighty ");
		map.put(90, " Ninty ");
	}
}
