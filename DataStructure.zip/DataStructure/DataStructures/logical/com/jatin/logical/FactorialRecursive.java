package com.jatin.logical;

import java.util.Scanner;

public class FactorialRecursive {
	public static int factorial(int i) {
		if (i < 2)
			return 1;
		return i * factorial(i - 1);
	}

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int noOfCases = scanner.nextInt();
		int[] arr = new int[noOfCases];
		for (int i = 0; i < noOfCases; i++) {
			arr[i] = scanner.nextInt();
		}
		for (int i = 0; i < noOfCases; i++) {
			System.out.println(factorial(arr[i]));
		}

	}
}
