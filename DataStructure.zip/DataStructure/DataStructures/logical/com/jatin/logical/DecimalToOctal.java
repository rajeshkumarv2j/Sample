package com.jatin.logical;

import java.util.Scanner;

public class DecimalToOctal {
	public static void main(String[] args) {
		int n = new Scanner(System.in).nextInt();
		int o[] = decimalToOctal(n);
		System.out.println();
		octalToDecimal(o);
	}

	private static void octalToDecimal(int[] o) {
		int result = 0;
		for (int i = 0; i < o.length; i++) {
			result += Math.pow(8, i) * o[i];
		}
		System.out.println(result);
	}

	private static int[] decimalToOctal(int n) {
		int[] octal = new int[25];
		int index = 0;
		while (n > 0) {
			octal[index++] = n % 8;
			n = n / 8;
		}
		for (int i = index - 1; i >= 0; i--) {
			System.out.print(octal[i] + "");
		}
		return octal;
	}
}
