package com.jatin.logical;

public class SwapWithoutOtherVariable {
	public static void main(String[] args) {
		int a=2;
		int b=3;
		/*
		 * 	XOR
		 * 	X	Y OUTPUT
		 * 	o	o	o
		 * 	1	o	1
		 * 	0	1	1
		 * 	1	1	0
		 * 
		 * 
		 * a	0010
		 * b	0011
		 * ---------
		 * a	0001
		 * 
		 * a	0001
		 * b	0011
		 * ---------
		 * b	0010
		 * 
		 * a	0001
		 * b	0010
		 * ---------
		 * a	0011
		 * 	
		 * 
		 * finally..
		 * a	0011
		 * b	0010	
		 */
		
		
		a=a^b;
		b=a^b;
		a=a^b;
		System.out.println(a);
		System.out.println(b);
	}
}
