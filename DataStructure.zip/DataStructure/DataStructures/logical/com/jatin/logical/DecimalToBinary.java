package com.jatin.logical;

import java.util.Scanner;

public class DecimalToBinary {
	public static void main(String[] args) {
		int n = new Scanner(System.in).nextInt();
		int[] d = decimalToBinary(n);
		System.out.println();
		binaryToDecimal(d);
	}

	static int[] decimalToBinary(int n) {
		int[] binary = new int[25];
		int index = 0;
		while (n > 0) {
			binary[index++] = n % 2;
			n = n / 2;
		}
		for (int i = index - 1; i >= 0; i--) {
			System.out.print(binary[i]);
		}
		return binary;
	}

	static void binaryToDecimal(int[] d) {
		int decimal = 0;
		for (int i = 0; i < d.length; i++) {
			decimal += (int) (Math.pow(2, i) * d[i]);
		}
		System.out.println(decimal);
	}
}
