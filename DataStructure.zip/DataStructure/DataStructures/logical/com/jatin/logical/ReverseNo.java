package com.jatin.logical;

import java.util.Scanner;

public class ReverseNo {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int cases = s.nextInt();
		int[] arr = new int[cases];
		for (int i = 0; i < cases; i++) {
			arr[i] = s.nextInt();
		}
		for (int i = 0; i < cases; i++) {
			System.out.println(reverseNo(arr[i]));
			System.out.println(reverseNo1(arr[i]));
		}
	}

	private static String reverseNo(int n) {
		StringBuffer buffer = new StringBuffer();
		while (n != 0) {
			buffer.append(n % 10);
			n = n / 10;
		}
		return buffer.toString();
	}

	private static int reverseNo1(int n) {
		int rn = 0;
		while (n != 0) {
			int tmp = (n % 10);
			n = n / 10;
			rn = (10 * rn) + tmp;
		}
		return rn;
	}
}
