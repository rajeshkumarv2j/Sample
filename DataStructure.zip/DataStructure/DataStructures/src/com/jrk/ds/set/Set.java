package com.jrk.ds.set;

public interface Set {

	void makeSet(int size);

	int find(int x);

	void union(int root1, int root2);

}
