package com.jrk.ds.linkedlist;

public class SingleLL {
	Node head;
	Node tail;

	void insert(int i) {
		Node newNode = new Node(i);
		if (tail == null) {
			head = tail = newNode;
			return;
		}
		tail.next = newNode;
		tail = newNode;
	}

	void reverse() {
		Node p = null, n = null;
		Node c = head;
		while (c != null) {
			n = c.next;
			c.next = p;
			p = c;
			c = n;
		}
		head = p;
	}

	void traverse() {
		Node tmp = head;
		while (tmp != null) {
			System.out.print(tmp.data + " ");
			tmp = tmp.next;
		}
		System.out.println();
	}

	static class Node {
		int data;
		Node next;

		public Node(int data) {
			this.data = data;
		}
	}

	public static void main(String[] args) {
		SingleLL ll = new SingleLL();
		ll.insert(10);
		ll.insert(12);
		ll.insert(14);
		ll.insert(16);
		ll.insert(18);
		ll.insert(20);
		ll.traverse();
		ll.reverse();
		ll.traverse();

	}
}
