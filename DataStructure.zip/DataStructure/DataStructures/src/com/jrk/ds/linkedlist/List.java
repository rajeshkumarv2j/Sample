package com.jrk.ds.linkedlist;

public interface List<E> {

	void add(E e);

	void addFirst(E e);

	void addAfter(E e, E after);

	void delete(E e);

	void deleteFirst();

	void deleteAfter(E after);

	void reverse();

	void reverseRecursionChange(INode<E> node);

	void reverseRecursionPrint(INode<E> node);

	Object getHead();

}
