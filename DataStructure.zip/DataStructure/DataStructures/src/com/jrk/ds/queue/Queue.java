package com.jrk.ds.queue;

public interface Queue<E> {

	void enQueue(E e);

	E deQueue();

	boolean isEmplty();

	E front();

	void travarse();

}
