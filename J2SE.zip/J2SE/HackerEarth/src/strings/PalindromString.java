package strings;

import java.util.Scanner;

public class PalindromString {

	public static void main(String[] args) {
		boolean res = true;
		String s = new Scanner(System.in).next();
		char[] arr = s.toCharArray();
		for(int i=0; i<arr.length/2; i++){
			if(arr[i]!=arr[(arr.length-1)-i]){
				res = false;
				break;
			}
		}
		System.out.println(res?"YES":"NO");
	}
}
