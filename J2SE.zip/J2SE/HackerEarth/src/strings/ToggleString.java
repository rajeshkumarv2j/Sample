package strings;

import java.util.Scanner;

public class ToggleString {
	public static void main(String[] args) {
		String s = new Scanner(System.in).next();
		char[] arry = s.toCharArray();
		for (int i = 0; i < arry.length; i++) {
			int z = (int) s.charAt(i);
			if (65 <= z && z <= 90)
				arry[i] = (char) (z + 32);
			else if (97 <= z && z <= 122)
				arry[i] = (char) (z - 32);
		}
		System.out.println(new String(arry));
	}
}
