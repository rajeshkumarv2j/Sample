package mathoperation;

import java.util.Scanner;

public class FindProduct {
	public static void main1(String[] args) {
		Scanner s = new Scanner(System.in);
		int n = s.nextInt();
		char[] s1 = s.next().toCharArray();//split(" ");
		int n1 = (s1.length<1000)?s1.length:1000;
		for(int i=0; i<n1; i++){
			
		}
		final double val = Math.pow(10, 9)+7;
//		for
	}
	
	public static void main(String[] args) {
		int i=1;
		char c='1';
		int o = Character.getNumericValue(c);
		System.out.println(i==c);
		System.out.println(i==o);
	}
}
