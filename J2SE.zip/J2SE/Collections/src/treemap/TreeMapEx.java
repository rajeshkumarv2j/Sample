package treemap;
 
import java.util.Comparator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;
 
public class TreeMapEx {

	/*
	 * TreeMap is a Red-Black tree based NavigableMap implementation. The map is
	 * sorted according to the natural ordering of its keys, or by a Comparator
	 * provided at map creation time, depending on which constructor is used.
	 * This implementation provides guaranteed log(n) time cost for the
	 * containsKey, get, put and remove operations. Algorithms are adaptations
	 * of those in Cormen, Leiserson, and Rivest's Intr
	 */
	
    public static void main(String a[]){
        TreeMap<String, String> hm = new TreeMap<String, String>();
        //add key-value pair to TreeMap
        hm.put("first", "FIRST INSERTED");
        hm.put("second", "SECOND INSERTED");
        hm.put("third","THIRD INSERTED");
        System.out.println(hm);
        //getting value for the given key from TreeMap
        System.out.println("Value of second: "+hm.get("second"));
        System.out.println("Is TreeMap empty? "+hm.isEmpty());
        hm.remove("third");
        System.out.println(hm);
        System.out.println("Size of the TreeMap: "+hm.size());
        
//        Iterate TreeMap :
        System.out.println(hm);
        Set<String> keys = hm.keySet();
        for(String key: keys){
            System.out.println("Value of "+key+" is: "+hm.get(key));
        }
        
//        How to copy Map content to another TreeMap?
        System.out.println(hm);
        TreeMap<String, String> subMap = new TreeMap<String, String>();
        subMap.put("s1", "S1 VALUE");
        subMap.put("s2", "S2 VALUE");
        hm.putAll(subMap);
        System.out.println(hm);
        
//        How to search a key in TreeMap?
        System.out.println(hm);
        if(hm.containsKey("first")){
            System.out.println("The TreeMap contains key first");
        } else {
            System.out.println("The TreeMap does not contains key first");
        }
        if(hm.containsKey("fifth")){
            System.out.println("The TreeMap contains key fifth");
        } else {
            System.out.println("The TreeMap does not contains key fifth");
        }
        
//        How to search a value in TreeMap?
        if(hm.containsValue("SECOND INSERTED")){
            System.out.println("The TreeMap contains value SECOND INSERTED");
        } else {
            System.out.println("The TreeMap does not contains value SECOND INSERTED");
        }
        if(hm.containsValue("first")){
            System.out.println("The TreeMap contains value first");
        } else {
            System.out.println("The TreeMap does not contains value first");
        }
        
//        How to get all keys from TreeMap?
        Set<String> keys1 = hm.keySet();
        for(String key: keys1){
            System.out.println(key);
        }
        
//        How to get entry set from TreeMap?
        Set<Entry<String, String>> entires = hm.entrySet();
        for(Entry<String,String> ent:entires){
            System.out.println(ent.getKey()+" ==> "+ent.getValue());
        }
        
//      How to delete all elements from TreeMap?  
        hm.clear();
        
//        How to sort keys in TreeMap?
        TreeMap<String, String> hm1 = new TreeMap<String, String>(new MyComp());
        //add key-value pair to TreeMap
        hm1.put("java", "language");
        hm1.put("computer", "machine");
        hm1.put("india","country");
        hm1.put("mango","fruit");
        System.out.println(hm1);
        
//      How to sort keys in TreeMap with user define objects?
      //By using name comparator (String comparison)
        TreeMap<Empl,String> tm = new TreeMap<Empl, String>(new MyNameComp());
        tm.put(new Empl("Ram",3000), "RAM");
        tm.put(new Empl("John",6000), "JOHN");
        tm.put(new Empl("Crish",2000), "CRISH");
        tm.put(new Empl("Tom",2400), "TOM");
        Set<Empl> keys2 = tm.keySet();
        for(Empl key:keys2){
            System.out.println(key+" ==> "+tm.get(key));
        }
        System.out.println("===================================");
        //By using salary comparator (int comparison)
        TreeMap<Empl,String> trmap = new TreeMap<Empl, String>(new MySalaryComp());
        trmap.put(new Empl("Ram",3000), "RAM");
        trmap.put(new Empl("John",6000), "JOHN");
        trmap.put(new Empl("Crish",2000), "CRISH");
        trmap.put(new Empl("Tom",2400), "TOM");
        Set<Empl> ks = trmap.keySet();
        for(Empl key:ks){
            System.out.println(key+" ==> "+trmap.get(key));
        }
        
//        How to get sorted sub-map from TreeMap?
      //the treemap sorts by key
        TreeMap<String, String> mh = new TreeMap<String, String>(new MyCompr());
        //add key-value pair to TreeMap
        mh.put("java", "language");
        mh.put("computer", "machine");
        mh.put("india","country");
        mh.put("mango","fruit");
        mh.put("game","cricket");
        System.out.println("TreeMap Entries:");
        System.out.println(mh);
        Map<String, String> subMap1 = mh.subMap("game", "java");
        System.out.println("Sub-Map enties:");
        System.out.println(subMap1);
        //how to get lower boundary also part of sub-map
        Map<String, String> subMap2 = mh.subMap("game", true, "java", true);
        System.out.println("Sub-Map enties:");
        System.out.println(subMap2);
        //how to omit upper boundary in the sub-map
        Map<String, String> subMap3 = mh.subMap("game", false, "java", true);
        System.out.println("Sub-Map enties:");
        System.out.println(subMap3);
        
//      How to get first key element from TreeMap (Sorted Map)?
      //By using salary comparator (int comparison)
        TreeMap<Emp,String> trmap1 = new TreeMap<Emp, String>(new MySalaryCompr());
        trmap1.put(new Emp("Ram",3000), "RAM");
        trmap1.put(new Emp("John",6000), "JOHN");
        trmap1.put(new Emp("Crish",2000), "CRISH");
        trmap1.put(new Emp("Tom",2400), "TOM");
        Emp em = trmap1.firstKey();
        System.out.println("Highest salary emp: "+em);
        Entry<Emp,String> ent = trmap1.firstEntry();
        System.out.println("Entry set values: ");
        System.out.println(ent.getKey()+" ==> "+ent.getValue());
        
//        How to get last key element from TreeMap (Sorted Map)?
        Emp em1 = trmap1.lastKey();
        System.out.println("Least salary emp: "+em1);
        Entry<Emp,String> entr = trmap1.lastEntry();
        System.out.println("Entry set values: ");
        System.out.println(entr.getKey()+" ==> "+entr.getValue());
        
//      How to reverse sorted map in a TreeMap?
        Map<String, String> rm = hm.descendingMap();
        System.out.println("Reverse Map Content: ");
        System.out.println(rm);
        
//        How to reverse sorted keys in a TreeMap?
        Set<String> rk = hm.descendingKeySet();
        System.out.println("Reverse Keys Content: ");
        System.out.println(rk);
        
        
        
        
    }
}

class MyCompr implements Comparator<String>{
	 
    @Override
    public int compare(String str1, String str2) {
        return str1.compareTo(str2);
    }
     
}

class MyComp implements Comparator<String>{
	 
    @Override
    public int compare(String str1, String str2) {
        return str1.compareTo(str2);
    }
     
}
class MyNameComp implements Comparator<Empl>{
	 
    @Override
    public int compare(Empl e1, Empl e2) {
        return e1.getName().compareTo(e2.getName());
    }
}
 
class MySalaryComp implements Comparator<Empl>{
 
    @Override
    public int compare(Empl e1, Empl e2) {
        if(e1.getSalary() > e2.getSalary()){
            return 1;
        } else {
            return -1;
        }
    }
}
 
class Empl{
     
    private String name;
    private int salary;
     
    public Empl(String n, int s){
        this.name = n;
        this.salary = s;
    }
     
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public int getSalary() {
        return salary;
    }
    public void setSalary(int salary) {
        this.salary = salary;
    }
    public String toString(){
        return "Name: "+this.name+"-- Salary: "+this.salary;
    }
}
class MySalaryCompr implements Comparator<Emp>{
	 
    @Override
    public int compare(Emp e1, Emp e2) {
        if(e1.getSalary() < e2.getSalary()){
            return 1;
        } else {
            return -1;
        }
    }
}
 
class Emp{
     
    private String name;
    private int salary;
     
    public Emp(String n, int s){
        this.name = n;
        this.salary = s;
    }
     
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public int getSalary() {
        return salary;
    }
    public void setSalary(int salary) {
        this.salary = salary;
    }
    public String toString(){
        return "Name: "+this.name+"-- Salary: "+this.salary;
    }
}