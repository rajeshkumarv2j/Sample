package arraylist;

import java.util.ArrayList;
import java.util.Iterator;

public class RemoveDuplicates {
	public static void main(String[] args) {
		ArrayList<String> al = new ArrayList<String>();
		al.add("hi");
		al.add("XYZ");
		al.add("123");
		al.add("hi");
		al.add("XYZ");
		al.add("123");
		al.add("098");
		System.out.println(al);
		for(int i=0; i<al.size(); i++){
			if (al.indexOf(al.get(i)) != al.lastIndexOf(al.get(i))) {
				al.remove(al.lastIndexOf(al.get(i)));
			}
		}
		System.out.println(al);
	}
}
