package linkedlist;
 
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
 
public class LinkedListEx {

	/*
	 * LinkedList is a linked list implementation of the List interface.
	 * Implements all optional list operations, and permits all elements
	 * (including null). In addition to implementing the List interface, the
	 * LinkedList class provides uniformly named methods to get, remove and
	 * insert an element at the beginning and end of the list. These operations
	 * allow linked lists to be used as a stack, queue, or double-ended queue.
	 */
    public static void main(String a[]){
         
        LinkedList<String> arrl = new LinkedList<String>();
        arrl.add("Orange");
        arrl.add("Apple");
        arrl.add("Grape");
        arrl.add("Banana");
        System.out.println(arrl);
        System.out.println("Size of the linked list: "+arrl.size());
        System.out.println("Is LinkedList empty? "+arrl.isEmpty());
        System.out.println("Does LinkedList contains 'Grape'? "+arrl.contains("Grape"));
        
        Iterator<String> itr = arrl.iterator();
        while(itr.hasNext()){
            System.out.println(itr.next());
        }
        System.out.println("Actual LinkedList:"+arrl);
		LinkedList<String> copy = (LinkedList<String>) arrl.clone();
		System.out.println("Cloned LinkedList:"+copy);
		
		LinkedList<String> copyByCon = new LinkedList<String>(arrl); 
		System.out.println(copyByCon+"...................");
		
		
		List<String> list = new ArrayList<String>();
        list.add("one");
        list.add("two");
        arrl.addAll(list);
        System.out.println("After Copy: "+arrl);
        
//copying all content of LinkedList to an array
        System.out.println("Actual LinkedList:"+arrl);
		String[] strArr = new String[arrl.size()];
		arrl.toArray(strArr);
		System.out.println("Created Array content:");
		for(String str:strArr){
			System.out.println(str);
		}
	
//getting LinkedList content based on range of index
		System.out.println("Actual LinkedList:"+arrl);
        List<String> list1 = arrl.subList(2, 4);
        System.out.println("Sub List: "+list1);
        
//        how to reverse LinkedList content?
        Collections.reverse(list);
        System.out.println("Results after reverse operation:");
        for(String str: list){
            System.out.println(str);
        }
        
//         shuffle elements in the LinkedList. ?
        Collections.shuffle(list);
		System.out.println("Results after shuffle operation:");
		for(String str: list){
			System.out.println(str);
		}
		
		Collections.shuffle(list);
		System.out.println("Results after shuffle operation:");
		for(String str: list){
			System.out.println(str);
		}
        
//		How to swap two elements in ll?

		list.add("First");
		list.add("Second");
		list.add("Third");
		list.add("Random");
		Collections.swap(list, 2, 5);
		System.out.println("Results after swap operation:");
		for(String str: list){
			System.out.println(str);
		}
	
		
//		addFirst() : Append element to the first of the list
//		offerFirst() : Append element to the first of the list
		
		arrl.clear();
		arrl.add("First");
		arrl.add("Second");
		arrl.add("Third");
		arrl.add("Random");
		System.out.println(arrl);
		System.out.println("Adding element at first position...");
		arrl.addFirst("I am first");
		System.out.println(arrl);
		System.out.println("Adding element at first position...");
		arrl.offerFirst("I am first - 2");
		System.out.println(arrl);
		
		/*addLast(): Appends the specified element to the end of this list.
		offerLast(): Inserts the specified element at the end of this list.
		offer(): Adds the specified element as the tail (last element) of this list.*/
		
		System.out.println(arrl);
        System.out.println("Adding element at last position...");
        arrl.addLast("I am last");
        System.out.println(arrl);
        System.out.println("Adding element at last position...");
        arrl.offerLast("I am last - 1");
        System.out.println(arrl);
        System.out.println("Adding element at last position...");
        arrl.offer("I am last - 2");
        System.out.println(arrl);
        
        /*element(): Retrieves, but does not remove, the head (first element) of this list.
        getFirst(): Returns the first element in this list.
        peek(): Retrieves, but does not remove, the head (first element) of this list.
        peekFirst(): Retrieves, but does not remove, the first element of this list, or returns null if this list is empty.
        */
        System.out.println("First Element: "+arrl.element());
        System.out.println("First Element: "+arrl.getFirst());
        System.out.println("First Element: "+arrl.peek());
        System.out.println("First Element: "+arrl.peekFirst());
        
        /*
        getLast(): Returns the last element in this list.
        peekLast(): Retrieves, but does not remove, the last element of this list, or returns null if this list is empty.*/
        
        System.out.println("Last Element: "+arrl.getLast());
		System.out.println("Last Element: "+arrl.peekLast());
		
//		How to iterate through LinkedList in reverse order?
		Iterator<String> itr1 = arrl.descendingIterator();
        while(itr1.hasNext()){
            System.out.println(itr1.next());
        }
		
  /*push(): Pushes an element onto the stack represented by this list.
        pop(): Pops an element from the stack represented by this list.
        */
        System.out.println(arrl);
        arrl.push("push element");
        System.out.println("After push operation:");
        System.out.println(arrl);
        arrl.pop();
        System.out.println("After pop operation:");
        System.out.println(arrl);
     //OUTPUT:
        //[I am first - 2, I am first, First, Second, Third, Random, I am last, I am last - 1, I am last - 2]
//        After push operation:
  //      	[push element, I am first - 2, I am first, First, Second, Third, Random, I am last, I am last - 1, I am last - 2]
    //    	After pop operation:
      //  	[I am first - 2, I am first, First, Second, Third, Random, I am last, I am last - 1, I am last - 2]

        
        
        /*remove(): Retrieves and removes the head (first element) of this list.
        remove(index): Removes the element at the specified position in this list.
        remove(object): Removes the first occurrence of the specified element from this list, if it is present.
        removeFirst(): Removes and returns the first element from this list.
        removeFirstOccurrence(object): Removes the first occurrence of the specified element in this list (when traversing the list from head to tail).
        removeLast(): Removes and returns the last element from this list.
        removeLastOccurrence(object): Removes the last occurrence of the specified element in this list (when traversing the list from head to tail).*/
        arrl.clear();
        arrl.add("First");
        arrl.add("Second");
        arrl.add("Third");
        arrl.add("Random");
        arrl.add("four");
        arrl.add("five");
        arrl.add("six");
        arrl.add("seven");
        arrl.add("eight");
        arrl.add("nine");
        System.out.println(arrl);
        System.out.println("Remov() method:"+arrl.remove());
        System.out.println("After remove() method call:");
        System.out.println(arrl);
        System.out.println("remove(index) method:"+arrl.remove(2));
        System.out.println("After remove(index) method call:");
        System.out.println(arrl);
        System.out.println("Remov(object) method:"+arrl.remove("six"));
        System.out.println("After remove(object) method call:");
        System.out.println(arrl);
        System.out.println("removeFirst() method:"+arrl.removeFirst());
        System.out.println("After removeFirst() method call:");
        System.out.println(arrl);
        System.out.println("removeFirstOccurrence() method:"
                            +arrl.removeFirstOccurrence("eight"));
        System.out.println("After removeFirstOccurrence() method call:");
        System.out.println(arrl);
        System.out.println("removeLast() method:"+arrl.removeLast());
        System.out.println("After removeLast() method call:");
        System.out.println(arrl);
        System.out.println("removeLastOccurrence() method:"
                            +arrl.removeLastOccurrence("five"));
        System.out.println("After removeLastOccurrence() method call:");
        System.out.println(arrl);
//        OUTPUT:
        /*[First, Second, Third, Random, four, five, six, seven, eight, nine]
         Remov() method:First
         After remove() method call:
         [Second, Third, Random, four, five, six, seven, eight, nine]
         remove(index) method:Random
         After remove(index) method call:
         [Second, Third, four, five, six, seven, eight, nine]
         Remov(object) method:true
         After remove(object) method call:
         [Second, Third, four, five, seven, eight, nine]
         removeFirst() method:Second
         After removeFirst() method call:
         [Third, four, five, seven, eight, nine]
         removeFirstOccurrence() method:true
         After removeFirstOccurrence() method call:
         [Third, four, five, seven, nine]
         removeLast() method:nine
         After removeLast() method call:
         [Third, four, five, seven]
         removeLastOccurrence() method:true
         After removeLastOccurrence() method call:
         [Third, four, seven]*/
        
        
    }
}