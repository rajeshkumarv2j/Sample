package tc;

import java.util.ArrayList;
import java.util.List;

public class ArrayListTC {

	private static final int TEST_SIZE = 10000000;
	private int[] mNumbers = new int[TEST_SIZE];

	// Lists have to use wrapper objects
	private List<Integer> mNumberList = new ArrayList<Integer>();

	public ArrayListTC() {
		System.out.println("Creating myApp");
		System.out.println("Initializing primitive array...");
		initializeArray();
		System.out.println("Initialization of primitive array completed.");
		System.out.println("Initializing ArrayList.");
		initializeArrayList();
		System.out.println("Initialization of ArrayList completed.");
	}

	private void initializeArray() {
		for (int i = 0; i < TEST_SIZE; i++) {
			mNumbers[i] = i;
		}
	}

	private void initializeArrayList() {
		for (int i = 0; i < TEST_SIZE; i++) {
			mNumberList.add(i);
		}
	}

	public void methodToTimeArray() {
		for (int i = 0; i < TEST_SIZE; i++) {
			mNumbers[i] = (i * 2);
		}
	}

	public void methodToTimeArrayList() {

		for (int i = 0; i < TEST_SIZE; i++) {
			mNumberList.set(i, i * 2);
		}
	}

	public static void main(String[] args) {

		ArrayListTC myApp = new ArrayListTC();
		long startTime = System.nanoTime();
		System.out.println("Start time of test: " + startTime + " ms");

		// Comment out one of the following methods in order to test the other:

//		myApp.methodToTimeArray();
		 myApp.methodToTimeArrayList();

		long endTime = System.nanoTime();
		System.out.println("End time of test: " + endTime + " ms");

		long duration = (endTime - startTime);
		System.out.println("Time: " + (double) duration / 1000000000.0
				+ " Seconds");

	}
}