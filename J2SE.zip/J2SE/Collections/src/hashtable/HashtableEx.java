package hashtable;
 
import java.util.Collections;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;
 
public class HashtableEx {

	/*
	 * Hashtable class implements a hashtable, which maps keys to values. Any
	 * non-null object can be used as a key or as a value. To successfully store
	 * and retrieve objects from a hashtable, the objects used as keys must
	 * implement the hashCode method and the equals method.
	 */
    public static void main(String a[]){
        //Create hashtable instance
        Hashtable<String,String> hm = new Hashtable<String,String>();
        //add key-value pair to hashtable
        hm.put("first", "FIRST INSERTED");
        hm.put("second", "SECOND INSERTED");
        hm.put("third","THIRD INSERTED");
        hm.put("", "");
        hm.put(" ", "");
        hm.put("  ", "Raj");
        hm.put("", "Raj");
        System.out.println(hm);
        //getting value for the given key from hashtable
        System.out.println("Value of key 'second': "+hm.get("second"));
        System.out.println("Is Hashtable empty? "+hm.isEmpty());
        hm.remove("third");
        System.out.println(hm);
        System.out.println("Size of the Hashtable: "+hm.size());
        
        System.out.println(hm);
        Set<String> keys = hm.keySet();
        for(String key: keys){
            System.out.println("Value of "+key+" is: "+hm.get(key));
        }
        
//      Copy another hash map in to hash table
        System.out.println(hm);
		HashMap<String, String> subMap = new HashMap<String, String>();
		subMap.put("s1", "S1 VALUE");
		subMap.put("s2", "S2 VALUE");
		hm.putAll(subMap);
		System.out.println(hm);
        
//		how to search a key from the Hashtable?
		System.out.println(hm);
        if(hm.containsKey("first")){
            System.out.println("The Hashtable contains key first");
        } else {
            System.out.println("The Hashtable does not contains key first");
        }
        if(hm.containsKey("fifth")){
            System.out.println("The Hashtable contains key fifth");
        } else {
            System.out.println("The Hashtable does not contains key fifth");
        }
        
//      search a value from the Hashtable.?
        if(hm.containsValue("SECOND INSERTED")){
            System.out.println("The Hashtable contains value SECOND INSERTED");
        } else {
            System.out.println("The Hashtable does not contains value SECOND INSERTED");
        }
        if(hm.containsValue("first")){
            System.out.println("The Hashtable contains value first");
        } else {
            System.out.println("The Hashtable does not contains value first");
        }
        
//      how to get key-value pair as Entry object. ? 
        Set<Entry<String, String>> entires = hm.entrySet();
		for(Entry<String,String> ent:entires){
			System.out.println(ent.getKey()+" ==> "+ent.getValue());
		}
		
//		how to delete all key-values at one call from Hashtable.?
		System.out.println(hm);
        System.out.println("Clearing Hashtable:");
        hm.clear();
        System.out.println("Content After clear:");
        System.out.println(hm);
        
        
//      how to get all keys as Enumeration object?
        hm.put("first", "FIRST INSERTED");
        hm.put("second", "SECOND INSERTED");
        hm.put("third","THIRD INSERTED");
        Enumeration<String> keys1 = hm.keys();
        while(keys1.hasMoreElements()){
            String key = keys1.nextElement();
            System.out.println("Value of "+key+" is: "+hm.get(key));
        }
        
//        How to add userdefined objects to Hashtable?
        Hashtable<Emp,String> tm = new Hashtable<Emp, String>();
        tm.put(new Emp(134,"Ram",3000), "RAM");
        tm.put(new Emp(235,"John",6000), "JOHN");
        tm.put(new Emp(876,"Crish",2000), "CRISH");
        tm.put(new Emp(512,"Tom",2400), "TOM");
        tm.put(new Emp(512,"Tom",2400), "TOM");
        System.out.println("Fecthing value by creating new key:");
         
        Emp e = new Emp(512,"Tom",2400);
        System.out.println(e+" ==> "+tm.get(e));
     
//      *  How to sort HashTable with keys?
    /*
	 *	HashTable wont maitain order.
	 * so we cant sort HashTable directly.
	 * Only option with the help of TrreMap we can do.
	 * 
	 * 1st approach :
	 * we have to pass Hashtable to TreeMap through constructor.
	 * So that it will be autmatically ordered
	 * As TreeMap maintains auto sorting order.
	 * But TreeMap accepts only Comparable implemented objects.
	 * 
        	
        	*/
        /*Map<Emp, String> sortedMap = new TreeMap<Emp, String>(tm);
        Set<Entry<Emp, String>> entries = sortedMap.entrySet();
        for (Entry<Emp, String> entry : entries) {
			System.out.println("key.."+entry.getKey()+"value..."+entry.getValue());
		}*/
        
        
        /*
         * 2nd Approach :
         * instead of our object implementing comparable interface.
         * pass an anounimus comparator to treemap constructor
         * and add hastable to trremap.
         * 
         */
        Map<Emp, String> sortedMap = new TreeMap<Emp, String>(new Comparator<Emp>() {
        	@Override
        	public int compare(Emp o1, Emp o2) {
        		return ((Integer)o1.getId()).compareTo(((Integer)o2.getId()));
        	}
		});
        Set<Entry<Emp, String>> entries1 = tm.entrySet();
        for (Entry<Emp, String> entry : entries1) {
			System.out.println("key.."+entry.getKey()+"value..."+entry.getValue());
		}
        sortedMap.putAll(tm);
        Set<Entry<Emp, String>> entries = sortedMap.entrySet();
        for (Entry<Emp, String> entry : entries) {
			System.out.println("key.."+entry.getKey()+"value..."+entry.getValue());
		}
        System.out.println(sortedMap);
        
        
//      *  How to sort HashTable with values?
        /*
         * 1st Approach But Bad approach...
         */
        Hashtable<Emp,String> ht1 = new Hashtable<Emp, String>();
        ht1.put(new Emp(134,"Ram",3000), "RAM");
        ht1.put(new Emp(235,"John",6000), "JOHN");
        ht1.put(new Emp(876,"Crish",2000), "CRISH");
        ht1.put(new Emp(512,"Tom",2400), "TOM");
        ht1.put(new Emp(512,"Tom",2400), "TOM");
        
        Map<Emp, String> sortedByValuesMap = new LinkedHashMap<Emp, String>();
        List<String> listToSort = new LinkedList<String>(ht1.values());
        Collections.sort(listToSort);
        
        Set<Entry<Emp, String>> entries2 = ht1.entrySet();
        
        for(String sortedValue : listToSort){
	        for (Entry<Emp, String> entry : entries2) {
	        	if(entry.getValue().equals(sortedValue)){
	        		sortedByValuesMap.put(entry.getKey(), entry.getValue());
	        		break;
	        	}
			}
        }
        
        Set<Entry<Emp, String>> all = sortedByValuesMap.entrySet();
        for (Entry<Emp, String> entry : all) {
			System.out.println("key.."+entry.getKey()+"value..."+entry.getValue());
		}
        
        
        /*
         * 2nd approach : Good Approach.
         * 
         */
        Hashtable<Emp,String> needToSortByValue = new Hashtable<Emp, String>();
        needToSortByValue.put(new Emp(134,"Ram",3000), "RAM");
        needToSortByValue.put(new Emp(235,"John",6000), "JOHN");
        needToSortByValue.put(new Emp(876,"Crish",2000), "CRISH");
        needToSortByValue.put(new Emp(512,"Tom",2400), "TOM");
        needToSortByValue.put(new Emp(512,"Tom",2400), "TOM");
        
        List<Entry<Emp, String>> entries3 = new LinkedList<Map.Entry<Emp,String>>(needToSortByValue.entrySet());
        Collections.sort(entries3, new Comparator<Entry<Emp, String>>() {
        	@Override
        	public int compare(Entry<Emp, String> o1, Entry<Emp, String> o2) {
        		return o1.getValue().compareTo(o2.getValue());
        	}
		});
        Map<Emp, String> resultedSortedByValuesMap = new LinkedHashMap<Emp, String>();
        for(Entry<Emp, String> entry : entries3){
        	resultedSortedByValuesMap.put(entry.getKey(), entry.getValue());
        }
        Set<Entry<Emp, String>> all1 = resultedSortedByValuesMap.entrySet();
        for (Entry<Emp, String> entry : all1) {
			System.out.println("key.."+entry.getKey()+"value..."+entry.getValue());
		}
    }
}

class Emp //implements Comparable<Emp>{
{
    private String name;
    private int salary;
    private int id;
     
    public Emp(int id, String n, int s){
        this.id = id;
        this.name = n;
        this.salary = s;
    }
     
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public int getSalary() {
        return salary;
    }
    public void setSalary(int salary) {
        this.salary = salary;
    }
    public String toString(){
        return "Id: "+this.id+" -- Name: "+this.name+" -- Salary: "+this.salary;
    }
 
    public void setId(int id) {
        this.id = id;
    }
 
    public int getId() {
        return id;
    }
     
    @Override
    public int hashCode() {
        System.out.println("In hashcode");
        return this.getId();
    }
     
    @Override
    public boolean equals(Object obj) {
        Emp e = null;
        if(obj instanceof Emp){
            e = (Emp) obj;
        }
        System.out.println("In equals");
        if(this.getId() == e.getId()){
            return true;
        } else {
            return false;
        }
    }

/*	@Override
	public int compareTo(Emp o) {
		return ((Integer)this.getId()).compareTo(((Integer)o.id));
	}*/
	
	
}