package linkedhashmap;
 
import java.util.LinkedHashMap;
import java.util.Set;
 
public class LinkedHashMapEx {

	/*
	 * LinkedHashMap is a combination of Hash table and linked list implementation of the Map interface, with predictable iteration order.
It maintains a doubly-linked list running through all of its entries.
The iteration order is normally the order in which keys were inserted into the map ie insertion order.
The insertion order is not affected if a key is re-inserted into the map.
	 */
	
	public static void main(String a[]){
        
        LinkedHashMap<String, String> lhm = new LinkedHashMap<String, String>();
        lhm.put("one", "This is first element");
        lhm.put("two", "This is second element");
        lhm.put("four", "this element inserted at 3rd position");
        System.out.println(lhm);
        System.out.println("Getting value for key 'one': "+lhm.get("one"));
        System.out.println("Size of the map: "+lhm.size());
        System.out.println("Is map empty? "+lhm.isEmpty());
        System.out.println("Contains key 'two'? "+lhm.containsKey("two"));
        System.out.println("Contains value 'This is first element'? "
                            +lhm.containsValue("This is first element"));
        System.out.println("delete element 'one': "+lhm.remove("one"));
        System.out.println(lhm);
        
//        How to iterate through LinkedHashMap?
        Set<String> keys = lhm.keySet();
        for(String k:keys){
            System.out.println(k+" -- "+lhm.get(k));
        }
        
//        How to check whether the value exists or not in a LinkedHashMap?
        System.out.println("Map contains value 'This is first element'? "
                +lhm.containsValue("This is first element"));
        
//        How to Delete all elements in LinkedHashMap?
        System.out.println(lhm);
        lhm.clear();
        System.out.println(lhm);
        
//        How to eliminate duplicate user defined objects as a key from LinkedHashMap?
        LinkedHashMap<Price, String> hm = new LinkedHashMap<Price, String>();
        hm.put(new Price("Banana", 20), "Banana");
        hm.put(new Price("Apple", 40), "Apple");
        hm.put(new Price("Orange", 30), "Orange");
        printMap(hm);
        Price key = new Price("Banana", 20);
        System.out.println("Adding duplicate key...");
        hm.put(key, "Grape");
        System.out.println("After adding dulicate key:");
        printMap(hm);
        
//      How to find user defined objects as a key from LinkedHashMap?
        System.out.println("Does key available? "+hm.containsKey(key));
        
//      How to delete user defined objects as a key from LinkedHashMap?
        hm.remove(key);
        
//        
        
        
    }
     
    public static void printMap(LinkedHashMap<Price, String> map){
         
        Set<Price> keys = map.keySet();
        for(Price p:keys){
            System.out.println(p+"==>"+map.get(p));
        }
    }
}
 
class Price{
     
    private String item;
    private int price;
     
    public Price(String itm, int pr){
        this.item = itm;
        this.price = pr;
    }
     
    public int hashCode(){
        int hashcode = 0;
        hashcode = price*20;
        hashcode += item.hashCode();
        return hashcode;
    }
     
    public boolean equals(Object obj){
        if (obj instanceof Price) {
            Price pp = (Price) obj;
            return (pp.item.equals(this.item) && pp.price == this.price);
        } else {
            return false;
        }
    }
     
    public String getItem() {
        return item;
    }
    public void setItem(String item) {
        this.item = item;
    }
    public int getPrice() {
        return price;
    }
    public void setPrice(int price) {
        this.price = price;
    }
     
    public String toString(){
        return "item: "+item+"  price: "+price;
    }
}