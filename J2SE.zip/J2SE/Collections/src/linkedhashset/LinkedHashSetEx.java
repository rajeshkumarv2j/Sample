 package linkedhashset;
 
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
 
public class LinkedHashSetEx {

	/*
	 * 
	 * The LinkedHashSet is Hash table and linked list implementation of the Set
	 * interface, with predictable iteration order. This implementation differs
	 * from HashSet in that it maintains a doubly-linked list running through
	 * all of its entries. This linked list defines the iteration ordering,
	 * which is the order in which elements were inserted into the set
	 * (insertion-order). Note that insertion order is not affected if an
	 * element is re-inserted into the set. This class provides all of the
	 * optional Set operations, and permits null elements.
	 */

public static void main(String a[]){
		
		LinkedHashSet<String> lhs = new LinkedHashSet<String>();
		//add elements to HashSet
		lhs.add("first");
		lhs.add("second");
		lhs.add("third");
		System.out.println(lhs);
		System.out.println("LinkedHashSet size: "+lhs.size());
		System.out.println("Is LinkedHashSet emplty? : "+lhs.isEmpty());
		
//		clear it
		lhs.clear();
		System.out.println(lhs);
		
        //add collection elements to HashSet
        lhs.add("first");
        lhs.add("second");
        lhs.add("third");
        System.out.println(lhs);
        HashSet<String> subSet = new HashSet<String>();
        subSet.add("s1");
        subSet.add("s2");
        lhs.addAll(subSet);
        System.out.println("LinkedHashSet content after adding another collection:");
        System.out.println(lhs);
        
//        iteatate the LHS
        Iterator<String> itr = lhs.iterator();
		while(itr.hasNext()){
			System.out.println(itr.next());
		}
		
//		Retain All
		lhs.clear();
		lhs.add("first");
        lhs.add("second");
        lhs.add("third");
        lhs.add("apple");
        lhs.add("rat");
        System.out.println(lhs);
        LinkedHashSet<String> subSet1 = new LinkedHashSet<String>();
        subSet1.add("rat");
        subSet1.add("second");
        subSet1.add("first");
        lhs.retainAll(subSet1);
        System.out.println("LinkedHashSet content:");
        System.out.println(lhs);
        
//      how to copy content of LinkedHashSet elements to an array object.?
        System.out.println("LinkedHashSet content: ");
		System.out.println(lhs);
		String[] strArr = new String[lhs.size()];
		lhs.toArray(strArr);
		System.out.println("Copied array content:");
		for(String str:strArr){
			System.out.println(str);
		}
//		How to remove a element.?
		System.out.println(lhs);
        lhs.remove("second");
        System.out.println("Elements after deleting an element:");
        System.out.println(lhs);
        System.out.println("Does set contains 'first'? "+lhs.contains("first"));
        
        
	}
}