package collections;
 
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Deque;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.Vector;
 
public class CollectionsEx {

	/*
	 * The Collections class consists of static methods that exclusively
	 * operates on collections and returns collections. It contains polymorphic
	 * algorithms that operate on collections, "wrappers", which return a new
	 * collection backed by a specified collection, and a few other odds and
	 * ends. The methods of Collections class all throw a NullPointerException
	 * if the collections or class objects provided to them are null.
	 */
	
	 public static void main(String a[]){
         
//	How to add all elements to the given collection object?
        List<String> myList = new ArrayList<String>();
        myList.add("java");
        myList.add("c");
        myList.add("c++");
        System.out.println("Initial list:"+myList);
        Collections.addAll(myList, "perl","php");
        System.out.println("After adding elements:"+myList);
        String[] strArr = {".Net", "unix"};
        Collections.addAll(myList, strArr);
        System.out.println("After adding array:"+myList);
        
//        Write an example for Collections.asLifoQueue() method.?
        Deque<String> dq = new ArrayDeque<String>(5);
        dq.add("java");
        dq.add("c");
        dq.add("c++");
        dq.add("unix");
        dq.add("perl");        
        Queue<String> q = Collections.asLifoQueue(dq);
        System.out.println("returned queue is: "+q);
        
//        How to search user defined object from a List by using binary search using comparator?
        List<Emp> empList = new ArrayList<Emp>();
        empList.add(new Emp(12,"Dinesh",50000));
        empList.add(new Emp(146,"Tom",20000));
        empList.add(new Emp(201,"John",40000));
        empList.add(new Emp(302,"Krish",44500));
        empList.add(new Emp(543,"Abdul",10000));
         
        Emp searchKey = new Emp(201,"John",40000);
        int index = Collections.binarySearch(empList, searchKey, new EmpComp());
        System.out.println("Index of the searched key: "+index);
        
//        Write an example for Collections.checkedCollection() method.?
        List myList1 = new ArrayList();
        myList1.add("one");
        myList1.add("two");
        myList1.add("three");
        myList1.add("four");
        Collection chkList = Collections.checkedCollection(myList1, String.class);
        System.out.println("Checked list content: "+chkList);
        //you can add any type of elements to myList1 object
        myList1.add(10);
        //you cannot add any type of elements to chkList object, doing so
        //throws ClassCastException
//        chkList.add(10); //throws ClassCastException
        
//        Write an example for Collections.checkedMap() method?
        Map myMap = new HashMap();
        myMap.put("one", 1);
        myMap.put("two", 2);
        myMap.put("three", 3);
        myMap.put("four", 4);
        Map chkMap = Collections.checkedMap(myMap, String.class, Integer.class);
        System.out.println("Checked map content: "+chkMap);
        //you can add any type of elements to myMap object
        myMap.put(10, "ten");
        //you cannot add any type of elements to chkMap object, doing so
        //throws ClassCastException
//        chkMap.put(10, "ten"); //throws ClassCastException
        
//        How to check there in no common element between two list objects by using Collections.disjoint() method?
        List<String> sl = new ArrayList<String>();
		sl.add("apple");
		sl.add("java");
		sl.add("c++");
		sl.add("unix");
		sl.add("orange");
		sl.add("airtel");
		
		List<String> tl = new ArrayList<String>();
		tl.add("job");
		tl.add("oracle");
		tl.add("jungle");
		tl.add("cricket");
		boolean isCommon = Collections.disjoint(sl,tl);
		System.out.println("Does not found any common elements? "+isCommon);
		tl.add("java");
		isCommon = Collections.disjoint(sl,tl);
		System.out.println("Does not found any common elements? "+isCommon);
		
//		**** How to create empty list using Collections class?
		List<String> myEmptyList = Collections.<String>emptyList();
        System.out.println("Empty list: "+myEmptyList);
        
//		**** How to create empty set using Collections class?
		Set<String> myEmptySet = Collections.<String>emptySet();
        System.out.println("Empty set: "+myEmptySet);
        
//		**** How to create empty list using Collections class?
		Map<String, String> myEmptyMap = Collections.<String, String>emptyMap();
        System.out.println("Empty map: "+myEmptyMap);
        
//        How to Enumeration for ArrayList object?
        List<String> ls = new ArrayList<String>();
        ls.add("one");
        ls.add("two");
        ls.add("three");
        ls.add("four");
        Enumeration<String> enm = Collections.enumeration(ls);
        while(enm.hasMoreElements()){
            System.out.println(enm.nextElement());
        }
        
//        How to fill or replace elements of a List or ArrayList?
        List<String> ll = new ArrayList<String>();
        ll.add("one");
        ll.add("two");
        ll.add("three");
        ll.add("four");
        System.out.println("Original List: "+ll);
        Collections.fill(ll, "TEMP_STRING");
        System.out.println("After fill: "+ll);
        
//        How to find repeated element count (frequency) of a given collection?
        ll.clear();
        ll.add("one");
        ll.add("two");
        ll.add("three");
        ll.add("four");
        ll.add("two");
        ll.add("three");
        ll.add("two");
        ll.add("one");
        System.out.println("Actual list: "+ll);
        System.out.println("Frequency of 'one': "+Collections.frequency(ll, "one"));
        System.out.println("Frequency of 'three': "+Collections.frequency(ll, "three"));
        System.out.println("Frequency of 'two': "+Collections.frequency(ll, "two"));
       
//      How to convert Enumeration to List object?
        Vector<String> vct = new Vector<String>();
        vct.add("one");
        vct.add("two");
        vct.add("three");
        vct.add("four");
        vct.add("five");
        Enumeration<String> enm1 = vct.elements();
        List<String> ll1 = Collections.list(enm1);
        System.out.println("List elements: "+ll1);
        
//        How to get index of a sub list from another list?
        List<String> list = new ArrayList<String>();
        list.add("java");
        list.add("c");
        list.add("c++");
        list.add("unix");
        list.add("perl");
        list.add("php");
        list.add("javascript");
        list.add("ruby");
        list.add(".net");
        list.add("jdbc");
        list.add("servlets");
        List<String> subList = new ArrayList<String>();
        subList.add("php");
        subList.add("javascript");
        subList.add("ruby");
        System.out.println("Index of sublist: "+Collections.indexOfSubList(list, subList));
        
//        How to get last index of a sub list from another list?
        list.clear();
        list.add("java");
        list.add("c");
        list.add("c++");
        list.add("unix");
        list.add("perl");
        list.add("php");
        list.add("javascript");
        list.add("ruby");
        list.add(".net");
        list.add("jdbc");
        list.add("php");
        list.add("javascript");
        list.add("ruby");
        list.add("servlets");
        subList.clear();
        subList.add("php");
        subList.add("javascript");
        subList.add("ruby");
        System.out.println("Last index of sublist: "
                    +Collections.lastIndexOfSubList(list, subList));
        
//        How to get max element from the given list?
        List<Integer> li = new ArrayList<Integer>();
        li.add(23);
        li.add(44);
        li.add(12);
        li.add(45);
        li.add(2);
        li.add(16);
        System.out.println("Maximum element from the list: "+Collections.max(li));
        System.out.println("Minimum element from the list: "+Collections.min(li));
        
//        How to get max element of a list of user defined objects?
        List<Empl> emps = new ArrayList<Empl>();
        emps.add(new Empl(10, "Raghu", 25000));
        emps.add(new Empl(120, "Krish", 45000));
        emps.add(new Empl(210, "John", 14000));
        emps.add(new Empl(150, "Kishore", 24000));
        Empl maxSal = Collections.max(emps, new Comparator<Empl>() {
        	@Override
        	public int compare(Empl o1, Empl o2) {
        		return o1.getSalary().compareTo(o2.getSalary());
        	}
		});
        System.out.println("Employee with max salary: "+maxSal);
        
        
//        How to get min element of a list of user defined objects?
        Empl minSal = Collections.min(emps, new Comparator<Empl>() {
        	@Override
        	public int compare(Empl o1, Empl o2) {
        		return o1.getSalary().compareTo(o2.getSalary());
        	}
		});
        System.out.println("Employee with min salary: "+minSal);
        
        
//        How to create multiple copies of a given object?
        String temp = "JAVA2NOVICE";
        List<String> tempCopies = Collections.nCopies(5, temp);
        System.out.println(tempCopies);
        Empl emp = new Empl(10, "Raghu", 25000);
        List<Empl> empCopies = Collections.nCopies(5, emp);
        for(Empl e:empCopies){
            System.out.println(e);
        }
        
//        How to replace all occurances of a given object in the list?
        list.clear();
        list.add("java");
        list.add("c");
        list.add("c++");
        list.add("unix");
        list.add("perl");
        list.add("php");
        list.add("javascript");
        list.add("ruby");
        list.add(".net");
        list.add("perl");
        list.add("c++");
        System.out.println(list);
        //replace perl with dum_dum
        Collections.replaceAll(list, "perl", "dum_dum");
        System.out.println(list);
        
//        How to rotate elements in the list by specified distance?
        list.clear();
        list.add("java");
        list.add("c");
        list.add("c++");
        list.add("unix");
        list.add("perl");
        list.add("php");
        list.add("javascript");
        list.add("ruby");
        list.add(".net");
        System.out.println(list);
        Collections.rotate(list, 3);//Forward to 3 places..
        System.out.println("List after rotation:");
        System.out.println(list);
        
//        How to create synchronized list?
        List<String> nli = new ArrayList<String>();
        List<String> sysLi = Collections.synchronizedList(nli);
        
//      How to create synchronized set?
        Set<String> ss = new HashSet<String>();
        Set<String> sysSet = Collections.synchronizedSet(ss);
        
//      How to create synchronized map?
        Map<String,String> mp = new HashMap<String,String>();
        Map<String,String> sysMapt = Collections.synchronizedMap(mp);
        
        
        
    }
}

class Empl {
    
    private int id;
    private String name;
    private Integer salary;
     
    public Empl(int id, String name, Integer sal){
        this.id = id;
        this.name = name;
        this.salary = sal;
    }
     
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public Integer getSalary() {
        return salary;
    }
    public void setSalary(Integer salary) {
        this.salary = salary;
    }
    public String toString(){
        return id+"  "+name+"   "+salary;
    }
}
 
class EmpComp implements Comparator<Emp>{
 
	public int compare(Emp e1, Emp e2) {
        if(e1.getEmpId() == e2.getEmpId()){
            return 0;
        } else {
            return -1;
        }
    }
}
 
class Emp {
     
    private int empId;
    private String empName;
    private int empSal;
     
    public Emp(int id, String name, int sal){
        this.empId = id;
        this.empName = name;
        this.empSal = sal;
    }
     
    public int getEmpId() {
        return empId;
    }
     
    public void setEmpId(int empId) {
        this.empId = empId;
    }
     
    public String getEmpName() {
        return empName;
    }
     
    public void setEmpName(String empName) {
        this.empName = empName;
    }
     
    public int getEmpSal() {
        return empSal;
    }
    public void setEmpSal(int empSal) {
        this.empSal = empSal;
    }
     
    public String toString(){
        return empId+" : "+empName+" : "+empSal;
    }
}