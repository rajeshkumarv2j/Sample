package arrays;

import java.util.Arrays;
import java.util.List;

public class ArraysDemo1 {
	public static void main(String[] args) {
		int [] a = {1,2,3,4,5};
		List list = Arrays.asList(a);
		System.out.println(list);
	}
}
