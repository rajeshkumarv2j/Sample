package hashset;

public class Emp {

	public int id;
	public String name;
	public Emp(int i, String string) {
		id =i;
		name  = string;
	}
	@Override
	public int hashCode() {
		System.out.println("hashcode........");
		int result = 17;
		result = result * 31 + id;
		result = result * 31 + ((name!=null)?name.hashCode():0);
		return result ;
	}
	@Override
	public boolean equals(Object obj) {
		System.out.println("equals........");
		Emp j = (Emp)obj;
		if(id == j.id && name.equals(j.name)){
			return true;
		}
		return false;
	}
	@Override
	public String toString() {
		return "Emp [id=" + id + ", name=" + name + "]";
	}
	
	
}
