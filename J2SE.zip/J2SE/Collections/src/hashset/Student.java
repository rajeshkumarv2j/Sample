package hashset;

public class Student {

	public int id;
	public String name;
	public Student(int i, String string) {
		id =i;
		name  = string;
	}
	@Override
	public int hashCode() {
		int result = 17;
		result = result * 31 + id;
		result = result * 31 + ((name!=null)?name.hashCode():0);
		return result ;
	}
	@Override
	public boolean equals(Object obj) {
		Student j = (Student)obj;
		if(id == j.id && name.equals(j.name)){
			return true;
		}
		return false;
	}
	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + "]";
	}
}
