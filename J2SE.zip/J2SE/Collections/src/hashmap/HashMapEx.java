package hashmap;
 
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Map.Entry;
import java.util.Set;
 
public class HashMapEx {

	/*
	 * HashMap is a Hash table based implementation of the Map interface. This
	 * implementation provides all of the optional map operations, and permits
	 * null values and the null key. The HashMap class is roughly equivalent to
	 * Hashtable, except that it is unsynchronized and permits nulls. This class
	 * makes no guarantees as to the order of the map; in particular, it does
	 * not guarantee that the order will remain constant over time. This
	 * implementation provides constant-time performance for the basic
	 * operations (get and put), assuming the hash function disperses the
	 * elements properly among the buckets. Iteration over collection views
	 * requires time proportional to the "capacity" of the HashMap instance (the
	 * number of buckets) plus its size (the number of key-value mappings).
	 * Thus, it's very important not to set the initial capacity too high (or
	 * the load factor too low) if iteration performance is important.
	 */
	
	public static void main(String a[]){
        HashMap<String, String> hm = new HashMap<String, String>();
        //add key-value pair to hashmap
        hm.put("first", "FIRST INSERTED");
        hm.put("second", "SECOND INSERTED");
        hm.put("third","THIRD INSERTED");
        hm.put(null,null);
        hm.put(null,null);
        hm.put("first",null);
        hm.put(new Object().toString(), null);
        
        System.out.println(hm);
        
        //getting value for the given key from hashmap
        System.out.println("Value of second: "+hm.get("second"));
        System.out.println("Is HashMap empty? "+hm.isEmpty());
        hm.remove("third");
        System.out.println(hm);
        System.out.println("Size of the HashMap: "+hm.size());
        
        HashMap<String, String> subMap = new HashMap<String, String>();
        subMap.put("s1", "S1 VALUE");
        subMap.put("s2", "S2 VALUE");
        hm.putAll(subMap);
        System.out.println(hm);
        
//        How to search a key in HashMap?
        if(hm.containsKey("first")){
            System.out.println("The hashmap contains key first");
        } else {
            System.out.println("The hashmap does not contains key first");
        }
        if(hm.containsKey("fifth")){
            System.out.println("The hashmap contains key fifth");
        } else {
            System.out.println("The hashmap does not contains key fifth");
        }
        
//        how to find whether specified value exists or not?
        if(hm.containsValue("SECOND INSERTED")){
            System.out.println("The hashmap contains value SECOND INSERTED");
        } else {
            System.out.println("The hashmap does not contains value SECOND INSERTED");
        }
        if(hm.containsValue("first")){
            System.out.println("The hashmap contains value first");
        } else {
            System.out.println("The hashmap does not contains value first");
        }
        
//       how to get all key-value pair as Entry objects? 
        Set<Entry<String, String>> entires = hm.entrySet();
        for(Entry<String,String> ent:entires){
            System.out.println(ent.getKey()+" ==> "+ent.getValue());
        }
//        Clear the map
        hm.clear();
        
//        how to search user defined objects as a key from HashMap?
        HashMap<Price, String> hm1 = new HashMap<Price, String>();
        hm1.put(new Price("Banana", 20), "Banana");
        hm1.put(new Price("Apple", 40), "Apple");
        hm1.put(new Price("Orange", 30), "Orange");
        printMap(hm1);
        Price key = new Price("Banana", 20);
        System.out.println("Does key available? "+hm1.containsKey(key));
        
//        how to delete user defined objects as a key from HashMap?
        Price key1 = new Price("Banana", 20);
        System.out.println("Deleting key...");
        hm1.remove(key1);
        System.out.println("After deleting key:");
        printMap(hm1);
        
        
        
        
    }
	public static void printMap(HashMap<Price, String> map){
        
        Set<Price> keys = map.keySet();
        for(Price p:keys){
            System.out.println(p+"==>"+map.get(p));
        }
    }
}

class Price{
    
    private String item;
    private int price;
     
    public Price(String itm, int pr){
        this.item = itm;
        this.price = pr;
    }
     
    public int hashCode(){
        System.out.println("In hashcode");
        int hashcode = 0;
        hashcode = price*20;
        hashcode += item.hashCode();
        return hashcode;
    }
     
    public boolean equals(Object obj){
        System.out.println("In equals");
        if (obj instanceof Price) {
            Price pp = (Price) obj;
            return (pp.item.equals(this.item) && pp.price == this.price);
        } else {
            return false;
        }
    }
     
    public String getItem() {
        return item;
    }
    public void setItem(String item) {
        this.item = item;
    }
    public int getPrice() {
        return price;
    }
    public void setPrice(int price) {
        this.price = price;
    }
     
    public String toString(){
        return "item: "+item+"  price: "+price;
    }
}