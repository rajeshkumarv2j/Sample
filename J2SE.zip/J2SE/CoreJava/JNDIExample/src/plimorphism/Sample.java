package plimorphism;

import java.sql.BatchUpdateException;
import java.sql.SQLException;
import java.util.DuplicateFormatFlagsException;

class A {
	public void m1() {
		System.out.println(9);
	}

	public A m2() throws SQLException {
		System.out.println(9);
		return null;
	}

	public Object m3() {
		System.out.println(10);
		return null;
	}

	public static void m4() {
		System.out.println(9);
	}
}

class B extends A {
	public void m1() {
		System.out.println(9);
	}

	public B m2() throws BatchUpdateException {
		System.out.println(9);
		return null;
	}

	public synchronized Object m3() {
		System.out.println(10);
		return null;
	}

	public static void m4() {
		System.out.println(9);
	}
}