package plimorphism;

import java.util.HashMap;

public class EqualsHashCode {
	public static void main(String[] args) {
		HashMap<Emp, String> hashMap = new HashMap<Emp, String>();
		Emp emp1 = new Emp();
		System.out.println(emp1.hashCode());
		Emp emp2 = new Emp();
		System.out.println(emp2.hashCode());
		Emp emp3 = new Emp();
		System.out.println(emp3.hashCode());
		hashMap.put(emp1, "a");
		hashMap.put(emp2, "b");
		hashMap.put(emp3, "c");
		System.out.println(hashMap.size());
		System.out.println(hashMap);
		Emp emp = new Emp();
		System.out.println(hashMap.get(emp));
	}
}

class Emp {
	int id;
	String name;

	public Emp() {
	}

	public Emp(int id, String name) {
		this.id = id;
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int hashCode() {
		return 1;
	}

	public boolean equals(Object object) {
		return true;
	}
}