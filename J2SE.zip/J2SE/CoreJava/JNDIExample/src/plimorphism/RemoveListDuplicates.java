package plimorphism;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.TreeSet;

public class RemoveListDuplicates {
	
	public static void main(String[] args) {
		List details = new ArrayList();
		details.add(100);
		details.add(200);
		details.add(100);
		details.add(200);
		details.add(300);
		details.add(600);
		details.add(600);

		System.out.println(details);
		Object[] d = details.toArray();
		Arrays.sort(d);
		System.out.println(details);
		
		ListIterator lItr = details.listIterator();
		for(int i=0; lItr.hasNext();i++){
			lItr.next();
			lItr.set(d[i]);
		}
		
		
		System.out.println(details);
	}
	
}
