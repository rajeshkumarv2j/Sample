package com.jatin.jndi.examples;

import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.naming.Reference;
import javax.naming.StringRefAddr;

public class JNDIExample {
	public static void main(String[] args) throws NamingException {
		Hashtable<String, String> hashtable = new Hashtable<String, String>();
		hashtable.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.fscontext.RefFSContextFactory");
		hashtable.put(Context.PROVIDER_URL,"file:/C:/");
		Context context = new InitialContext(hashtable);
		
		Reference ref = new Reference("one","two", null);
		ref.add(new StringRefAddr("name","value"));
		context.bind("wishes", ref);
		
	}
}
