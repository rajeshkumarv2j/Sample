package puzzile.java;

public class HelloGoodbye1 {
	public static void main(String[] args) {
		System.out.println("Hello world");
		Runtime.getRuntime().addShutdownHook(new Thread() {
			public void run() {
				try {
					Thread.sleep(5000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				System.out.println("Goodbye world");
			}
		});
		System.exit(0);
	}
}