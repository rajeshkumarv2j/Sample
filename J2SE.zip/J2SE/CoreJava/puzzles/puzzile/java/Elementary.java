package puzzile.java;public class Elementary {
    public static void main(String[] args) {
        System.out.println(12345 + 5432l);
    }
}
