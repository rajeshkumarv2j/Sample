package puzzile.java;public class Tweedledum {
    public static void main(String[] args) {
        // Put your declarations for x and i here
    	int i=0,x=0;
        x += i;     // Must be LEGAL
        x = x + i;  // Must be ILLEGAL
    }
}
