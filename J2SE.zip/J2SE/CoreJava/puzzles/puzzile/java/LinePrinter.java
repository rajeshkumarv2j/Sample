package puzzile.java;
public class LinePrinter {
	public static void main(String[] args) {
		// Note: \\u000A is Unicode representation of linefeed (LF)
		char c = 0x000A;
		System.out.println(c);
		System.out.println("Raj");
		char c1='\n';
		System.out.println(c1);
		System.out.println("Raj");
	}
}