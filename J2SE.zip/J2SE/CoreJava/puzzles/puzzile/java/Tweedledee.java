package puzzile.java;public class Tweedledee {
    public static void main(String[] args) {
        // Put your declarations for x and i here
    	int x=0,i=0;
        x = x + i;  // Must be LEGAL
        x += i;     // Must be ILLEGAL
    }
}
