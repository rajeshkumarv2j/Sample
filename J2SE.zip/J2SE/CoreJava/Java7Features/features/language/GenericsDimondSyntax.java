package features.language;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GenericsDimondSyntax {
	public static void main(String[] args) {
		testDinamond();
	}
	public static void testDinamond(){
	    List<String> list = new ArrayList<>();
	    list.add("");
	    list.add("1");
	    System.out.println(list);
	    
	    Map<String, String> map = new HashMap<>();
	    map.put("raj", "raj");
	    System.out.println(map);
	}
}
