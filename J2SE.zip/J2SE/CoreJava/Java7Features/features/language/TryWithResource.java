package features.language;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class TryWithResource {
	public static void main(String[] args) throws FileNotFoundException,
			IOException {
		testTryWithResourcesStatement();

		try (Connection con = DriverManager.getConnection("")) {
			System.out.println(con);
		} catch (SQLException e) {
		}
	}

	public static void testTryWithResourcesStatement()
			throws FileNotFoundException, IOException {
		try (FileInputStream in = new FileInputStream("java7.txt")) {
			System.out.println(in.read());
		}
	}

}
