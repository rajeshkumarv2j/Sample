package features.language;

public class Binary {
	public static void main(String[] args) {
		testBinaryIntegralLiterals();
		
		System.out.println(0b010000);
	}


	public static void testBinaryIntegralLiterals() {
		int binary = 0b1000; // 2^3 = 8
		if (binary == 8) {
			System.out.println(true);
		} else {
			System.out.println(false);
		}
	}
}
