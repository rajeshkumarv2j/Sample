package features.language;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Scanner;

public class ExceptionMultiCatch {
	public static void main(String[] args) {
		testMultiCatch(Boolean.parseBoolean(new Scanner(System.in).next()));
	}

	public static void testMultiCatch(boolean flag) {
		try {
			if (flag) {
				throw new SQLException("SQLException");
			} else
				throw new FileNotFoundException("FileNotFoundException");
		} catch (SQLException | IOException fnfo) {
			fnfo.printStackTrace();
		}
	}
}
