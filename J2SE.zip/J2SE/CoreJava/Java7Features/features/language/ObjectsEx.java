package features.language;

import java.util.Arrays;
import java.util.Objects;

public class ObjectsEx {
	private String houseNumber;
	private String street;
	private String city;
	private String stateOrProvince;
	private String country;

	/**
	 * Ternary Makes Equals More Concise
	 */
	// @Override
	public boolean equals1(Object obj) {
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final ObjectsEx other = (ObjectsEx) obj;
		if (this.houseNumber != other.houseNumber
				&& (this.houseNumber == null || !this.houseNumber.equals(other.houseNumber))) {
			return false;
		}
		if ((this.street == null) ? (other.street != null) : !this.street.equals(other.street)) {
			return false;
		}
		if ((this.city == null) ? (other.city != null) : !this.city.equals(other.city)) {
			return false;
		}
		if ((this.stateOrProvince == null) ? (other.stateOrProvince != null)
				: !this.stateOrProvince.equals(other.stateOrProvince)) {
			return false;
		}
		if ((this.country == null) ? (other.country != null) : !this.country.equals(other.country)) {
			return false;
		}
		return true;
	}

	// @Override
	public boolean equals2(Object obj) {
		boolean result;

		if (this == obj) {
			result = true;
		} else if (obj != null && getClass() == obj.getClass()) {
			final ObjectsEx other = (ObjectsEx) obj;

			final Object[] fields = { houseNumber, street, city, stateOrProvince, country };

			final Object[] otherFields = { other.houseNumber, other.street, other.city, other.stateOrProvince,
					other.country };

			result = Arrays.equals(fields, otherFields);
		} else {
			result = false;
		}

		return result;
	}

//	@Override
	public boolean equals3(Object obj) {
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final ObjectsEx other = (ObjectsEx) obj;
		return Objects.equals(this.houseNumber, other.houseNumber) && Objects.equals(this.street, other.street)
				&& Objects.equals(this.city, other.city) && Objects.equals(this.stateOrProvince, other.stateOrProvince)
				&& Objects.equals(this.country, other.country);
	}

//	@Override
	public int hashCode1() {
		int hash = 3;
		hash = 53 * hash + (this.houseNumber != null ? this.houseNumber.hashCode() : 0);
		hash = 53 * hash + (this.street != null ? this.street.hashCode() : 0);
		hash = 53 * hash + (this.city != null ? this.city.hashCode() : 0);
		hash = 53 * hash + (this.stateOrProvince != null ? this.stateOrProvince.hashCode() : 0);
		hash = 53 * hash + (this.country != null ? this.country.hashCode() : 0);
		return hash;
	}

//	@Override
	public int hashCode2() {
		return Objects.hash(this.houseNumber, this.street, this.city, this.stateOrProvince, this.country);
	}
}
