package features.language;

public class UnderscoreNumber {
	public static void main(String[] args) {
		testUnderscoresNumericLiterals();
		System.out.println(1_1_1_1_1_1);
	}

	public static void testUnderscoresNumericLiterals() {
		int oneMillion_ = 1_000_000; // new
		int oneMillion = 1000000;
		if (oneMillion_ == oneMillion) {
			System.out.println(true);
		} else {
			System.out.println(false);
		}
	}
}
