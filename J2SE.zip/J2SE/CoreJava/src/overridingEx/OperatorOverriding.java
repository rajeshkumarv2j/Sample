package overridingEx;

public class OperatorOverriding {
	public static void main(String[] args) {
		T t = null;
		System.out.println(t.i);
		t = new T(){};
		System.out.println(t.i);
		t = new A1();
		System.out.println(t.i);
		t = new B1();
		System.out.println(t.i);
		
		A1 a = new A1();
		System.out.println(a.i);
		System.out.println(a.print());
		
		a = new B1();
		System.out.println(a.i);
		System.out.println(a.print());
		
		A1 a2 = new B1();
		a2.method();
	}
}
interface T{
	int i = 5;
}
class A1 implements T{
	static void method(){
		System.out.println("parent static");
	}
	int i = 10;
	public int print() {
		return i;
	}
}
class B1 extends A1{
	static void method(){
		System.out.println("child static");
	}
	int i = 20;
	public int print() {
		return super.i;
	}
}