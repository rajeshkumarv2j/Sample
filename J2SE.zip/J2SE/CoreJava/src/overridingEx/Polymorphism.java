package overridingEx;

class A {
	public Number m1() {
		System.out.println("m1...");
		return 0;
	}
	
	public String m2() {
		System.out.println("m2...");
		return null;
	}

	public void m3() throws ArrayIndexOutOfBoundsException{
		System.out.println("m3...");
	}

	public void m4() throws RuntimeException {
		System.out.println("m4...");
	}

	public void m5(Object object) {
		System.out.println("m5...");
	}

	public Number m6(double d) {
		System.out.println("m6...");
		return 0.0;
	}

	public void eat() throws Exception {
		System.out.println("Parents are eating..");
	}
	private void m10(){
		System.out.println("A... m10....");
	}
}

class B extends A {
	public Float m1() {
		System.out.println("m1...");
		return 0f;
	}
	
	public String m2() {
		System.out.println("m2...");
		return null;
	}

	public void m3() throws  RuntimeException  {//ArrayIndexOutOfBoundsException, SQLException,ClassNotFoundException, RuntimeException, IOException {
		System.out.println("m3...");
	}

	public void m4() throws RuntimeException {
		System.out.println("m4...");
	}

	public void m5(Object object) {
		System.out.println("m5...");
	}

	public Float m6(float d) {
		return 0.0f;
	}

	public void eat() throws ClassNotFoundException {
		System.out.println("Child is eating..");
	}
	
	private void m10(){
		System.out.println("B... m10...");
	}
}

public class Polymorphism {
	public static void main(String[] args) {
		B a = new B();
	}
}