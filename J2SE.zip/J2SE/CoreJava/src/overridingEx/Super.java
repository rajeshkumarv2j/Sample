package overridingEx;

import java.sql.SQLException;

public class Super {
	int a=20;
	
	protected void c() throws SQLException{
		
	}
	public Super() {
		super();
		System.out.println("Super class constructor");
	}
	
}
