package memory;

import java.util.ArrayList;

public class Practice {
	public static void main(String[] args) {
		System.out.println(Memory.content());
		ArrayList<String> arrayList = new ArrayList<String>();
		for(int i = 0; i < 7630000; i++){
			arrayList.add(new String("Rajeshkumar.VelishojuRajeshkumar.VelishojuRajeshkumar.VelishojuRajeshkumar.VelishojuRajeshkumar.Velishoju"));
		}
		System.out.println(Memory.content());
	}
}
class Memory{
	static final int TO_MB = 1024*1024;
	public static String content() {
		int total = (int) (Runtime.getRuntime().totalMemory() / TO_MB), 
			free = (int) (Runtime.getRuntime().freeMemory() / TO_MB), 
			max = (int) (Runtime.getRuntime().maxMemory() / TO_MB), 
			used = total - free;
		return "Memory [total=" + total + ", free=" + free + ", max=" + max + ", used=" + used + "]";
	}
}
