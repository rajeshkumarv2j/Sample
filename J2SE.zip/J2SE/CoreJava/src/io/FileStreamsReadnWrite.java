package io;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

class FileStreamsReadnWrite {
	public static void main(String[] args) {
		try {
			File stockInputFile = new File("C://stock/stockIn.txt");
			File StockOutputFile = new File("C://stock/StockOut.txt");

			/*
			 * Constructor of FileInputStream throws FileNotFoundException if
			 * the argument File does not exist.
			 */

			FileInputStream fis = new FileInputStream(stockInputFile);
			FileOutputStream fos = new FileOutputStream(StockOutputFile);
			int count;
			int s = 0;
			while ((count = fis.read()) != -1) {
				fos.write(count);
				s++;
			}
			System.out.println(s);
			fis.close();
			fos.close();
		} catch (FileNotFoundException e) {
			System.err.println("FileStreamsReadnWrite: " + e);
		} catch (IOException e) {
			System.err.println("FileStreamsReadnWrite: " + e);
		}
	}
}