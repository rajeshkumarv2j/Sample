package io;

import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;

public class HowToReadFileInJava {
	public static void main(String args[]) {
		// Example 1 - Reading File's content using FileInputStream
		try {
			FileInputStream fis = new FileInputStream("data.txt");
			int data = fis.read();
			while (data != -1) {
				System.out.print(Integer.toHexString(data));
//				System.out.print("---");
//				System.out.print("nonHexa"+data);
//				System.out.println();
				data = fis.read();
			}
		} catch (IOException e) {
			System.out.println("Failed to read binary data from File");
			e.printStackTrace();
		}

		// Example 2 - Reading File data using FileReader in Java
		try {
			FileReader reader = new FileReader("data.txt");
			int character = reader.read();
			while (character != -1) {
				System.out.print((char) character);
				character = reader.read();
			}
		} catch (IOException io) {
			System.out.println("Failed to read character data from File");
			io.printStackTrace();
		}
	}
}
