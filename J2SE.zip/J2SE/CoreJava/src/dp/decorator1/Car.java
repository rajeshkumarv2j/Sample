package dp.decorator1;
public interface Car {

	public void assemble();
}