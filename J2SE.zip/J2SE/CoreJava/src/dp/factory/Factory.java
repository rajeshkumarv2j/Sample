package dp.factory;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

class CurrencyFactory {

	public static Currency createCurrency(String country) {
		if (country.equalsIgnoreCase("India")) {
			return new Rupee();
		} else if (country.equalsIgnoreCase("Singapore")) {
			return new SGDDollar();
		} else if (country.equalsIgnoreCase("US")) {
			return new USDollar();
		}
		throw new IllegalArgumentException("No such currency");
	}
}

// Factory client code
public class Factory {
	public static void main(String args[]) throws IOException {
		System.out.println("Enter which currency symbol you want..?");
		BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
		String country = bufferedReader.readLine();
//		String country = args[0];
		Currency rupee = CurrencyFactory.createCurrency(country);
		System.out.println(rupee.getSymbol());
	}
}