package dp.decorator;

//Another Concrete Decorator

public class _1SGDDecorator extends _1Decorator {
	_1Currency currency;

	public _1SGDDecorator(_1Currency currency) {
		this.currency = currency;
	}

	@Override
	public String getCurrencyDescription() {
		return currency.getCurrencyDescription() + " ,its singapore Dollar";
	}

	@Override
	public double cost(double value) {
		return currency.cost(value);
	}
}
