package dp.decorator;

public class _2OneBedRoomHouseWithSwimmingPoolDecorator extends
_2AbstractHouseDecorator {

	public _2HouseComponent house;

	public _2OneBedRoomHouseWithSwimmingPoolDecorator(_2HouseComponent house) {
		this.house = house;
	}

	@Override
	public String getHouseDescription() {
		return house.getHouseDescription() + " and with swimmmingPool";

	}

	@Override
	public Double getPrice() {
		Double modifiedPrice = house.getPrice() + house.getPrice() * .25;
		return modifiedPrice;
	}
}
