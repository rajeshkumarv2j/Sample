package dp.decorator;

//This class will act as Component

public abstract class _2HouseComponent {

	public String description = " Unknown House ";

	public String getHouseDescription() {
		return description;
	}

	public abstract Double getPrice();

}
