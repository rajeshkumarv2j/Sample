package dp.decorator;

public class _2DecoratorDemo {
	public static void main(String[] args) {

		_2HouseComponent oneBHKhouse = new _2OneBedRoomHouse();
		System.out.println(oneBHKhouse.getHouseDescription() + ", Price: "
				+ oneBHKhouse.getPrice());

		_2HouseComponent decoratedHouse1 = new _2OneBedRoomHouseWithCarSpaceDecorator(
				new _2OneBedRoomHouse());
		System.out.println(decoratedHouse1.getHouseDescription() + ", Price :"
				+ decoratedHouse1.getPrice());

		_2HouseComponent decoratedHouse2 = new _2OneBedRoomHouseWithSwimmingPoolDecorator(
				new _2OneBedRoomHouseWithCarSpaceDecorator(new _2OneBedRoomHouse()));
		System.out.println(decoratedHouse2.getHouseDescription() + ", Price :"
				+ decoratedHouse2.getPrice());

	}

}
