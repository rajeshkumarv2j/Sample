package dp.observer1;

public interface NEWSReader {
	public void update();
	public void setNEWSPaper(NEWSPaper newsPaper);
}