package dp.observer1;

public interface NEWSPaper {
	public void registerNEWSReader(NEWSReader obj);
	public void unregisterNEWSReader(NEWSReader obj);
	public void notifyNEWSReaders();
	public Object getUpdate(NEWSReader obj);
	public void postMessage(String news);
}