package dp.observer1;

public class TeluguNEWSReader implements NEWSReader {

	private String name;
	private TeluguNEWSPaper teluguNEWSPaper;

	public TeluguNEWSReader(String nm) {
		this.name = nm;
	}

	@Override
	public void update() {
		String msg = (String) teluguNEWSPaper.getUpdate(this);
		if (msg == null) {
			System.out.println(name + ":: No new message");
		} else
			System.out.println(name + ":: Consuming message::" + msg);
	}

	@Override
	public void setNEWSPaper(NEWSPaper newsPaper) {
		this.teluguNEWSPaper = (TeluguNEWSPaper) newsPaper;
	}

}