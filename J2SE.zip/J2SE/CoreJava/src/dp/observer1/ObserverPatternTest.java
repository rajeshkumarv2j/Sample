package dp.observer1;

public class ObserverPatternTest {

	public static void main(String[] args) {
		NEWSPaper newsPaper = new TeluguNEWSPaper();

		NEWSReader newsReader1 = new TeluguNEWSReader("newsReader1");
		NEWSReader newsReader2 = new TeluguNEWSReader("newsReader2");
		NEWSReader newsReader3 = new TeluguNEWSReader("newsReader3");

		newsPaper.registerNEWSReader(newsReader1);
		newsPaper.registerNEWSReader(newsReader2);
		newsPaper.registerNEWSReader(newsReader3);

		newsReader1.setNEWSPaper(newsPaper);
		newsReader2.setNEWSPaper(newsPaper);
		newsReader3.setNEWSPaper(newsPaper);

		// check if any update is available
		newsReader1.update();

		// now send message to subject
		newsPaper.postMessage("New Message");
	}

}