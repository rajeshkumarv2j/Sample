package dp.observer1;

import java.util.ArrayList;
import java.util.List;

public class TeluguNEWSPaper implements NEWSPaper {

	private List<TeluguNEWSReader> teluguNEWSReaders;
	private String message;
	private boolean changed;
	private final Object MUTEX = new Object();

	public TeluguNEWSPaper() {
		this.teluguNEWSReaders = new ArrayList<TeluguNEWSReader>();
	}

	@Override
	public void registerNEWSReader(NEWSReader newsReader) {
		if (newsReader == null)
			throw new NullPointerException("Null Observer");
		synchronized (MUTEX) {
			if (!teluguNEWSReaders.contains(newsReader))
				teluguNEWSReaders.add((TeluguNEWSReader) newsReader);
		}
	}

	@Override
	public void unregisterNEWSReader(NEWSReader newsReader) {
		synchronized (MUTEX) {
			teluguNEWSReaders.remove(newsReader);
		}
	}

	@Override
	public void notifyNEWSReaders() {
		List<TeluguNEWSReader> observersLocal = null;
		synchronized (MUTEX) {
			if (!changed)
				return;
			observersLocal = new ArrayList<TeluguNEWSReader>(this.teluguNEWSReaders);
			this.changed = false;
		}
		for (TeluguNEWSReader obj : observersLocal) {
			obj.update();
		}

	}

	@Override
	public Object getUpdate(NEWSReader obj) {
		return this.message;
	}

	public void postMessage(String msg) {
		System.out.println("Message Posted to Topic:" + msg);
		this.message = msg;
		this.changed = true;
		notifyNEWSReaders();
	}
}