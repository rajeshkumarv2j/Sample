package date;

import java.text.DateFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Syntax {
	public static void main(String[] args) {
		Date date = new Date();
		System.out.println(date);// Thu Sep 29 06:52:11 IST 2016
		System.out.println(date.toString());

		Date date2 = new Date(new Date().getTime());
		System.out.println(date2);

		System.out.println(new Date().getTime());// 1475115057897

		DateFormat ft = new SimpleDateFormat("E yyyy.MM.dd 'at' hh:mm:ss a zzz");
		ft = new SimpleDateFormat("E");
		ft = new SimpleDateFormat("yyyy");
		ft = new SimpleDateFormat("MM");
		ft = new SimpleDateFormat("MMM");
		ft = new SimpleDateFormat("dd");
		ft = new SimpleDateFormat("hh");
		ft = new SimpleDateFormat("HH");
		ft = new SimpleDateFormat("mm");
		ft = new SimpleDateFormat("ss");
		ft = new SimpleDateFormat("a");
		ft = new SimpleDateFormat("zzz");
		System.out.println("Current Date: " + ft.format(date));

		// 1 second = 1000
		// 1 minute = 1000 * 60
		// 1 hour = 1000 * 60 * 60
		// 24 hours = 24 * 1000 * 60 * 60
		Date today = new Date(new Date().getTime());
		System.out.println(today);

		Date tommorow = new Date(new Date().getTime() + 86400000);
		System.out.println(tommorow);
		System.out.println(today.before(tommorow));
		System.out.println(today.after(tommorow));
		System.out.println(today.equals(tommorow));

		System.out.println(today.getTime() < tommorow.getTime());
		System.out.println(today.getTime() > tommorow.getTime());
		System.out.println(today.getTime() == tommorow.getTime());

		tommorow.setTime(tommorow.getTime() - 24 * 60 * 60 * 1000);
		System.out.println(today.equals(tommorow));
		// jan 1 1970

		long start = System.currentTimeMillis();
		System.out.println(new Date() + "\n");

		// try {
		// Thread.sleep(5*60*10);
		// } catch (InterruptedException e) {
		// e.printStackTrace();
		// }
		System.out.println(new Date() + "\n");

		long end = System.currentTimeMillis();
		long diff = end - start;
		System.out.println("Difference is : " + diff);

		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String dateString = format.format(new Date());
		Date parseDate = null;
		try {
			parseDate = format.parse("2009-12-31");
		} catch (ParseException e) {
			e.printStackTrace();
		}
		System.out.println(parseDate);

		// ====================================================================================================
		System.out
				.println("====================================================================================================");
		Calendar calendar = new GregorianCalendar();
		calendar = Calendar.getInstance();

		System.out.println(calendar.getTime());
		System.out.println(calendar.getTimeInMillis());
		System.out.println(calendar.getTimeZone().getDisplayName());

		int year = calendar.get(Calendar.YEAR);
		int month = calendar.get(Calendar.MONTH);
		int dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH); // Jan = 0, not 1
		int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);
		int weekOfYear = calendar.get(Calendar.WEEK_OF_YEAR);
		int weekOfMonth = calendar.get(Calendar.WEEK_OF_MONTH);
		int hour = calendar.get(Calendar.HOUR); // 12 hour clock
		int hourOfDay = calendar.get(Calendar.HOUR_OF_DAY); // 24 hour clock
		int minute = calendar.get(Calendar.MINUTE);
		int second = calendar.get(Calendar.SECOND);
		int millisecond = calendar.get(Calendar.MILLISECOND);

		calendar.set(Calendar.YEAR, 2009);
		calendar.set(Calendar.MONTH, 11); // 11 = december
		calendar.set(Calendar.DAY_OF_MONTH, 24); // christmas eve
		System.out.println(calendar.getTime());

		calendar.set(Calendar.YEAR, 2009);
		calendar.set(Calendar.MONTH, 11); // 11 = december
		calendar.set(Calendar.DAY_OF_MONTH, 31); // new years eve

		// add one day
		calendar.add(Calendar.DAY_OF_MONTH, 1);

		// date is now jan. 1st 2010
		System.out.println(calendar.get(Calendar.YEAR)); // now 2010
		System.out.println(calendar.get(Calendar.MONTH)); // now 0 (Jan = 0)
		System.out.println(calendar.get(Calendar.DAY_OF_MONTH)); // now 1

		calendar.clear();
		System.out.println(calendar.getTime());// Thu Jan 01 00:00:00 IST 1970
		System.out.println(calendar.after(calendar));
		System.out.println(calendar.before(calendar));
		
		
		//===============================================================================================
//		A Locale object represents a specific geographical, political, or cultural region.
		
		// Creates a locale object using one parameter to constructor
		Locale locale = new Locale("fr");	
		System.out.println("locale: "+locale);
		
		// Create a locale object using two parameters constructor
		Locale locale2 = new Locale("fr", "CANADA");
		System.out.println("locale2: "+locale2);
		
		// Getting a default locale object
		locale = Locale.getDefault();
		System.out.println("Default Locale: "+locale);
		
		// Getting all available locales from current instance of the JVM
		Locale []availableLocale = Locale.getAvailableLocales();
		for(Locale aLocale : availableLocale){
			System.out.println("Name of Locale: "+aLocale.getDisplayName());
			System.out.println("Language Code: "+aLocale.getLanguage()+", Language Display Name: "+aLocale.getDisplayLanguage());
			System.out.println("Country Code: "+aLocale.getCountry()+", Country Display Name: "+aLocale.getDisplayCountry());
			if(!aLocale.getVariant().equals("")){
				System.out.println("Variant Code: "+aLocale.getVariant()+", Variant Display Name: "+aLocale.getDisplayVariant());
			}
			System.out.println("****************************************************************");
		}

		long number = 5000000L;
		NumberFormat numberFormatDefault = NumberFormat.getInstance();
		System.out.println("Number Format using Default Locale: "+numberFormatDefault.format(number));
		
		NumberFormat numberFormatLocale = NumberFormat.getInstance(Locale.ITALY);
		System.out.println("Number Format using ITALY Locale: "+numberFormatLocale.format(number));
		
		NumberFormat numberFormatDefaultCurrency = NumberFormat.getCurrencyInstance();
		System.out.println("Currency Format using Default Locale: "+numberFormatDefaultCurrency.format(number));
		
		NumberFormat numberFormatLocaleCurrency = NumberFormat.getCurrencyInstance(Locale.ITALY);
		System.out.println("Currency Format using ITALY Locale: "+numberFormatLocaleCurrency.format(number));
		
		Date currentDate = new Date();
		DateFormat dateFormat = DateFormat.getDateInstance(DateFormat.FULL, Locale.GERMAN);
		System.out.println("Date Format in German Locale: "+dateFormat.format(currentDate));
		
//		==================================================================================================================
		System.out.println("==============================================================================================");
		
	}
}
