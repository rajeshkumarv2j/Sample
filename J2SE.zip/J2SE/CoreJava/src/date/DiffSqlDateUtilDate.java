package date;

import java.sql.Date;

public class DiffSqlDateUtilDate {
	public static void main(String[] args) {
		Date date = new java.sql.Date(23*60*60*60*1000);
		System.out.println(date);
		
//		java.util.Date date2 = new java.util.Date();
		
	}
}
