package externalization;

import java.io.Externalizable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;

public class Sample {
	public static void main1(String[] args) throws IOException {
		Emp emp = new Emp(1, "Rajeshkumar.V");
		File file = new File("nenu.txt");
		file.createNewFile();
		FileOutputStream fileOutputStream = new FileOutputStream(file);
		ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
		objectOutputStream.writeObject(emp);
		objectOutputStream.flush();
		objectOutputStream.close();
	}
	public static void main(String[] args) throws IOException, ClassNotFoundException {
		FileInputStream fileInputStream = new FileInputStream("nenu.txt");
		ObjectInputStream inputStream = new ObjectInputStream(fileInputStream);
		Emp emp = (Emp) inputStream.readObject();
		System.out.println(emp);
	}
}

class Emp implements Externalizable {
	int id;
	String name;

	public Emp() {
	}

	public Emp(int id, String name) {
		this.id = id;
		this.name = name;
	}

	@Override
	public void writeExternal(ObjectOutput out) throws IOException {
		out.writeInt(this.id);
		out.writeUTF(this.name);
	}

	@Override
	public void readExternal(ObjectInput in) throws IOException,
			ClassNotFoundException {
		this.id = in.readInt();
		this.name = in.readUTF();
	}

	@Override
	public String toString() {
		return "Emp [id=" + id + ", name=" + name + "]";
	}

}