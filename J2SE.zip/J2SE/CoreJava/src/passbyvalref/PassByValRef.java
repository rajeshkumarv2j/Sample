package passbyvalref;

import java.util.HashMap;

public class PassByValRef {
	void changeValue(int i) {
		i = i + 10;
	}

	void changeValue(StringBuffer i) {
		i.append("Rajeshkumar.V");
	}
	
	static StringBuffer s1 = new StringBuffer("Rajesh");
	static StringBuffer s2;
	static{
		s2=s1;
	}

	public static void main1(String[] args) {
		s2.append("Kumar");
		System.out.println(s1);
		System.out.println(s2);

		s2.delete(0, s2.length());
		s2.append("1111111111111111");
		System.out.println(s1);
		System.out.println(s2);

		
/*		s2=new StringBuffer("Jatin");
		System.out.println(s1);
		System.out.println(s2);*/
		
/*		PassByValRef byValRef = new PassByValRef();
		int d = 15;
		byValRef.changeValue(d);
		StringBuffer buffer = new StringBuffer("Rajeshkumar");
		byValRef.changeValue(buffer);
		System.out.println(d);
		System.out.println(buffer);*/
	}
	
	
	static HashMap<Integer, StringBuffer> hashMap = new HashMap<Integer, StringBuffer>();
	static  void doithere(HashMap<Integer, StringBuffer> hashMap){
		hashMap.get(1).append("Rajeshkumar.V");
	}
	public static void main(String[] args) {
		hashMap.put(1, new StringBuffer("one "));
		doithere(hashMap);
		System.out.println(hashMap);
	}
}
