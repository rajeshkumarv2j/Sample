package foreachEx;

import java.util.AbstractCollection;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class CustomCollection<T> implements Iterable<T>{
	private ArrayList<T> bucket;

	public CustomCollection() {
		bucket = new ArrayList<T>();
	}

	public int size() {
		return bucket.size();
	}

	public boolean isEmpty() {
		return bucket.isEmpty();
	}

	public boolean contains(T o) {
		return bucket.contains(o);
	}

	public boolean add(T e) {
		return bucket.add(e);
	}

	public boolean remove(T o) {
		return bucket.remove(o);
	}

	public Iterator<T> iterator() {
		return bucket.iterator();
	}
}
class A<E> extends AbstractCollection<E>{

	ArrayList<E> list;
	public A() {
		list = new ArrayList<E>();
	}
	public boolean add(E e) {
		return list.add(e);
	}
	
	@Override
	public Iterator<E> iterator() {
		return list.iterator();
	}
	
	@Override
	public boolean remove(Object o) {
		return list.remove(o);
	}
	@Override
	public int size() {
		return list.size();
	}
	
}