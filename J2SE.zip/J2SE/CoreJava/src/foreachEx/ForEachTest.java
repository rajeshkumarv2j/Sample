package foreachEx;

import java.util.ArrayList;


/** * Java Class to show how for-each loop works in Java */
public class ForEachTest {
	public static void main(String args[]) {
		ArrayList<String> myCollection = new ArrayList<String>();
		myCollection.add("Java");
		myCollection.add("Scala");
		myCollection.add("Groovy");
		// What does this code will do, print language, throw exception or compile time error
		for (String language : myCollection) {
			if(language.equals("Scala"))
				myCollection.iterator().remove();
			System.out.println(language);
		}
	}
}
