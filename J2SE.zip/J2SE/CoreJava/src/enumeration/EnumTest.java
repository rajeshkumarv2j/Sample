package enumeration;

/**
 * Java Program to parse String to Enum in Java with examples.
 */
public class EnumTest {

	private enum LOAN {
		HOME_LOAN {
			@Override
			public String toString() {
				return "Home Loan";
			}
		},
		PERSONAL_LOAN {
			@Override
			public String toString() {
				return "Personal Loan";
			}
		},
		AUTO_LOAN {
			@Override
			public String toString() {
				return "Auto Loan";
			}
		}
	}

	public static void main(String[] args) {
		EnumTest.LOAN name = EnumTest.LOAN.AUTO_LOAN;
		System.out.println(name);
		
		// Exmaple of Converting String to Enum in Java
        LOAN homeLoan = LOAN.valueOf("HOME_LOAN");
        System.out.println(homeLoan);

        LOAN autoLoan = LOAN.valueOf("AUTO_LOAN");
        System.out.println(autoLoan);

        /*
        LOAN personalLoan = LOAN.valueOf("PEROSNAL_LOAN");
        System.out.println(personalLoan);*/   
/*
 * Exception in thread "main" java.lang.IllegalArgumentException: No enum const class enumeration.EnumTest$LOAN.PEROSNAL_LOAN
	at java.lang.Enum.valueOf(Unknown Source)
	at enumeration.EnumTest$LOAN.valueOf(EnumTest.java:1)
	at enumeration.EnumTest.main(EnumTest.java:40)
 */

        
     // Java example to convert Enum to String in Java
        String homeLoan1 = LOAN.HOME_LOAN.name();
       System.out.println(homeLoan1);

       String autoLoan1 = LOAN.AUTO_LOAN.name();
       System.out.println(autoLoan1);

       String personalLoan1 = LOAN.PERSONAL_LOAN.name();
       System.out.println(personalLoan1); 
       
       System.out.println(LOAN.AUTO_LOAN.name());
       System.out.println(LOAN.AUTO_LOAN.ordinal());// output:2


	}
}
