package enumeration;

public class EnumSwitch {
	enum DAYS {
		SUNDAY, MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY
	}

	public static void main(String[] args) {
		DAYS[] days = DAYS.values();
		for (DAYS day : days) {

			switch (day) {
			default:
				System.out.println("SUNDAY");
			case MONDAY:
				System.out.println("MONDAY");
				break;
			case FRIDAY:
				System.out.println("FRIDAY");
				break;
			case SATURDAY:
				System.out.println("SATURDAY");
				break;
			case THURSDAY:
				System.out.println("THURSDAY");
				break;
			case TUESDAY:
				System.out.println("TUESDAY");
				break;
			case WEDNESDAY:
				System.out.println("WEDNESDAY");
				break;
			}
		}
	}
}
