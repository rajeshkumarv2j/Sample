package finalizeEx;

public class Syntax {
	public static void main1(String[] args) throws InterruptedException {
		Emp emp = new Emp(1,"1");
		Emp emp2 = new Emp(2,"2");
		Emp emp3 = new Emp(3,"3");
		Emp emp4 = emp3;
		emp3 = null;
		emp4 = null;
		new Emp(5, "5");
		new Emp(6, "6");
		System.gc();
		Thread.sleep(5000);
	}
	public static void main(String[] args) throws InterruptedException {
		for(int i=0;i<10000000l;i++){
			new Emp(i, ""+i);
		}
	}
}

class Emp {
	private int id;
	private String name;

	public Emp() {
	}

	Emp(int id, String name) {
		this.id = id;
		this.name = name;
		System.out.println("Emp Object is going to created..."+this.getId()+","+this.getName());
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public void finalize(){
		System.out.println("Emp Object is going to garbage collected.=================================================================.."+this.getId()+","+this.getName());
	}
}