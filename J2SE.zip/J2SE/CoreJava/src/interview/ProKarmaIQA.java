package interview;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class ProKarmaIQA {

	public static void main1(String[] args) {
		HashMap<String, String> hashMap = new HashMap<String, String>();
		hashMap.put("a", null);
		hashMap.put(null, null);
		String s = null;
		hashMap.put(s, "a0");
		hashMap.put("a", "10");
		System.out.println(hashMap.get(s));
		System.out.println(hashMap.size());
		System.out.println(hashMap);
		
	}

	public static void main2(String[] args) {
		int[] is = new int[] { 1, 2, 3, 4, 5, 6 };
		float[] f = (float[]) Array.newInstance(float.class, 5);
		Array array = null;
		for (float i : f) {
			System.out.println(i);
		}
		System.out.println(f instanceof Object);
		System.out.println(is instanceof Object);
		System.out.println(array instanceof Object);
	}

	public static void main3(String[] args) {
		Integer[] i = { 1, 2, 3, 4, 5, 6, 7, 8 };
		ArrayList<Integer> arrayList = new ArrayList<Integer>(Arrays.asList(i));
		for (Integer integer : arrayList) {
			System.out.println(integer);
			arrayList.remove(integer);
		}
		// Exception in thread "main" java.util.ConcurrentModificationException
	}

	public static void main4(String[] args) {
		ArrayList<Integer> arrayList = new ArrayList<Integer>();
		arrayList.add(1);
		arrayList.add(2);
		arrayList.add(3);
		System.out.println(arrayList);
		Iterator<Integer> iterator = arrayList.iterator();
		for (Iterator<Integer> itr = iterator; itr.hasNext();) {
			Integer integer = itr.next();
			if (integer == 1)
				itr.remove();
			// No CuncurrentModificationException
			if (integer == 2)
				arrayList.add(integer);
		}
		System.out.println(arrayList);
	}

	public static void main5(String[] args) {
		ArrayList<Integer> arrayList = new ArrayList<Integer>();
		arrayList.add(1);
		arrayList.add(2);
		arrayList.add(3);
		System.out.println(arrayList);
		for (Integer integer : arrayList) {
			arrayList.remove(integer);
		}
		System.out.println(arrayList);
		// Exception in thread "main" java.util.ConcurrentModificationException
	}

	public static void main6(String[] args) {
		Map<String, String> map = new HashMap<String, String>();
		map.put("", "");
		map.put("1", "1");
		map.put("2", "2");
		map.put("3", "3");
		map.put("4", "4");
		Set<Entry<String, String>> entries = map.entrySet();
		for (Entry<String, String> entry : entries) {
			map.remove("1");
		}
		// Exception in thread "main" java.util.ConcurrentModificationException
	}

	public static void main7(String[] args) {
		Map<String, String> map = new HashMap<String, String>();
		map.put("", "");
		map.put("1", "1");
		map.put("2", "2");
		map.put("3", "3");
		map.put("4", "4");
		System.out.println(map);
		Iterator<Entry<String, String>> iterator = map.entrySet().iterator();
		for (Iterator<Entry<String, String>> itr = iterator; itr.hasNext();) {
			Entry<String, String> entry = itr.next();
			entry.setValue("123123");
			entry.setValue("123123");
			System.out.println(entry.toString());
		}
		System.out.println(map);
	}

	public static void main8(String[] args) {
		Integer integer = null;
		int i = integer;
		System.out.println(i);
	}
	/*class Z{
		public static void main(String[] args) {
			
		}
	}*/
	
	/*package finalExm;
	public class AA{
		public void method(){
			System.out.println("A");
		}
	}
	final class BB extends AA{
		@Override
		public void method(){
			System.out.println("B");
		}
		public static void main(String[] args) {
			AA aa = new AA();
			aa.method();
			BB bb = new BB();
			bb.method();
			AA aa2 = new BB();
			aa2.method();
//			BB bb2 = new AA();
//			bb2.method();
		}
	}*/
	public int method(int a, int b){
		try{
			return a+b;
		}finally{
			return a-b;
		}
	}
	public static void main9(String[] args) {
		System.out.println(new ProKarmaIQA().method(6, 2));
	}
	
	public static void main(String[] args) {
		//main1(args);
		String s1 = new String("durga");
		String s2 = "durga";
		//String s3 = s1.intern();
		System.out.println(s2==s1.intern());
		try{
			System.out.println("A");
			Object object = null;
			object.toString();
		}catch (Exception e) {
			System.out.println("B");
		}finally{
			System.out.println("C");
		}
	}
	
	
	
	
	


	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

//	Can we override the overloaded method?
//	Print Hello Rajesh. Condition is syso should have only Rajesh not Hello.
//	Write Standalone Rest Web Service
//	Write standalone SOAP Service
//	Difference between ArrayList and Linked List
//	What is difference between JPA and Hibernet.
//	What are the extra featurers of Hiernate
//	Normalizations on database table creation
//	what is difference between Rest 1.4 and 1.7
//	can we get WSDL file in Restfull web service
//	When we will get Cuncurrent Modification exception
//	what is volatile
//	what is singleton
//	what is class level locking and object level locking
//	what is the perpose of hibernate versioning
//	which is better performance.. Writing joins on Indexed database tables or non indexed tables
//	I want to use a collection object which maintain insertion order and avoid duplicates
//	how to integrate JPA with Spring and Hibernate with Spring
//	when u go for setter injection when u go for constructor injection
//	what is dead lock and write a deadlock program
//	what is difference between JSF and Struts
//	what is difference between Rest and SOAP
//	write a JSF program which will give u OOM error with ajax tags and 504 error should be display
//	What is first level caching, what is secondLevel Caching
//	what is Maven Profile?
//	What is Maven Repository structure
//	what will happen when we call mvn clean
//	What are the Spring scopes? What is Spring default scope?
//	What is internal mechanizam of spring container
//	what disgn patter spring container is follwing
//	why every one is going for jsf instead of struts
//	What is hibernate lazy loading. Is that better?
//	What are the difference parsers you know
//	What are diffence XML Binders?
//	When we have to go for session in web application
//	can we start more than 1 process on sigle jvm
//	can we access any object or members from one process to another process
//	can we have two session factory object
//	can we use same entities in two different session facory objects
//	what is difference between foreach loop and normal for loop
//	what code review tools you are using
//	what are the logger levels
//	what is difference between application server and web server
//	How you will write Unit Testcases
//	i dont want to use my entity for updation and deletion and edition except selcetion. How to acheive this.
//	How hibernate is working internally when we go for lazy loading
//	*Why entities should implement Serializable
//	what is synchronous and asynchronous web services
//	How to create a new textbox with javascirpt
//	JPMN Work flow
//	BIRT work flow
//	how to avoid cuncurrentexception
//	What is the JRE internal memory mechanizam
//	How to avoid an object cloning

}
