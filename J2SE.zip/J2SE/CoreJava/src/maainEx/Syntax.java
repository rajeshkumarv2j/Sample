package maainEx;

public class Syntax {
	public static void main(String[] args) {
		System.out.println("Super");
	}
}
