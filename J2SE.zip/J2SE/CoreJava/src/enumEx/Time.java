package enumEx;

public enum Time {
	SECONDS(60), MINUTES(60), HOURS(24), DAYS(7), WEEKS(4), MONTHS(12), YEARS(
			10), DECADE(1);
	int value;

	Time(int value) {
		this.value = value;
	}
}