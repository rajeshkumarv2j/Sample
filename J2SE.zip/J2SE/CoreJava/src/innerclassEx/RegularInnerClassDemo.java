package innerclassEx;

import innerclassEx.RIOuter.RIInn;

public class RegularInnerClassDemo {
	public static void main(String[] args) {
		RIOuter rout = new RIOuter();
		
		RIInn inn = rout.new RIInn();
		inn.innerFun();
		
		rout.innerFun();
		
		
	}
}

class RIOuter {
	void innerFun() {
		RIInn1 inn1 = new RIInn1();
		inn1.innerFun();
	}

	private int iVar;
	private static int sVar;
	private  void iFun(){}
	private static void sFun(){}
	
	private int x=10;
//	we cannot write tatic memners in regular inner 	classes..
	private class RIInn1 {
//		static int i;
//		static void m1(){}
	
		private int x=20;
		
		void innerFun() {
			int x=30;
			
			System.out.println(x);
			System.out.println(this.x);
			System.out.println(RIOuter.this.x);
			
			System.out.println(iVar);
			System.out.println(sVar);
			iFun();
			sFun();
			
			System.out.println("Inner");
		}
		
	}

	protected class RIInn {
		void innerFun() {
			System.out.println("Inner");
		}
	}

	public class RIInn2 {

	}

	strictfp class RIInn3 {

	}

	abstract class RIInn4 {

	}

	final class RIInn5 {

	}
}