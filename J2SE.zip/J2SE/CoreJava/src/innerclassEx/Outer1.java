package innerclassEx;

class Outer1 {

	Inner in = new Inner();
	int i =10;
	char ch = 'c';
	public Outer1() {
		System.out.println(this);
//		System.out.println(in);
	}
	void set(){
		in.disp();
	}
	static class Inner{
		private float f;
		private int i;
		public Inner() {
			System.out.println(this);
		}
		public void setF(float f) {
			this.f = f;
		}
		public float getF() {
			return f;
		}
		void disp(){
			System.out.println(i);
		}
	}

	public static void main(String[] args) {
		// Outer outer = new Outer();
		// Inner in = outer.new Inner();
		// in.disp();
		Outer1.Inner in = new Outer1.Inner();
		in.f = 1.2f;
		in.disp();
	}
}
