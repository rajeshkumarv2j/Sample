package innerclassEx;

public class LocalInnerClassDemo {

}

//LI class can access outer class members and access local mmethod variables but local members variables should be final
//you cant write main in Inner/Local Inner classes
//we cant create static inner local classes
//we can create only final abstract strictfp local inner classes
class LIOuter {
	public static void main(String[] args) {
		new LIOuter().liFun();
		LIOuter.liStaticFun();
	}
	private int iVar;
	private static int sVar;
	private  void iFun(){}
	private static void sFun(){}
	
	private int x=10;
	private static int y=10;
	static{
		class QQQQ{
			
		}
	}
	{
		class WWW{
			
		}
	}
	public static void liStaticFun() {
		final int x1=10;
		int y1=10;
		
		class LIInn{
			private int x=10;
			
			void v1(){
//				System.out.println(iVar);
				System.out.println(sVar);
//				iFun();
				sFun();
				
				
				int x=10;
				System.out.println(x);
				System.out.println(this.x);
				System.out.println(new LIOuter().x);
				
				System.out.println(LIOuter.y);
				System.out.println(x1);
//				System.out.println(y1);
			}
		}
		LIInn inn = new LIInn();
		inn.v1();
	}
	static{
		class QQQQ{
			
		}
	}
	{
		class WWW{
			
		}
	}
	
	public void liFun() {
		final int x1=10;
		class LIInn{
			private int x=10;
			void v1(){
				int x=10;
				
				System.out.println(x);
				System.out.println(this.x);
				System.out.println(LIOuter.this.x);
				
				System.out.println(LIOuter.y);
				System.out.println(x1);
				
				System.out.println(iVar);
				iFun();
			}
		}
		LIInn inn = new LIInn();
		inn.v1();
		
		final class LIInner{
		}
		abstract class LIInner1{
		}
		strictfp class LIInner2{
		}
	}
}