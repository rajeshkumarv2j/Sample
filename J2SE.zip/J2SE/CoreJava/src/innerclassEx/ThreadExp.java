package innerclassEx;

class ThreadExp{

	public static void main(String[] args) {
		new Thread(new Runnable() {public void run() {for(int i=0; i<1000; i++){System.out.println("Rajesh"+i);}}}).start();
		new Thread(new Runnable() {public void run() {for(int i=0; i<1000; i++){System.out.println("Raj"+i);}}}).start();
	}
}
