package innerclassEx;

public class A {
	public void display1(){
		System.out.println("LocalDisplay...");
		System.out.println("LocalDisplay...");
	}
}
