package innerclassEx;

public class AnonymusClassDemo {

	interface Whicle {
		void drive();
	}

	class Car implements Whicle {
		@Override
		public void drive() {
			System.out.println("Car driving");
		}
	}

	public void loadOwnWhicle() {
		Whicle whicle = new Car();
		whicle.drive();

		final int f = 2;

		Whicle myWhicle = new Whicle() {
			int x = 10;

			public void drive() {
				System.out.println(x);
				System.out.println(f);
				System.out.println("My Whicle driving");
				exit();
			}

			void exit() {
				System.out.println(x);
				System.out.println("exit..");
			}
		};

		myWhicle.drive();
	}

	public static void main1(String[] args) {
		// Normal way
		// LoadMotor loadMotor = new LoadMotor();
		// loadMotor.start();

		int userId = 10;
		final String userName = "Rajesh";

		// Anonymus way
		LoadMotor motor = new LoadMotor() {
			int a = 10;
			int b = 20;

			@Override
			void start() {
				System.out.println("Anonymus block..");
				System.out.println(userName + " is starting..");
				super.start();
				System.out.println(a);
				System.out.println(b);
			}
		};
		motor.start();

	}
}

class LoadMotor {
	void start() {
		System.out.println("Strated...");
	}
}
