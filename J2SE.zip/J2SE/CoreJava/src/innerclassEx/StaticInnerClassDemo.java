package innerclassEx;

import innerclassEx.SIOuter.SIInner;


public class StaticInnerClassDemo {
	public static void main(String[] args) {
		SIInner inner = new SIOuter.SIInner();
		inner.innerFun();
	}
}

class SIOuter {
	public int iVar;
	private static int sVar;
	private  void iFun(){	}
	private static void sFun(){	}
	
	private int x=10;
	static int y=10;
	
//	In Static inner class we can write static and instance members.
//	Static inner class cannot access outer instance members
	static class SIInner {
		int x=10;
		static int y=10;
		
		void innerFun() {
			int x=10;
			int y=10;
			
			System.out.println(x);
			System.out.println(this.x);
			System.out.println(new SIOuter().x);
			System.out.println(y);
			System.out.println(SIInner.y);
			System.out.println(SIOuter.y);
			
			System.out.println(sVar);
			sFun();
			
			System.out.println(new SIOuter().iVar);
			new SIOuter().iFun();
		}
		
		static void innerFun1() {
			System.out.println(sVar);
			sFun();
			
			System.out.println(new SIOuter().iVar);
			new SIOuter().iFun();
		}
	}
}

class SIOut {

	void innerFun() {
		SIInn1 inn1 = new SIInn1();
		inn1.innerFun();
	}
	
	private  static class SIInn1 {
		void innerFun() {
			System.out.println("Inner");
		}
	}
	
	protected static class SIInn {
		void innerFun() {
			System.out.println("Inner");
		}
	}

	public static class SIInn2 {

	}

	strictfp static class SIInn3 {

	}

	abstract static class SIInn4 {

	}
	final static class SIInn5{
		
	}
}
class SITest{
	public static void main(String[] args) {
		SIOut.SIInn inn1 = new SIOut.SIInn();
		inn1.innerFun();
		
		SIOut out = new SIOut();
		out.innerFun();
	}
}