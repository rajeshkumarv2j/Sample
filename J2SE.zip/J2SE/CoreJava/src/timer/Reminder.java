package timer;

import java.awt.Toolkit;
import java.util.Calendar;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

public class Reminder {
    Timer timer;
    Toolkit toolkit;
    public Reminder(int seconds) {
//        timer = new Timer();
//        timer.schedule(new RemindTask(), seconds*1000);
    	toolkit = Toolkit.getDefaultToolkit();
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, 6);
        calendar.set(Calendar.MINUTE, 14);
        calendar.set(Calendar.SECOND, 0);
        Date time = calendar.getTime();

        timer = new Timer();
        timer.schedule(new RemindTask(), time);
	}

    class RemindTask extends TimerTask {
        public void run() {
            System.out.println("Time's up!");
            toolkit.beep();
            timer.cancel(); //Terminate the timer thread
        }
    }

    public static void main(String args[]) {
        new Reminder(5);
        System.out.println("Task scheduled.");
    }
}