package exceptions;

public class ClassNotFoudException {
	static{
		try {
			Class.forName("exceptions.ClassNotFoudException");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		try {
			Class.forName("exceptions.ClassNotFoudException");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		try {
			ClassLoader.getSystemClassLoader().loadClass("exceptions.ClassNotFoudException");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}