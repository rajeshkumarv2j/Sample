package exceptions;

public class Syntax {
	public static void main(String[] args) throws Throwable {
		Syntax syntax = new Syntax();
//		syntax.call();
		System.out.println(syntax.try1());
	}

	private void call() throws Throwable {
		System.out.println("In call");
		throw new Throwable();
	}
	
	int try1(){
		try{
			System.out.println("try..");
//			return 10;
		}catch (Exception e) {
			System.out.println("catch...");
			return 20;
		}finally{
			System.out.println("finally...");
			return 30;
		}
	}
}
