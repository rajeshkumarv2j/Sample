package exceptions;

import java.net.MalformedURLException;
import java.net.URL;

public class ThrowNull {
	public void action(){
		Service service = new Service();
		System.out.println(service.service());
	}
	public static void main(String[] args) {
		ThrowNull null1 = new ThrowNull();
		null1.action();
	}
}
class Service {
	public int service(){
		System.out.println("Service..");
		throw null;
	}
}

class Foo {

    public void doSomething(String arg) {}

    public void example() throws MalformedURLException {
    	if(new URL("http://www.yahoo.com").equals(new URL("http://www.yahoo.com"))){
    		
    	}
//        doSomething({ "foo", "bar" });
    }
    public static void main(String[] args) throws MalformedURLException {
    	Foo foo = new Foo();
    	foo.example();
	}
}