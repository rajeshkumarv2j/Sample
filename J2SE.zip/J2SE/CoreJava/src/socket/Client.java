package socket;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;

public class Client {
	public static void main(String[] args) throws UnknownHostException, IOException {
		Socket socket = new Socket("localhost", 9999);
		OutputStream outputStream = socket.getOutputStream();
		BufferedReader bufferedReader = null;
		PrintWriter printWriter = null;
		printWriter = new PrintWriter(outputStream,true);
		printWriter.println("Hi...");
		InputStream inputStream = socket.getInputStream();
		bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
		String s=null;
		if(bufferedReader.ready())
			s = bufferedReader.readLine();
		while(s!=null){
			System.out.println(s);
			s = bufferedReader.readLine();
		}
		printWriter.close();
		bufferedReader.close();
	}
}
