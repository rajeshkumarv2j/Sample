package socket;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
	public static void main(String[] args) throws IOException {
		ServerSocket serverSocket = new ServerSocket(9999);
		BufferedReader bufferedReader = null;
		PrintWriter printWriter = null;
		while(true){
			System.out.println("Waiting for Clients...");
			Socket socket = serverSocket.accept();
			InputStream inputStream = socket.getInputStream();
			OutputStream outputStream = socket.getOutputStream();
			bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
			String s = bufferedReader.readLine();
			while(s!=null){
				System.out.println(s);
				s = bufferedReader.readLine();
			}
			printWriter = new PrintWriter(outputStream,true);
			printWriter.println("Hi...");
			printWriter.close();
			bufferedReader.close();
			socket.close();
		}
		
	}
}
