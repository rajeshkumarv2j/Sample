package security;

import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.swing.JOptionPane;

import org.apache.commons.codec.binary.Base64;

public class CopyOfPasswordService {
	private static byte[] sharedvector = { 0x01, 0x02, 0x03, 0x05, 0x07, 0x0B,	0x0D, 0x11 };
	private static String key = "developersnotedotcom";
	private static byte[] keyArray;
	private static Cipher c;

	static {
		keyArray = new byte[24];
		byte[] temporaryKey = null;
		MessageDigest m = null;
		try {
			m = MessageDigest.getInstance("MD5");
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		try {
			temporaryKey = m.digest(key.getBytes("UTF-8"));
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}

		if (temporaryKey.length < 24) // DESede require 24 byte length key
		{
			int index = 0;
			for (int i = temporaryKey.length; i < 24; i++) {
				keyArray[i] = temporaryKey[index];
			}
		}
		try {
			c = Cipher.getInstance("DESede/CBC/PKCS5Padding");
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (NoSuchPaddingException e) {
			e.printStackTrace();
		}
	}

	public String EncryptText(String password) {
			try {
				c.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(keyArray, "DESede"), new IvParameterSpec(sharedvector));
			} catch (InvalidKeyException e) {
				e.printStackTrace();
			} catch (InvalidAlgorithmParameterException e) {
				e.printStackTrace();
			}
			byte[] encrypted = null;
			try {
				encrypted = c.doFinal(password.getBytes("UTF-8"));
			} catch (IllegalBlockSizeException e) {
				e.printStackTrace();
			} catch (BadPaddingException e) {
				e.printStackTrace();
			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			}
			return Base64.encodeBase64String(encrypted);
	}

	public String DecryptText(String password) {
			try {
				c.init(Cipher.DECRYPT_MODE, new SecretKeySpec(keyArray, "DESede"),	new IvParameterSpec(sharedvector));
			} catch (InvalidKeyException e) {
				e.printStackTrace();
			} catch (InvalidAlgorithmParameterException e) {
				e.printStackTrace();
			}
			byte[] decrypted = null;
			try {
				decrypted = c.doFinal(Base64.decodeBase64(password));
			} catch (IllegalBlockSizeException e) {
				e.printStackTrace();
			} catch (BadPaddingException e) {
				e.printStackTrace();
			}
			try {
				return new String(decrypted, "UTF-8");
			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			}
			return null;
	}

	public static void main(String[] args) {
		CopyOfPasswordService copyOfPasswordService = new CopyOfPasswordService();
		String encripted = copyOfPasswordService.EncryptText("Rajeshkumar.V");
		System.out.println(encripted);
		String decripted = copyOfPasswordService.DecryptText(encripted);
		System.out.println(decripted);
	}
}
