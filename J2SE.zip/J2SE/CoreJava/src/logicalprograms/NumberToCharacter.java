package logicalprograms;

public class NumberToCharacter {
/*	100	Hundred
 * 	1	One
 * 	2	Two
 * 3	Three
 * 
 * 10 
 * 	11	Eleven
 * 12	Twelve
 * 13	Thirteen
 * 14	Fourteen
 * 15	Fifteen
 * 16
 * 
 * 
 * 
 * 
 * 
 * */
	public static void main(String[] args) {
		System.out.println(21/10);
	}
	
	public static void main1(String[] args) {
		String input = args[0];
		int no = Integer.parseInt(input);
		int decimalNo = no/10;
	}
}
