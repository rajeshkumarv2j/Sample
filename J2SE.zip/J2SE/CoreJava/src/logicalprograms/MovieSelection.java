package logicalprograms;

import java.util.Arrays;

public class MovieSelection {
	public static void main(String[] args) {
		int movie_start[] = { 10, 12, 9, 14, 16, 14, 10};
		int movie_end[] = { 11, 13, 15, 16, 18, 18, 12};
		int[] time_diff = new int[movie_start.length];
		for (int i = 0; i < movie_start.length; i++) {
			time_diff[i] = movie_end[i] - movie_start[i];
		}
		int[] reverseArray = (int[]) cloneAnArray(time_diff);
		sortAnArrayAsc(reverseArray);
		reverseAnArray(reverseArray);
		int possibleMoviesCount = movie_start.length;
		for(int s=0,start=0,end=0; s<reverseArray.length; s++){
			for(int i=0; i<movie_start.length; i++)
				if((reverseArray[s] == time_diff[i])){
					start = movie_start[i];
					end = movie_end[i];
					time_diff[i]=-time_diff[i];
					break;
				}				
			for(int i=0; i<movie_start.length; i++)
				if(!(start==movie_start[i] && end==movie_end[i]) && start<=movie_start[i] && end>=movie_end[i]){
					--possibleMoviesCount;
					break;
				}
		}
		System.out.println(possibleMoviesCount);
	}
	
	public static Object cloneAnArray(Object time_diff) {
		Object object = null;
		if(time_diff instanceof int[])
			object = ((int[]) time_diff).clone();
		return object;
	}

	public static void sortAnArrayAsc(Object reverseArray){
		if(reverseArray instanceof int[])
			Arrays.sort((int[])reverseArray);
	}
	
	public static void reverseAnArray(Object reverseArray){
		int[] is = (int[]) reverseArray;
		for(int i=0,j=is.length-1; i < (is.length/2); i++, j--) {
			 int temp = is[i];
			 is[i] = is[j];
			 is[j] = temp;
		}
	}
}