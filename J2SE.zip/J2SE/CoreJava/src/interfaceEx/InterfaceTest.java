package interfaceEx;

public class InterfaceTest implements A, B {
	public static void main(String[] args) {
//		System.out.println(i);//The field i is ambiguous
	}
	@Override
	public void a() {
	}
}
interface A {
	int i = 10;
	void a();
}
interface B {
	int i = 20;
	void a();
}