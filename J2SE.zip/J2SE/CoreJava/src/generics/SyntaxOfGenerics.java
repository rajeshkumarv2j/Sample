package generics;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class SyntaxOfGenerics {

	<E> E method(E e) {
		return e;
	}

	private void foo0(List<?> list) {
	    Object o = list.get(0); // ok
	    String o1 = (String) list.get(0); // ok
//	    list.add(new Object()); // won't compile!
//	    list.addAll(new ArrayList<String>()); // won't compile!
	    // you cannot add anything, and only extract Object instances
	}

	private <E>void foo01(List<E> list) {
	    Object o = list.get(0);
	    String o1 =  (String) list.get(0); 
	    list.add((E) new Object()); 
	    list.addAll((Collection<? extends E>) new ArrayList<String>()); 
	}
	void foo(List<?> list){
		
	}

	void foo1(List<? extends Comparable> comparables){
		
	}
	
	void foo2(List<? super Comparable> list){
		
	}
	
	<E>void foo3(List<E> list){
		
	}
	<E>E foo4(List<E> list){
		E e = list.get(0);
		return e;
	}
	
	public static void main(String[] args) {
		SyntaxOfGenerics generics = new SyntaxOfGenerics();
		System.out.println(generics.method(123123));
		System.out.println(generics.method("String"));
		System.out.println(generics.method(new Object()));
		System.out.println(generics.method(generics.new Emp()));

	}

	class Emp {
		int id = 1;
		String name = "jatin";
	}
}
