package generics;

import java.util.ArrayList;

public class GenericsDemo1 {
	public static void main(String[] args) {
		Integer[] numbers = new Integer[10];
		ArrayList<Integer> numbers2 = new ArrayList<Integer>();
		displayArray(numbers);
//		displayArray1(numbers2);
	}
	static void displayArray(Number[] values){
		for (Number number : values) {
			System.out.println(number);
		}
	}
	static void displayArray1(ArrayList<Number> values){
		for (Number number : values) {
			System.out.println(number);
		}
	}
}
