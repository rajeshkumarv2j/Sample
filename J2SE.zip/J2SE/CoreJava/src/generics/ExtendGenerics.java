package generics;

import java.util.ArrayList;
import java.util.List;

public class ExtendGenerics {
	static class Creature {}
	static class Human extends Creature {}
	static class Person extends Human {}
	static class Father extends Person {}
	static class Son extends Father {}
	
	public static void main(String[] args) {
		/*
		 * This eList could hold Person object and sub class of Person objects(Father and Son), 
		 * But not super classes(Human and Creature)
		 */
		List<? extends Person>  eList = new ArrayList<Person>();
		List<? extends Person>  eList1 = new ArrayList<Father>();
		List<? extends Person>  eList2 = new ArrayList<Son>();
//		List<? extends Person>  eList3 = new ArrayList<Human>();//Error
//		List<? extends Person>  eList4 = new ArrayList<Creature>();//Error

	//------------------------------:WRITING:--------------------------------------		
	/*
	 * You can't add an Person because eList could be pointing at a List<Father>.
	 * You can't add a Father because eList could be pointing at a List<Son>.
	 * You can't add a Son because eList could be pointing at a List<Other Child Of Father>.
	 * 
	 */
//		eList2.add(new Person());//Error
//		eList2.add(new Father());//Error
//		eList2.add(new Son());//Error

//--------------------------------:READING:---------------------------------
		Person person = eList.get(0);// valid... Even sub classes of Parent objects comes(Father, Son) it can be referenced by super class(Person)
		Father father = (Father) eList.get(0);//Error without type cast, Not sure which sub object of Person might come
		Son son = (Son) eList.get(0);//Error without type cast, Not sure which sub object of Person might come
		
		
		/*
		 * This eList could hold Person objects and super class objects of Person(Human and Creature)
		 * But not sub classes objects(Father, Son)
		 */
		List<? super Person>  sList = new ArrayList<Person>();
		List<? super Person>  sList1 = new ArrayList<Human>();
		List<? super Person>  sList2 = new ArrayList<Creature>();
//		List<? super Person>  sList3 = new ArrayList<Father>();//Error
//		List<? super Person>  sList4 = new ArrayList<Son>();//Error
		
//------------------------------:WRITING:--------------------------------------		
		/*
		 * You can't add a Human because sList could be pointing at a List<Other Super Of Person>.
		 * You can't add a Creature because sList could be pointing at a List<Other Super Of Person>.
		 *	Note:Person is child here 
		 */
		sList.add(new Person());
//		sList.add(new Human());//Error
//		sList.add(new Creature());//Error

		//--------------------------------:READING:---------------------------------
		Person person1 = (Person) sList.get(0);// Error... without type cast, Not sure which super object of Person might come
		Human human = (Human) sList.get(0);//Error... without type cast, Not sure which super object of Person might come
		Creature creature = (Creature) sList.get(0);//Error without type cast, Not sure which super object of Person might come
		
	}
}
