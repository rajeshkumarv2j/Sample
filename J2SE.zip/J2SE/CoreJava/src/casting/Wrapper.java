package casting;

public class Wrapper {
	public static void main(String[] args) {
		Integer integer = new Integer(10);
		Integer integer1 = new Integer(10);
		System.out.println(integer1 == integer);
		System.out.println(integer1.equals(integer));
		System.out.println(integer1.intValue() == integer.intValue());
		
		Integer i = null;
		int i1 = i;
		System.out.println(i1);
	}
}
