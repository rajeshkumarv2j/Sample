package casting;

public class WrapperEx {
	public static void main(String[] args) {
		Integer i = new Integer(100);
		Integer i1 = new Integer(100);
		System.out.println(i <= i1);
		System.out.println(i >= i1);
		System.out.println(i != i1);
		
		System.out.println(i.intValue() <= i1.intValue());
		System.out.println(i.intValue() >= i1.intValue());
		System.out.println(i.intValue() != i1.intValue());
		
		
		/*while (i <= i1 && i >= i1 && i != i1) {
			System.out.println("Hi...");
		}*/
	}
}
