package casting;

public class Syntax {
	public static void main(String[] args) {
		String s ="";
		Integer i = 2;
//		s = (String)i;
		
		A a = new  A();
		
		B b = new B();
		C c = new C();
		a=b;
		b=(B) a;
		
		
		Syntax syntax = new Syntax();
		syntax.display(b);
		syntax.display(c);
	}
	void display(A a){
		if(a instanceof B){
			B b = (B) a;
			b.display();
		}
		if(a instanceof C){
			C c = (C) a;
			c.display();
		}
	}
}

class A{
	/*void display(){
		System.out.println("A");
	}*/
}
class B extends A{
	void display(){
		System.out.println("B");
	}
}

class C extends A{
	void display(){
		System.out.println("C");	
	}
}
