package collectionsEx;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;

public class LinkedHashSetEx {
	
	public static void main(String[] args) {
		HashSet<String> hashSet = new LinkedHashSet<String>();
		hashSet.add("Rajeshkumar.V");
		hashSet.add("Jaanavi");
		hashSet.add("Jatin");
		hashSet.add("Amma");
		hashSet.add("Nana");
		Iterator<String> iterator = hashSet.iterator();
		while(iterator.hasNext())
			System.out.println(iterator.next());
		
	}
}
