package collectionsEx;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;

public class HashTableExample {

	public static void main(String[] args) {

		Hashtable<String, String> myHashtable = new Hashtable<String, String>();
		myHashtable.put("1", "1");
		myHashtable.put("2", "1");
		myHashtable.put("3", "1");
		myHashtable.put("4", "1");
		myHashtable.put("5", "1");
		myHashtable.put("6", "1");
		Iterator<String> it = myHashtable.keySet().iterator();
		System.out.println("HashTable : " + myHashtable);

		while (it.hasNext()) {
			String key = it.next();
//			if (key.equals("3"))
//				myHashtable.put(key + "new", "new3");
//			java.util.ConcurrentModificationException
		}
		System.out.println("HashTable : " + myHashtable);

		myHashtable = new Hashtable<String, String>();
		myHashtable.put("1", "1");
		myHashtable.put("2", "1");
		myHashtable.put("3", "1");
		myHashtable.put("4", "1");
		myHashtable.put("5", "1");
		myHashtable.put("6", "1");
		Iterator<String> it1 = myHashtable.keySet().iterator();

		for(Iterator<String> it2 = it1; it2.hasNext();){
			String key = it1.next();
//			if (key.equals("3"))
//				myHashtable.put(key + "new", "new3");
//			java.util.ConcurrentModificationException
		}
		System.out.println("HashTable : " + myHashtable);
	
	
		
		Hashtable<String, String> myHashtable1 = new Hashtable<String, String>();
		myHashtable1.put("1", "1");
		myHashtable1.put("2", "1");
		myHashtable1.put("3", "1");
		myHashtable1.put("4", "1");
		myHashtable1.put("5", "1");
		myHashtable1.put("6", "1");
		
		Enumeration<String> enumeration = myHashtable1.elements();
		while (enumeration.hasMoreElements()) {
			String string = (String) enumeration.nextElement();
			myHashtable1.remove(string);
		}
		System.out.println("HashTable : " + myHashtable1);
	
	}

}