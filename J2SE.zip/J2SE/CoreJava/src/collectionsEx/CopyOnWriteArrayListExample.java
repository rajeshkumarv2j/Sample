package collectionsEx;

import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;

public class CopyOnWriteArrayListExample {

	public static void main(String args[]) {

		CopyOnWriteArrayList<String> threadSafeList = new CopyOnWriteArrayList<String>();
		threadSafeList.add("Java");
		threadSafeList.add("J2EE");
		threadSafeList.add("Collection");

		Iterator<String> failSafeIterator = threadSafeList.iterator();
		while (failSafeIterator.hasNext()) {
			String delString = (String) failSafeIterator.next();
			System.out.printf("Read from CopyOnWriteArrayList : %s %n",
					delString);
			if(delString.equals("J2EE"))
				threadSafeList.remove(delString);
		}
		System.out.println(threadSafeList);
	}
}