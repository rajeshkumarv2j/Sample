package collectionsEx;

import java.util.*;
import java.util.Map.Entry;

class HashMapDemo1 {
	public static void main(String args[]) {
		String fruites = "Hi Say Hi To All Who Wont Say Hi Or Say Good Morning To All Who You See In Morning";
		String[] spiltedArray = fruites.split("\\s");
		Map<String, Integer> stringWithCount = new HashMap<String, Integer>();
		for (String key : spiltedArray) {
			if(stringWithCount.containsKey(key)){
				for(Entry<String, Integer> set : stringWithCount.entrySet()){
					if(set.getKey().equals(key)){
						set.setValue(set.getValue()+1);
					}
				}
			}else{
				stringWithCount.put(key, 1);
			}
		}
		System.out.println(stringWithCount);
	}
}