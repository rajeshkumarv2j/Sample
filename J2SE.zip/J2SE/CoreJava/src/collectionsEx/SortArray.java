package collectionsEx;

import java.util.ArrayList;
import java.util.Arrays;


public class SortArray {

	public static void main(String[] args) {
		Integer[] integers = {1,54,222,4,7777,32,98,34,23,97,543,66};
//		ArrayList<Integer> arrayList = new ArrayList<Integer>(Arrays.asList(integers));
		System.out.println(Arrays.asList(integers));
		Arrays.sort(integers);
		System.out.println(Arrays.asList(integers));
	}

}