package collectionsEx;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.TreeMap;
import java.util.TreeSet;

public class EmployeeSortById {

	static Object object = null;
	Object object2 = null;
	
	public static void main(String[] args) {
	/*	EmployeeSortById employeeSortById = null;
		System.out.println(employeeSortById.object);//No Null Pointer Exception
		System.out.println(employeeSortById.object2);//Null pointer Exception
*/		List<Employee> employees = new ArrayList<Employee>();
		employees.add(new Employee(2, "rajesh3"));
		employees.add(new Employee(1, "rajesh4"));
		employees.add(new Employee(4, "rajesh1"));
		employees.add(new Employee(3, "rajesh2"));
		System.out.println(employees);

		Collections.sort(employees);

		System.out.println(employees);
//		TreeSet<Employee> employees2 = new TreeSet<Employee>();
//		employees2.addAll(employees);
//		System.out.println(employees2);
	}
}

class Employee implements Comparable<Employee> {
	private Integer empId;
	private String empName;

	public Employee() {
	}

	public Employee(Integer empId, String empName) {
		this.empId = empId;
		this.empName = empName;
	}

	public Integer getEmpId() {
		return empId;
	}

	public void setEmpId(Integer empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((empId == null) ? 0 : empId.hashCode());
		result = prime * result + ((empName == null) ? 0 : empName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		if (empId == null) {
			if (other.empId != null)
				return false;
		} else if (!empId.equals(other.empId))
			return false;
		if (empName == null) {
			if (other.empName != null)
				return false;
		} else if (!empName.equals(other.empName))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + "]";
	}

//	Sort with Employee Id
	/*@Override
	public int compareTo(Employee o) {
		if (this.empId <= o.empId) {
			return -1;
		} else {
			return 1;
		}
	}*/
	
	// Sort with Employee Name
	@Override
	public int compareTo(Employee o) {
		return this.empName.compareTo(o.empName);
	}
}