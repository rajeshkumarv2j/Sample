package collectionsEx;

import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class ConcurrentHashMapExample {

	public static void main(String[] args) {

		Hashtable<String, String> myHashtable = new Hashtable<String, String>();
		myHashtable.put("1", "1");
		myHashtable.put("2", "1");
		myHashtable.put("3", "1");
		myHashtable.put("4", "1");
		myHashtable.put("5", "1");
		myHashtable.put("6", "1");
		System.out.println("HashTable before iterator: " + myHashtable);
		
		Enumeration<String> enumeration = myHashtable.elements();
		// Inside the enumeration we can remove elements, But inside Iteration
		// we cant remove/update the elements except iterator.remove()
		for(; enumeration.hasMoreElements(); ){
			String g = enumeration.nextElement();
			System.out.print(g+",");
			myHashtable.remove(g);
			myHashtable.put(g + "new", "new3");
		}
		System.out.println("HashTable after iterator with enumerator: " + myHashtable);
		
		Iterator<String> it2 = myHashtable.keySet().iterator();

		while (it2.hasNext()) {
			String key = it2.next();
			if (key.equals("3"))
				myHashtable.put(key + "new", "new3");
		}
		System.out.println("HashTable after iterator: " + myHashtable);
		
		
		// ConcurrentHashMap
		Map<String, String> myMap = new ConcurrentHashMap<String, String>();
		myMap.put("1", "1");
		myMap.put("2", "1");
		myMap.put("3", "1");
		myMap.put("4", "1");
		myMap.put("5", "1");
		myMap.put("6", "1");
		System.out.println("ConcurrentHashMap before iterator: " + myMap);
		
		Set<Entry<String,String>> entries = myMap.entrySet();
		
//		This below also wont work out for HashMap
		for (Iterator<Entry<String, String>> iterator = entries.iterator(); iterator.hasNext();) {
			Entry<String, String> entry = (Entry<String, String>) iterator
					.next();
			entry.setValue("1212");
		}
		System.out.println("......................");
		
		Iterator<String> valuesIterator = myMap.values().iterator();
		
		for (Iterator<String> iterator = valuesIterator; iterator.hasNext();) {
			System.out.println(iterator.next());
			iterator.remove();
		}
		
		Iterator<String> it = myMap.keySet().iterator();

		while (it.hasNext()) {
			String key = it.next();
			if (key.equals("3"))
				myMap.put(key + "new", "new3");
		}
		System.out.println("ConcurrentHashMap after iterator: " + myMap);

		// HashMap
		myMap = new HashMap<String, String>();
		myMap.put("1", "1");
		myMap.put("2", "1");
		myMap.put("3", "1");
		myMap.put("4", "1");
		myMap.put("5", "1");
		myMap.put("6", "1");
		System.out.println("HashMap before iterator: " + myMap);
		Iterator<String> it1 = myMap.keySet().iterator();

		while (it1.hasNext()) {
			String key = it1.next();
			if (key.equals("3"))
				myMap.put(key + "new", "new3");
		}
		System.out.println("HashMap after iterator: " + myMap);
	}

}