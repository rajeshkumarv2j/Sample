package collectionsEx;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class CollectionsExample {

	public static void main(String[] args) {
		Map<String, String> map = new HashMap<String, String>();
		map.put("1", "1");
		map.put("2", "1");
		map.put("3", "1");
		map.put("4", "1");
		map.put("5", "1");
		map.put("6", "1");
		
		System.out.println(map);
		Map<String, String> map2 = Collections.synchronizedMap(map);
		System.out.println(map2);
		
		System.out.println(Collections.EMPTY_LIST);
		
		System.out.println(Collections.EMPTY_MAP);
		
		System.out.println(Collections.EMPTY_SET);
		
		List<String> strings = new ArrayList<String>(map.keySet());
		System.out.println(strings);
		Collections.swap(strings, 0, 5);
		System.out.println(strings);
		
		List<String> listElements = new ArrayList<String>();
		listElements.addAll(strings);
		Set<String> strings2 = new HashSet<String>(listElements);
		System.out.println(strings2);
		
		
		List<String> unModifiedList = Collections.unmodifiableList(strings);
		System.out.println("unSortedList.."+unModifiedList);
//		java.lang.UnsupportedOperationException will come if we try to change the unmodified list
		
		Collections.sort(strings, new Comparator<String>() {
			
			@Override
			public int compare(String o1, String o2) {
				return o1.compareTo(o2);
			}
		});
		
		System.out.println("sortedList.."+strings);
		
		List<List<String>> strings3 = Collections.singletonList(strings);
		System.out.println(strings3);
		
		Collections.reverse(strings);
		System.out.println(strings);
	}

}