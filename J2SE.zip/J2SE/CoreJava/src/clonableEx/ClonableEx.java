package clonableEx;

public class ClonableEx {

}
