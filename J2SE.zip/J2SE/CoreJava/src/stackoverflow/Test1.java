package stackoverflow;

public class Test1 {

	{System.out.println(k++);}
	static int k = 0;
	Test1 test1 = new Test1();
	public static void main(String[] args) {
		{new Test1();}
	}
}