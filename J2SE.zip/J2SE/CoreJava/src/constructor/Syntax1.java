package constructor;

public class Syntax1 {
	public static void main(String[] args) {
		D d = new D("");
	}
}

class C{
	public C() {
		System.out.println("C para");
	}
	public C(String string) {
		this();
		System.out.println("C arg");
	}
}
class D extends C{
	public D() {
		super("");
		System.out.println("D defult..");
	}
	public D(String s){
//		super();
		this();
//		super(s);
		System.out.println("D arg...");
	}
}