package constructor;

public class Syntax {
	public static void main(String[] args) {
//		A a = new A();
	}
}
class A{
	A(String string){
		
	}
}
class B{
	B(){
		
	}
}

class A1{
	A1(String string){
		
	}
}
class B1{
	B1(){
	}
}
class Parent{
	public Parent() {
		System.out.println("In parent Default");
	}
	public Parent(String s){
		this();
		System.out.println("In parent Parameter Costructor");
	}
	public static void main(String[] args) {
		Parent parent = new Parent("Test");
	}
}
