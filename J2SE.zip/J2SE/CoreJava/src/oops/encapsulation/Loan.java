package oops.encapsulation;

public class Loan {
	private int duration; // private variables examples of encapsulation
	private String loan;
	private String borrower;
	private String salary;

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	public String getLoan() {
		return loan;
	}

	public void setLoan(String loan) {
		this.loan = loan;
	}

	public String getBorrower() {
		return borrower;
	}

	public void setBorrower(String borrower) {
		this.borrower = borrower;
	}

	public String getSalary() {
		return salary;
	}

	public void setSalary(String salary) {
		this.salary = salary;
	}

	// public constructor can break encapsulation instead use factory method
	private Loan(int duration, String loan, String borrower, String salary) {
		this.duration = duration;
		this.loan = loan;
		this.borrower = borrower;
		this.salary = salary;
	}

	// no argument consustructor omitted here

	// create loan can encapsulate loan creation logic
	public static Loan createLoan(int duration, String loan, String borrower,
			String salary) {

		// processing based on loan type and than returning loan object
		return new Loan(duration, loan, borrower, salary);
	}

	public static void main(String[] args) {
		System.out.println(Loan
				.createLoan(1, "Housing Loan", "Rajesh", "40000"));
	}
}
