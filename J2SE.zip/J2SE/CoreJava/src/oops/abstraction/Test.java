package oops.abstraction;

public class Test {
	public static void main(String[] args) {
		Player player = new VLSPlayer("VLC Player");
		player.start();
		player.pause();
		player.stop();
		System.out.println(player);
	}
}
