package oops.abstraction;

public abstract class Loan {
	
}
