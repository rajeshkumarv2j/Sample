package oops.abstraction;

public abstract class AbstractPlayer implements Player{
	private String playerName;
	public AbstractPlayer() {
	}
	public AbstractPlayer(String playerName) {
		this.playerName = playerName;
	}
	public abstract void start();

	public abstract void stop();

	@Override
	public void pause() {
		System.out.println(playerName+" paused Successfully !!!");
	}
	@Override
	public String toString() {
		return "AbstractPlayer [playerName=" + playerName + "]";
	}
}