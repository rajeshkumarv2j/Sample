package oops.abstraction;

public interface Player {
	public void start();
	public void stop();
	public void pause();
}
