package oops.abstraction;

public class VLSPlayer extends AbstractPlayer{

	public VLSPlayer() {
	}
	
	public VLSPlayer(String player) {
		super(player);
	}
	
	@Override
	public void start() {
		System.out.println("VLS Player has Started !!!");
	}

	@Override
	public void stop() {
		System.out.println("VLS Player has Stoped !!!");
	}

}