package oops;

import java.util.List;

public class Overloading {
	/*int a(Integer a) {
		System.out.println("Int");
		return a;
	}*/

	/*Long a(Long a) {
		System.out.println("Long");
		return a;
	}*/
	
	public static  void doSomething(Integer obj) {
	    System.out.println("Integer called");
	}
	
	/*public static  void doSomething(Object obj) {
		System.out.println("Object called");
	}*/
	
	public static  void doSomething(char[] obj) {
		System.out.println("Array called");
	}
	
	List a(List emp){
		return emp;
	}
	Object a(Object a){
		System.out.println("Object");
		return a;
	}
	
	String a(String a){
		System.out.println("String");
		return a;
	}

	public static void main(String[] args) {
		Overloading overloading = new Overloading();
		char[] c = null;
		overloading.doSomething(c);
	}
}