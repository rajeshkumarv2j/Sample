package oops;
/**
 * When the compiler has to choose which of the two test methods to execute
 * (since null can be passed to both), it chooses the one with the more specific
 * argument type - test(String s) - String is more specific than Object since it
 * is a sub-class of Object.
 * 
 * @author velishra
 * 
 */
class PassingNullToOverloadedMethod {

	public void test(Object o) {
		System.out.println("Object");
	}

	public void test(String s) {
		System.out.println("String");
	}

	public static void main(String[] args) {
		PassingNullToOverloadedMethod q = new PassingNullToOverloadedMethod();
		q.test(null);
	}
}


/**
 * 
 * @author velishra
 *
 */
class Overload {

    public static void main(String[] args) {
//        new Overload().test(null);
    }

    public void test(String s) {
        System.out.println("String");
    }

    public void test(Object o) {
        System.out.println("Object");
    }
    
    public void test(Integer s) {
        System.out.println("Integer");
    }
}


interface Callee {
	public void foo(Object o);

	public void foo(String s);

	public void foo(Integer i);
}

class CalleeImpl implements Callee {
	public void foo(Object o) {
		System.out.println("foo(Object o)");
	}

	public void foo(String s) {
		System.out.println("foo(\"" + s + "\")");
	}

	public void foo(Integer i) {
		System.out.println("foo(" + i + ")");
	}

	public static void main(String[] args) {
		Callee callee = new CalleeImpl();

		Object i = new Integer(12);
		Object s = "foobar";
		Object o = new Object();

		callee.foo(i);
		callee.foo(s);
		callee.foo(o);
	}
}
