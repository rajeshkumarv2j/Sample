package oops.a;
public class A {
	protected void method() {
		System.out.println("A");
	}
}


