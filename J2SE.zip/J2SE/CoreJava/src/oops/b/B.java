package oops.b;

import oops.a.A;

class B extends A {
	@Override
	protected void method() {
		System.out.println("B");
	}
	public static void main(String[] args) {
		A a = new A();
		/*
		 * Error. As you cannot access protected method on parent
		 * object from outside of parent object package..
		 */
//		a.method(); 
		A a1 = new B();
		/*
		 * Error. As you cannot access protected method on parent
		 * object reference from outside of parent object package..
		 */
//		a1.method();
		B b = new B();
		b.method();
	}
}