package oops;


public class EqualsHashcode {
	public static void main(String[] args) {
		String s = "   ";
		String s1 = "  ";
		System.out.println(s.equals(s1));
		System.out.println(s.hashCode());
		System.out.println(s1.hashCode());
		
		EqualsHashcode equalsHashcode = new EqualsHashcode();
		equalsHashcode.value = s.toCharArray();
		System.out.println(equalsHashcode.hashCode());
	}
	
	
	private int hash;
	private char value[];
	@Override
	public int hashCode() {
		int h = hash;
		if (h == 0 && value.length > 0) {
			char val[] = value;

			for (int i = 0; i < value.length; i++) {
				h = 31 * h + val[i];
			}
			hash = h;
		}
		return h;
	}
}

class Sample{
	int method() throws IndexOutOfBoundsException {
		return 0;
	}
}

class Emp1 extends Sample{
	int eId;
	String eName;
	String eAddress;
	public Emp1() {
	}
	public Emp1(int eId, String eName, String eAddress){
		this.eId = eId;
		this.eAddress = eAddress;
		this.eName = eName;
	}

	public boolean equals(Object object) {
		if (object == null || getClass() != object.getClass())
			return false;
		if (this == object)
			return true;
		Emp1 emp = (Emp1) object;
		if(eAddress==null){
			if(emp.eAddress!=null)
				return false;
		}
		if(eName==null){
			if(emp.eName!=null)
				return false;
		}
		if (this.eId != emp.eId || !this.eAddress.equals(emp.eAddress)
				|| !this.eName.equals(emp.eName))
			return false;
		return true;
	}
	
	public int hashCode(){
		int hash = 1, prime = 31;
		hash = prime * hash + eId;
		hash = prime * hash + eAddress != null ? eAddress.hashCode() : 0;
		hash = prime * hash + eName != null ? eName.hashCode() : 0;
		return hash;
	}
	
	int method()throws ArrayIndexOutOfBoundsException{
		return new Access().method();
	}
}