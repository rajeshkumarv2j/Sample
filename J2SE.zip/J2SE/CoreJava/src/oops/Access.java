package oops;

public class Access {
	protected int method(){
		return 0;
	}
}
