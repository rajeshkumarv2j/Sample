package oops;

public class Main {
	public static void main(String[] args) {

	}

	public static void main(int args) {

	}
	public static void main(int[] args) {
		
	}
}
