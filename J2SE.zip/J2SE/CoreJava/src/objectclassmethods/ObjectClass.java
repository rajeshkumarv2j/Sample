package objectclassmethods;
public class ObjectClass{
	public static void main(String[] args) {
		String s1="raj";
		String s2="raj";
		System.out.println(s1.equals(s2));
		System.out.println(s1.hashCode());
		System.out.println(s2.hashCode());
	}
}