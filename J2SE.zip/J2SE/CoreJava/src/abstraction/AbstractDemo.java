package abstraction;

public class AbstractDemo {

	public static void main(String[] args) {
		System.out.println("CLicked Facebook!");
		System.out.println("Facebook open..");
	}
	private class S extends V{
		public void f1() {
			System.out.println();
		}
	}
}
interface I{
	void f1();
}
abstract class V implements I{

}

