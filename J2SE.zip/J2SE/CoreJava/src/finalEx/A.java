package finalEx;

final class A {

	int i=10;
	final char ch;
	A() {
		i =0;
		ch = 'a';
	}
	A(int x){
		i = x;
		ch = ' ';
	}
}
/*class B extends A{
	
}*/