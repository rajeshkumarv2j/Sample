package volatileEx;

public class VolatileTest {
	private static int VOLATILE_VAR = 0;

	public static void main(String[] args) {
		Thread t1 = new Thread("Readable Thread...") {
			public void run() {
				int x = VOLATILE_VAR;
				while (true) {
					if (x != VOLATILE_VAR) {
						System.out.println("Print VOLATILE_VAR..."+VOLATILE_VAR);
						x = VOLATILE_VAR;
					}
				}
			};
		};

		Thread t2 = new Thread("Writable Thread...") {
			@Override
			public void run() {
				int t2var = VOLATILE_VAR;
				while (true) {
					++VOLATILE_VAR;
					System.out.println("Increment VOLATILE_VAR..."+VOLATILE_VAR);
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}
		};

		t2.start();
		t1.start();
	}
}
