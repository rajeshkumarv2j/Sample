package threadEx;

public class PrintNoByAlternatingThreads {
	Print print = new Print();

	Thread t1 = new Thread() {
		public void run() {
				doOneByOne();
		};
	};

	Thread t2 = new Thread() {
		public void run() {
				doOneByOne();
		};
	};

	public static void main(String[] args) throws InterruptedException {
		PrintNoByAlternatingThreads alternatingThreads = new PrintNoByAlternatingThreads();
		alternatingThreads.t1.start();
		alternatingThreads.t2.start();
	}
	
	public void doOneByOne() {
		while (true) {
			if (print.i > 20)
				break;
			print.print();
			synchronized (print) {
				print.notify();
				try {
					print.wait();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				print.notify();
			}
		}
	}
}

class Print {
	int i = 1;

	public void print() {
		System.out.println(Thread.currentThread().getName() + "..." + this.i++);
	}
}
