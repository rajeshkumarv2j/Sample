package threadEx;

public class DaemonG {
	public static void main(String[] args) {
		new WorkerThread().start();
		try {
			Thread.sleep(7500);
		} catch (InterruptedException e) {
		}
		System.out.println("Main Thread ending");
	}
}

class WorkerThread extends Thread {

	public WorkerThread() {
		// When false, (i.e. when it's a user thread),
		// the Worker thread continues to run.
		// When true, (i.e. when it's a daemon thread),
		// the Worker thread terminates when the main
		// thread terminates.
		setDaemon(true);
		
		/*
		 * setDaemon(false)	: User Threads... No one will kill User Threads...
		 * setDaemon(true) 	: Daemon Threads...	JVM may kill this thread if there is no user thread available.
		 * 
		 * 	It provides services to user threads for background supporting tasks. It has no role in life than to serve user threads.
			Its life depends on user threads.
			It is a low priority thread.

		 * JVM will only shut down a program when all user threads have terminated.
		 * Daemon threads are terminated by the JVM when there are no longer any user threads running, including the main thread of execution.
		 * 
		 * If you want to make a user thread as Daemon, it must not be started otherwise it will throw IllegalThreadStateException.
		 * 
		 * difference between daemon thread and user thread is that as soon as all user thread finish execution java program or JVM terminates itself, JVM doesn't wait for daemon thread to finish there execution.
		 * 
		 * As soon as last non daemon thread finished JVM terminates no matter how many Daemon thread exists or running inside JVM
		 * 
		 * Thread inherits its daemon nature from the Thread which creates it i.e. parent Thread and since main thread is a non daemon thread, any other thread created from it will remain non-daemon until explicitly made daemon by calling setDaemon(true).
		 * 
		 * 1) JVM doesn't wait for any daemon thread to finish before existing.
		 * 2) Daemon Thread are treated differently than User Thread when JVM terminates, finally blocks are not called, Stacks are not unwounded and JVM just exits.
		 * 
		 * 
		 */
	}
	

	public void run() {
		int count = 0;

		while (true) {
			System.out.println("Hello from Worker " + count++);

			try {
				sleep(5000);
			} catch (InterruptedException e) {
			}finally{
				System.out.println("End");
			}
		}
	}
}