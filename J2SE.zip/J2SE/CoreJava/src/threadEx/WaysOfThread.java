package threadEx;

public class WaysOfThread {
	public static void main(String[] args) {
		Thread thread = new Thread();
		thread.start();
		
		new Thread(){
			@Override
			public void run() {
				for(int i=0; i<5; i++)
					System.out.println(Thread.currentThread()+"  "+i);
			};
		}.start();
//		thread1.start();
//		
//		new Thread(thread1).start();
//		new Thread(thread1).start();
//		new Thread(thread1).start();
//		new Thread(thread1).start();
	}
}
