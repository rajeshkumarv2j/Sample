package threadEx;

public class ProducerConsumerMine {
	SharedResource sharedResource = new SharedResource();

	Thread consumer = new Thread(new Runnable(){
		public void run(){
			synchronized (sharedResource) {
				while(true){
					sharedResource.notify();
					System.out.println("Buffer Size...Consumer..."+(sharedResource.buffer-1));
					try {
						Thread.sleep(500);
					} catch (InterruptedException e1) {
						e1.printStackTrace();
					}
					if(--sharedResource.buffer==0)
						try {
							sharedResource.wait();
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
				}
			}
		}
	});
	
	Thread producer = new Thread(new Runnable(){
		public void run(){
			synchronized (sharedResource) {
				while(true){
					sharedResource.notify();
					System.out.println("Buffer Size...Producer..."+(sharedResource.buffer+1));
					try {
						Thread.sleep(500);
					} catch (InterruptedException e1) {
						e1.printStackTrace();
					}
					if(++sharedResource.buffer==9)
						try {
							sharedResource.wait();
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
				}
			}
		}
	});
	
	class SharedResource{
		public int buffer = 0;
	}
	
	public static void main(String[] args) {
		ProducerConsumerMine delete = new ProducerConsumerMine();
		delete.producer.start();
		delete.consumer.start();
	}
}
