package threadEx;

public class YieldEx {
	class ThreadDemo implements Runnable {

		ThreadDemo(String str, int i) {
			Thread t = new Thread(this, str);
			t.setPriority(i);
			t.start();
		}

		public void run() {
			for (int i = 0; i < 5; i++) {
				// yields control to another thread every 5 iterations
				if ((i % 5) == 0) {
					System.out.println(Thread.currentThread().getName()	+ "yielding control...");
					/*
					 * causes the currently executing thread object to
					 * temporarily pause and allow other threads to execute
					 */
					Thread.yield();
				}
			}
			System.out.println(Thread.currentThread().getName()+ " has finished executing.");
		}
	}

	public static void main(String[] args) {
		YieldEx ex = new YieldEx();
		for(int i=1; i<10; i++)
			ex.new ThreadDemo("Thread "+i,5);
	}
}