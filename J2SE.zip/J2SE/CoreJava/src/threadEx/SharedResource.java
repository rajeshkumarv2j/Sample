package threadEx;

public class SharedResource {

}
