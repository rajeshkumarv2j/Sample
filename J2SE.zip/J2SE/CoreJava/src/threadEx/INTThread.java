package threadEx;

public class INTThread {
	EmpVO empVO = new EmpVO();
	EmpVO empVO1 = new EmpVO();
	Runnable runnable = new Runnable() {
		public void run() {
			System.out.println(empVO.m3());
		}
	};
	Runnable runnable2 = new Runnable() {
		public void run() {
			System.out.println(empVO.m4());
		}
	};
	public static void main(String[] args) {
		INTThread realThread = new INTThread();
		new Thread(realThread.runnable).start();
		new Thread(realThread.runnable2).start();
		/*
		 * If you share an object to multiple threads.. there is scope of data
		 * inconsistency it may be between static methods or between non static
		 * methods or between static and non static methods...
		 */
	}
}

class EmpVO {
	private static String order = "";

	public synchronized String m3(){
		System.out.println("m3..."+Thread.currentThread());
		order = "changed in m3..."+Thread.currentThread();
		return order;
	}
	
	public static synchronized String m4(){
		System.out.println("m4..."+Thread.currentThread());
		order = "changed in m4..."+Thread.currentThread();
		return order;
	}
}
