package threadEx;

public class DeadLockEx {
	private Object r1 = new Object();
	private Object r2 = new Object();
	
	private Runnable t1 = new Runnable() {
		@Override
		public void run() {
			while(true){
				synchronized(r1){ //t1 thread monitoring/locked on r1 resource, so no other thread can monitor/lock on resource r1 until this synchronize block completed.  
					synchronized(r2){ //t2 thread monitoring/locked on r1 resource, so no other thread can monitor/lock on resource r1 until this synchronize block completed. 
						System.out.println(r2.equals(r1));
					}
				}
			}
		}
	};
	
	private Runnable t2 = new Runnable(){
		public void run(){
			while(true){
				synchronized(r2){
					synchronized(r1){
						System.out.println(r1.equals(r2));
					}
				}
			}
		}
	};
	
	public static void main1(String[] args) {
		DeadLockEx deadLockEx = new DeadLockEx();
		new Thread(deadLockEx.t1).start();
		new Thread(deadLockEx.t2).start();
	}
}

class DeadLockDemo { /*
					 *  * This method request two locks, first String and then
					 * Integer
					 */
	public void method1() {
		synchronized (String.class) {
			System.out.println(Thread.currentThread().getName()+"... Aquired Outer lock on String.class object");
			synchronized (Integer.class) {
				System.out.println(Thread.currentThread().getName()+"... Aquired Inner lock on Integer.class object");
			}
		}
	} /*
	 *  * This method also requests same two lock but in exactly * Opposite order
	 * i.e. first Integer and then String. * This creates potential deadlock, if
	 * one thread holds String lock * and other holds Integer lock and they wait
	 * for each other, forever.
	 */

	public void method2() {
		synchronized (Integer.class) {
			System.out.println(Thread.currentThread().getName()+"... Aquired Outer lock on Integer.class object");
			synchronized (String.class) {
				System.out.println(Thread.currentThread().getName()+"... Aquired Inner lock on String.class object");
			}
		}
	}
	public static void main(String[] args) {
		final DeadLockDemo deadLockDemo = new DeadLockDemo();
		new Thread("Jatin"){
			public void run() {
				deadLockDemo.method1();
				deadLockDemo.method2();
			};
		}.start();
		new Thread("Rajesh"){
			public void run() {
				deadLockDemo.method1();
				deadLockDemo.method2();
			};
		}.start();
	}
}
