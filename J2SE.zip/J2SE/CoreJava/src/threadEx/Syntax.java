package threadEx;

public class Syntax {

	public static void main(String[] args) {
		MyThread myThread = new MyThread();
		myThread.start();

		Thread thread1 = new Thread(new MyThread(), "my thead");
		thread1.start();

		MyRunnable myRunnable = new MyRunnable();
		Thread thread = new Thread(myRunnable);
		thread.start();

		Thread t = new Thread();
		t.run(); // Legal, but does not start a new thread
		t.setName("xyz");
		System.out.println(t);
		
		System.out.println("..................................................."+Thread.currentThread());//Thread[main,5,main]
		
		NameRunnable nr = new NameRunnable();
		Thread one = new Thread(nr);
		Thread two = new Thread(nr);
		Thread three = new Thread(nr);
		one.setName("Fred");
		two.setName("Lucy");
		three.setName("Ricky");
		one.start();
		two.start();
		three.start();
		try {
			one.join();//If any executing thread t1 calls join() on t2 i.e; t2.join() immediately t1 will enter into waiting state until t2 completes its execution.
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		/*try {
			two.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
//		three.start();//Exception in thread "main" java.lang.IllegalThreadStateException
		/*try {
			three.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		Thread.yield();//yield() method pauses the currently executing thread temporarily for giving a chance to the remaining waiting threads of the same priority to execute. If there is no waiting thread or all the waiting threads have a lower priority then the same thread will continue its execution. The yielded thread when it will get the chance for execution is decided by the thread scheduler whose behavior is vendor dependent.
		three.setPriority(Thread.MIN_PRIORITY);
		
		System.out.println(Thread.currentThread().getId());
		
		
		
		/*public final void wait() throws InterruptedException
		public final void notify()
		public final void notifyAll()*/
		
		
	System.out.println("main end");	
	}

}

class MyThread extends Thread {
	public void run() {
		for (int x = 1; x < 6; x++) {
			System.out.println("Runnable running"+x+Thread.currentThread());
		}
	}
}

class MyRunnable implements Runnable {
	public void run() {
		for (int x = 1; x < 6; x++) {
			System.out.println("Runnable running"+x+Thread.currentThread());
		}
	}
}

class NameRunnable implements Runnable {
	public void run() {
		for (int x = 1; x <= 3; x++) {
			System.out.println("Run by " + Thread.currentThread().getName()
					+ ", x is " + x);
		}
	}
}