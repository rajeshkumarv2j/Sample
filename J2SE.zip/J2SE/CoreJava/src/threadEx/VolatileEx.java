package threadEx;

public class VolatileEx {

	private static Runnable t1 = new Runnable() {
		volatile Integer i = 0;

		void incIBy51() {
//			Integer temp = 0;
//			synchronized (i) {
//				temp = i;
//			}
//			synchronized (i) {
//				i = temp + 5;
//			}
			synchronized (i) {
			 i+=5;
			}
		}

		@Override
		public void run() {
			this.incIBy51();
			System.out.println("   " + Thread.currentThread().getName() + "   "
					+ i);
		}
	};

	public static void main(String[] args) {
		for (int i = 0; i < 100; i++)
			new Thread(t1).start();
	}
}
