package threadEx;

public class Threads1 implements Runnable {

	public void run() {
		System.out.println("run.");
		throw new RuntimeException("Problem");
	}

	public void method(){
		Thread t = new Thread(this);
		t.start();
	}
	public static void main(String[] args) {
		new Threads1().method();
	}
}