package varargs;

public class Syntax {
	
//	public void fun(int i, int j, int k){
//		System.out.println("int...");
//	}
	
	static void  sample(int j, int i){
		System.out.println(j+".."+i);
	}
	
	static void  sample(long j, long i){
		System.out.println("long..."+j+".."+i);
	}
	
	static void sample(int d,int...s){
		System.out.println(d);
		System.out.println(s[2]);
		System.out.println("var args...");
	}
	
	public static void main1(String[] args) {
		byte s = 90;
		byte s1 = 90;
		sample(s,s1);
		sample(s,s1,s1);
	}
	
	public static void main(String[] args) {
		
	}
	
	void m1(float... f){
		System.out.println(f.length);
	}
	void m1(int i,Object f){
		System.out.println(f instanceof float[]);
		
	}
}
