package system;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Map.Entry;
import java.util.Set;

public class SystemProps {
	public static void main(String[] args) throws IOException {
		FileWriter fileWriter = new FileWriter("nenu.txt");
		BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
		Set<Entry<Object, Object>> entries = System.getProperties().entrySet();
		for (Entry<Object, Object> entry : entries) {
			bufferedWriter.write(entry.getKey() + "=" + entry.getValue() + "\n");
		}
		bufferedWriter.flush();
		bufferedWriter.close();
		
		System.getProperties().list(System.out);
		Runtime.getRuntime().exit(1);
		System.exit(0);
		
//		System.out.println(System.getProperties());
	}
}
