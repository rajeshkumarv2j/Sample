package statcEx;
 
public class StaticExp {
	
	static int a = 10;
	static int b = 50;
	static{
		System.out.println(a);
		a=5;
		
		/*Integer i = null;
		i.byteValue();*/
		/*java.lang.ExceptionInInitializerError
		Caused by: java.lang.NullPointerException*/
	}
	
	static{
		System.out.println(a);
		System.out.println(b);
	}
	public static void main(String[] args) {
		try {
			Class.forName("statcExp.StaticExp");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
}