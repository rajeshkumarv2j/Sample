package statcEx;
public class StaticBlockExample {
	static{
		int b = 50;
		print2(b);
		System.out.println(b);
		System.out.println(StaticBlockExample.b);
	}
	static int b = 30;
	static int a = 30;
	static {
		int a=30;
		System.out.println(a);
		System.out.println(print());
	}
	static {
		int a=30;
		System.out.println(a);
		System.out.println(print1());
	}
	static int print(){
		return a;
	}
	private static void print2(int b) {
		StaticBlockExample.b=b;
	}
	static int print1(){
		return b;
	}
	public static void main(String[] args) {
	}
} 
/*30
30
30
30*/