package operators;

public class Addition {
	Integer i;
	Float f;
	static String s;

	float add() {
		return i + f;
	}

	public static void main1(String[] args) {
		System.out.println(s);
		System.out.println(new Addition().add());
		byte b = 0;
		b = +21;
		b = (byte) (b + 21);
		System.out.println(b);
	}

	public static void main(String[] args) {
		int y = 10;
		int x = 5;
//		int z = (++x) + (++x)/*6*/;
//		System.out.println(z);

//		int z = x++ + x++ + x++/*6*/;//18
//		int z = ++x + ++x + ++x/*6*/;//21
//		System.out.println(x);
//		System.out.println(z);

		/*int z = 2;
		x = x++ + ++x / z;//8
		System.out.println(x);*/

		
	}
}
