package serialization;
import java.io.Serializable;
 
public class Employee extends SuperEmployee implements Serializable{
	
	/*public Employee() {
		System.out.println("Employee Default...");
	}*/
	public Employee(String lastName1, String address, String lastName) {
		super(lastName1,address,lastName);
	}
	public String firstName;
	public String firstName2;
	public String firstName1;
}
 
class SuperEmployee {
	public String lastName;
	 transient  String address;// = "DEL123";
	public String lastName1;//="rajesh";
	
	public final String lastName2="Kumar";
	static String companyName = "TATA";
	static transient String companyCEO = "Jayshree";
	public SuperEmployee() {
		System.out.println("SuperEmployee Default...");
	}
	/*public SuperEmployee(String lastName1) {//Error: The blank final field lastName1 may not have been initialized
		this.lastName1 = lastName1;
		this.address = lastName1;
	}*/
	
	public SuperEmployee(String lastName, String address, String lastName1) {
		super();
		this.lastName = lastName;
		this.address = address;
		this.lastName1 = lastName1;
	}
}