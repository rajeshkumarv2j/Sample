package serialization;

import java.io.Serializable;

/**
 * @author Rajeshkumar V
 *
 */
public class VersionIdGenerator implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 2656002796240055157L;

	private Long Id;
	
	private String name;
	
	private Object object;

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((Id == null) ? 0 : Id.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((object == null) ? 0 : object.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		VersionIdGenerator other = (VersionIdGenerator) obj;
		if (Id == null) {
			if (other.Id != null)
				return false;
		} else if (!Id.equals(other.Id))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (object == null) {
			if (other.object != null)
				return false;
		} else if (!object.equals(other.object))
			return false;
		return true;
	}

	/**
	 * @return
	 */
	public Long getId() {
		return Id;
	}

	/**
	 * @param id
	 */
	public void setId(Long id) {
		Id = id;
	}

	/**
	 * @return
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return
	 */
	public Object getObject() {
		return object;
	}

	/**
	 * @param object
	 */
	public void setObject(Object object) {
		this.object = object;
	}

	/**
	 * @param id
	 * @param name
	 * @param object
	 */
	public VersionIdGenerator(Long id, String name, Object object) {
		super();
		Id = id;
		this.name = name;
		this.object = object;
	}

	/**
	 * 
	 */
	public VersionIdGenerator() {
	}

}