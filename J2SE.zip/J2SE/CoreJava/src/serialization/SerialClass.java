package serialization;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;

public class SerialClass implements Serializable {
	private Date currentTime;

	public SerialClass() {
		calculateCurrentTime();
	}

	public Date getCurrentTime() {
		return currentTime;
	}

	private Date calculateCurrentTime() {
		currentTime = Calendar.getInstance().getTime();
		return currentTime;
	}

	private void writeObject(ObjectOutputStream out) throws IOException {
		System.out.println("............write");
		out.defaultWriteObject();
	}

	private void readObject(ObjectInputStream in) throws IOException,
			ClassNotFoundException {
		System.out.println("............read");
		// our "pseudo-constructor"
		in.defaultReadObject();
		// now perfrom same operation you need to do in constructor
		calculateCurrentTime();
	}
}