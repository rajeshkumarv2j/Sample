package jvm;

import java.lang.management.ManagementFactory;
import java.util.ArrayList;


public class JVMOptionArgumrnts extends Thread{

	static ArrayList<JVMOptionArgumrnts> argumrnts = new ArrayList<JVMOptionArgumrnts>();
	static JVMOptionArgumrnts argumrnts2 = new JVMOptionArgumrnts();
	public static void main(String args[]){
		System.out.println(ManagementFactory.getRuntimeMXBean().getInputArguments());
		new JVMOptionArgumrnts().start();
	}
	@Override
	public void run() {
		for(int i=0; i<1000000000; i++){
			argumrnts.add(new JVMOptionArgumrnts());
			argumrnts.add(new JVMOptionArgumrnts());
			argumrnts.add(new JVMOptionArgumrnts());
			argumrnts.add(new JVMOptionArgumrnts());
			argumrnts.add(new JVMOptionArgumrnts());
			argumrnts.add(new JVMOptionArgumrnts());
		}
	}
}