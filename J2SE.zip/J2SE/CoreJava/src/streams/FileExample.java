package streams;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

class FileExample {
	static InputStream inputStream;
	static{
		try {
			inputStream = new FileInputStream("hotel.txt");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
	static BufferedReader system_in = new BufferedReader(new InputStreamReader(inputStream));

	public static void main(String argv[]) {
			try {
				FileOutputStream fos = new FileOutputStream("file.dat",true);
				// Read in three hotels
				for (int i = 0; i < 3; i++) {
					Hotel1 a_hotel = new Hotel1();
					a_hotel.input(system_in);
					a_hotel.write_to_fos(fos);
				}
				fos.close();
			} catch (IOException e) {
				System.out.println(e);
			}
			byte[] buffer = null;
			File a_file = new File("file.dat");
			System.out.println("Length is " + a_file.length());
			System.out.println(" Can read " + a_file.canRead());
			try {
				FileInputStream fis = new FileInputStream(a_file);
				int length = (int) a_file.length();
				buffer = new byte[length];
				fis.read(buffer);
				fis.close();
			} catch (IOException e) {
				System.out.println(e);
			}
			String s = new String(buffer);
			System.out.println("Buffer is " + s);
	}
}

class Hotel1 {
	
	private String name;
	private int rooms;
	private String location;

	boolean input(BufferedReader in) {
		try {
			name = in.readLine();
			String temp = in.readLine();
			rooms = to_int(temp);
			location = in.readLine();
		} catch (IOException e) {
			System.err.println(e);
			return false;
		}
		return true;
	}

	boolean write_to_fos(FileOutputStream fos) {
		try {
			fos.write(("\n"+name).getBytes());
			Integer i = new Integer(rooms);
			fos.write(i.toString().getBytes());
			fos.write(location.getBytes());
			fos.write(' ');
		} catch (IOException e) {
			System.err.println(e);
			return false;
		}
		return true;
	}

	static int to_int(String value) {
		int i = 0;
		try {
			i = Integer.parseInt(value);
		} catch (NumberFormatException e) {
		}
		return i;
	}
}