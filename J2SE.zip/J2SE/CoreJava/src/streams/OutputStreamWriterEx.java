package streams;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;

/*
 * It turns byte based input stream to character based Reader object...
 * 
 */
public class OutputStreamWriterEx {
	public static void main(String[] args) throws IOException {
		OutputStream outputStream = new FileOutputStream("data.txt");
		Writer writer = new OutputStreamWriter(outputStream);
		writer.write("Rajeshkumar.V");
		outputStream.close();
	}
}