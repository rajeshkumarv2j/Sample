package streams;

import java.io.File;
import java.io.FilenameFilter;

public class FileNameFilterEx {
	public static void main(String[] args) {
		File file = new File("C:\\Rajeshkumar\\pracise\\CoreJava");
		System.out.println(file.isDirectory());
		System.out.println(file.isFile());
		for (String g : file.list(new FilenameFilter() {
			public boolean accept(File f, String s) {
				return s.contains("txt");
			}
		})) {
			System.out.println(g);
		}
	}
}
