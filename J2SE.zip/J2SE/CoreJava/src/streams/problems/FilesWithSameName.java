package streams.problems;

public class FilesWithSameName {
	static void  fun(int... a){
		System.out.println(a);
	}
	static void fun(float... f){
		System.out.println(f);
	}
	static void  fun1(int[] a){
		System.out.println(a);
	}
	static void fun1(float[] f){
		System.out.println(f);
	}
	public static void main(String[] args) {
		fun(new float[]{1,2});
//		fun({1,2,3);
//		fun(2);
		
	}
}
