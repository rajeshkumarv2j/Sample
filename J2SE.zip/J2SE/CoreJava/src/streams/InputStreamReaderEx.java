package streams;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;

/*
 * It turns byte based input stream to character based Reader object...
 * 
 */
public class InputStreamReaderEx {
	public static void main(String[] args) throws IOException {
		InputStream inputStream = new FileInputStream("data.txt");
		Reader inputStreamReader = new InputStreamReader(inputStream);

		int data = inputStreamReader.read();
		while (data != -1) {
			char theChar = (char) data;
			data = inputStreamReader.read();
		}
		inputStreamReader.close();
	}
}