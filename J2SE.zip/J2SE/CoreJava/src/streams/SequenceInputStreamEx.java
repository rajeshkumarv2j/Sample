package streams;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.SequenceInputStream;
import java.util.Enumeration;
import java.util.Vector;

public class SequenceInputStreamEx {
	public static void main1(String args[]) throws Exception {//Just Read two files...
		FileInputStream fin1 = new FileInputStream("data.txt");
		FileInputStream fin2 = new FileInputStream("hotel.txt");

		SequenceInputStream sis = new SequenceInputStream(fin1, fin2);
		int i;
		while ((i = sis.read()) != -1) {
			System.out.print((char) i);
		}
		sis.close();
		fin1.close();
		fin2.close();
	}

	public static void main2(String args[]) throws Exception {//Read two files and write to other single file...

		FileInputStream fin1 = new FileInputStream("data.txt");
		FileInputStream fin2 = new FileInputStream("hotel.txt");
		
		FileOutputStream fout = new FileOutputStream("output.txt");

		SequenceInputStream sis = new SequenceInputStream(fin1, fin2);
		int i;
		while ((i=sis.read()) != -1) {
			fout.write(i);
		}
		sis.close();
		fout.close();
		fin1.close();
		fin2.close();

	}
	
	public static void main(String args[]) throws IOException {//Read multiple files  

		// creating the FileInputStream objects for all the files
		FileInputStream fin = new FileInputStream("data.txt");
		FileInputStream fin2 = new FileInputStream("hotel.txt");
		FileInputStream fin3 = new FileInputStream("i.txt");

		// creating Vector object to all the stream
		Vector v = new Vector();
		v.add(fin);
		v.add(fin2);
		v.add(fin3);

		// creating enumeration object by calling the elements method
		Enumeration e = v.elements();

		// passing the enumeration object in the constructor
		SequenceInputStream bin = new SequenceInputStream(e);
		int i = 0;

		while ((i = bin.read()) != -1) {
			System.out.print((char) i);
		}

		bin.close();
		fin.close();
		fin2.close();
	}
}
