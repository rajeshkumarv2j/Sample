package streams;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.CharArrayReader;
import java.io.CharArrayWriter;
import java.io.Console;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.Reader;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Scanner;

public class Practice implements Serializable{

	public static void main(String[] args){
		char[] s = new char[]{'a','c'};
		CharArrayReader arrayReader = new CharArrayReader(s);
		try {
			System.out.println((char)arrayReader.read());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		FileReader fileReader = null;
		try {
			fileReader = new FileReader("sample.txt");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			System.out.println((char)fileReader.read());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ByteArrayInputStream in = new ByteArrayInputStream(new byte[]{'a','b'});
		InputStreamReader inputStreamReader = null;
		try {
			inputStreamReader = new InputStreamReader(new FileInputStream(""));
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		BufferedReader reader = new BufferedReader(inputStreamReader);
		try {
			System.out.println(reader.readLine());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		CharArrayWriter arrayWriter = new CharArrayWriter();
		try {
			arrayWriter.write("");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//		fileExplorer();
//		readFromConsole();
//		fileStreams();
//		byteArrayStreamExplorer();
//		bufferedStreams();
	}

	private static void bufferedStreams() {
		 
	}

	private static void readFromConsole() {
		BufferedInputStream inputStream = new BufferedInputStream( System.in);
		try {
			System.out.println(inputStream.read());
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		try{
			System.out.println("Enter data");
			System.out.println(in.readLine());
		}catch (IOException e) {
			// TODO: handle exception
		}
//or
		Console console = System.console();
		System.out.println("Enter data again..");
		System.out.println(console.readLine());
		
		Scanner scanner = new Scanner("");
	}

	private static void fileStreams() {
		try{
		FileWriter fileWriter = new FileWriter("sample.txt",true);
		BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
		PrintWriter printWriter = new PrintWriter(bufferedWriter, true);
		printWriter.write("\n 12364019237401273401732");
		printWriter.close();
//		bufferedWriter.write("\nhhhhhhhhhhhhhhhh");
//		bufferedWriter.flush();
//		bufferedWriter.close();
	}catch(FileNotFoundException e){
		
	} catch (IOException e) {
		e.printStackTrace();
	}
		
		/*try {
			FileReader fileReader = new FileReader("sample.txt");
			BufferedReader bufferedReader = new BufferedReader(fileReader);
			System.out.println(bufferedReader.readLine());
		} catch (FileNotFoundException e) {

		} catch (IOException e) {
			e.printStackTrace();
		}*/
		/*try {
			FileReader fileReader = new FileReader("sample.txt");
			int ch = fileReader.read();
			while (ch != -1) {
				System.out.print((char) ch);
				ch = fileReader.read();
			}
		} catch (FileNotFoundException e) {

		} catch (IOException e) {
			e.printStackTrace();
		}*/
		
		/*try{
			FileWriter fileReader = new FileWriter("sample.txt",true);
			char[] chrs = "Hi How Are you".toCharArray();
			fileReader.write(chrs);
			fileReader.write("ashdfl;asjdf;lasjdfjasdfajdfasdf");
			fileReader.append('q');
			fileReader.flush();
			fileReader.close();
		}catch(FileNotFoundException e){
			
		} catch (IOException e) {
			e.printStackTrace();
		}*/
		/*try{
			FileReader fileReader = new FileReader("sample.txt");
			int ch = fileReader.read();
			while(ch!=-1){
				System.out.print((char)ch);
				ch = fileReader.read();
			}
		}catch(FileNotFoundException e){
			
		} catch (IOException e) {
			e.printStackTrace();
		}*/
		
		
		/*try {
			FileOutputStream fileOutputStream = new FileOutputStream("sample.txt",true);
			fileOutputStream.write('\n');
			fileOutputStream.write('a');
			byte[] b = new byte[]{'a','b','c','d','e','f','g','f'};
			fileOutputStream.write(b);
			fileOutputStream.flush();
			fileOutputStream.close();
		}catch (IOException e) {
			e.printStackTrace();
		}*/
		
		/*//		Read Sample File...
		String fileName = "sample.txt";
		File file = new File(fileName);
		if(file.exists()){
			if(file.isDirectory()){
				System.out.println("Directory cant be read..");
				return;
			}
			if(file.isFile()){
				try{
					FileInputStream fileInputStream = new FileInputStream(file);
					final int EOF = -1;
					int ch = fileInputStream.read();
					while(ch!=EOF){
						System.out.println((char)ch);
						ch = fileInputStream.read();
					}
				}
				catch(FileNotFoundException e){
					e.printStackTrace();
				}
				catch(IOException e){
					e.printStackTrace();
				}
			}
		}else{
			System.out.println("File Not Found");
		}
		
		System.out.println("Start....");
		byte[] b = new byte[20];
		try{
		FileInputStream fileInputStream = new FileInputStream("sample.txt");
		fileInputStream.read(b);
		for(int i = 0 ; i < b.length; i++){
			System.out.print((char)b[i]);
		}
		fileInputStream.close();
		}catch (Exception e) {
		}
		
		System.out.println("Start....");
		byte[] b1 = new byte[]{'9','9','9','9','9'};
		try{
		FileInputStream fileInputStream = new FileInputStream("sample.txt");
		fileInputStream.read(b1,1,3);
		for(int i = 0 ; i < b1.length; i++){
			System.out.print((char)b1[i]);
		}
		fileInputStream.close();
		}catch (Exception e) {
		}
		*/
	}

	private static void byteArrayStreamExplorer() {
		byte[] buf = new byte[]{'9','9','9','9','9','9'};
		ByteArrayInputStream arrayInputStream = new ByteArrayInputStream(buf);
		int ch = arrayInputStream.read();
		while(ch!=-1){
			System.out.print((char)ch);
			ch = arrayInputStream.read();
		}
	}

	private static void fileExplorer() {
		File file = new File("C:\\Rajeshkumar\\pracise\\CoreJava\\");
		if(!file.exists())
			try {
				System.out.println(file.createNewFile());
			} catch (IOException e) {
				e.printStackTrace();
			}
		System.out.println(file.canWrite());
		System.out.println(file.canRead());
		System.out.println(file.compareTo(new File("sample.txt")));
//		System.out.println(file.delete());
		System.out.println(file.getAbsolutePath());
		try {
			System.out.println(file.getCanonicalPath());
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println(file.getPath());
		System.out.println(file.getFreeSpace()/(1024*1024*1024)+" GB");
		System.out.println(file.getName());
		System.out.println(file.getParent());
		System.out.println(file.getTotalSpace()/(1024*1024*1024)+" GB");
		System.out.println(file.getUsableSpace()/(1024*1024*1024)+" GB");
		System.out.println(file.isAbsolute());
		System.out.println(file.isDirectory());
		System.out.println(file.isFile());
		System.out.println(new Timestamp(file.lastModified()));
		System.out.println(file.length());
//		System.out.println(new File("C://Rajeshkumar//pracise//fun").mkdir());
//		System.out.println(file.renameTo(new File("s.txt")));
		for(String name : file.list()){
			System.out.println(name);
			
		}
		try {
			file.createTempFile("sample", ".txt");
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		
		file.deleteOnExit();
		file.setReadOnly();
		file.setReadable(false);
		file.setWritable(false);
		
		try {
			System.out.println(file.createTempFile("Hiii", ".txt"));
		} catch (IOException e) {
			e.printStackTrace();
		}		
	}
}
