package streams;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class DataInputOutputEx {
	static InputStream inputStream;
	static{
		try {
			inputStream = new FileInputStream("hotel.txt");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
	static BufferedReader system_in = new BufferedReader(new InputStreamReader(inputStream));

	public static void main(String argv[]) {
		// Create it
		{
			try {
				FileOutputStream fos = new FileOutputStream("data.dat");
				DataOutputStream dos = new DataOutputStream(fos);
				// Read in three hotels
				for (int i = 0; i < 3; i++) {
					Hotel5 a_hotel = new Hotel5();
					a_hotel.input(system_in);
					a_hotel.write_to_dos(dos);
				}
				dos.close();
			} catch (IOException e) {
				System.err.println(e);
			}
		}
		// Now read it
		{
			try {
				FileInputStream fis = new FileInputStream("data.dat");
				DataInputStream dis = new DataInputStream(fis);
				Hotel5 a_hotel = new Hotel5();
				while (a_hotel.read_from_dis(dis)) {
					a_hotel.debug_print();
				}
				dis.close();
			} catch (IOException e) {
				System.err.println(e);
			}
		}
	}
}

class Hotel5 {
	private String name;
	private int rooms;
	private String location;

	boolean input(BufferedReader in) {
		try {
			name = in.readLine();
			String temp = in.readLine();
			rooms = to_int(temp);
			location = in.readLine();
		} catch (IOException e) {
			System.err.println(e);
			return false;
		}
		return true;
	}

	boolean write_to_dos(DataOutputStream dos) {
		try {
			dos.writeUTF(name);
			dos.writeInt(rooms);
			dos.writeUTF(location);
		} catch (IOException e) {
			System.err.println(e);
			return false;
		}
		return true;
	}

	boolean read_from_dis(DataInputStream dis) {
		try {
			name = dis.readUTF();
			rooms = dis.readInt();
			location = dis.readUTF();
		} catch (EOFException e) {
			return false;
		} catch (IOException e) {
			System.err.println(e);
			return false;
		}
		return true;
	}

	void debug_print() {
		System.out.println("Name :" + name + ": Rooms : " + rooms + ": at :"
				+ location + ":");
	}

	static int to_int(String value) {
		int i = 0;
		try {
			i = Integer.parseInt(value);
		} catch (NumberFormatException e) {
		}
		return i;
	}
}