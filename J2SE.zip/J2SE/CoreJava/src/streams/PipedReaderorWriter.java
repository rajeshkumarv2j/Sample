package streams;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PipedReader;
import java.io.PipedWriter;

class PipedReaderorWriter {
	static BufferedReader system_in = new BufferedReader(new InputStreamReader(PipedReaderorWriter.class.getResourceAsStream("/hotel.txt")));
	static{
		try {
			System.out.println(new File("src/hotel.txt").getAbsolutePath());
			System.out.println(new File("src/hotel.txt").getPath());
			System.out.println(new File("src/hotel.txt").getCanonicalPath());
			
			System.out.println(new File("hotel.txt").getAbsolutePath());
			System.out.println(new File("hotel.txt").getPath());
			System.out.println(new File("hotel.txt").getCanonicalPath());
			System.out.println(PipedReaderorWriter.class.getCanonicalName());
			
			ByteArrayInputStream g = new ByteArrayInputStream(getFileBytes(new File("hotel.txt")));
		} catch (IOException e) {
			e.printStackTrace();
		} 
	}
	public static byte[] getFileBytes(File file) throws IOException {
	    ByteArrayOutputStream ous = null;
	    InputStream ios = null;
	    try {
	        byte[] buffer = new byte[4096];
	        ous = new ByteArrayOutputStream();
	        ios = new FileInputStream(file);
	        int read = 0;
	        while ((read = ios.read(buffer)) != -1)
	            ous.write(buffer, 0, read);
	    } finally {
	        try {
	            if (ous != null)
	                ous.close();
	        } catch (IOException e) {
	            // swallow, since not that important
	        }
	        try {
	            if (ios != null)
	                ios.close();
	        } catch (IOException e) {
	            // swallow, since not that important
	        }
	    }
	    return ous.toByteArray();
	}
	public static void main(String argv[]) {
		PipedReader pr = new PipedReader();
		PipedWriter pw = null;
		try {
			pw = new PipedWriter(pr);
		} catch (IOException e) {
			System.err.println(e);
		}
		PipedReaderorWriter example = new PipedReaderorWriter();
		// Create it {
		// Read in three hotels
		for (int i = 0; i < 3; i++) {
			Hotel a_hotel = example.new Hotel();
			a_hotel.input(system_in);
			a_hotel.write_to_pw(pw);
		}
		printIt(pr);
	}

	// Print it
	static void printIt(PipedReader pr) {
		char[] buffer = new char[1000];
		int length = 0;
		try {
			length = pr.read(buffer);
		} catch (IOException e) {
			System.err.println(e);
		}
		String output = new String(buffer, 0, length);
		System.out.println("String is ");
		System.out.println(output);
	}

	class Hotel {
		private String name;
		private int rooms;
		private String location;

		boolean input(BufferedReader in) {
			try {
				name = in.readLine();
				String temp = in.readLine();
				rooms = toInt(temp);
				location = in.readLine();
			} catch (IOException e) {
				System.err.println(e);
				return false;
			}
			return true;
		}

		boolean write_to_pw(PipedWriter pw) {
			try {
				pw.write(name);
				Integer i = new Integer(rooms);
				pw.write(i.toString());
				pw.write(location);
				pw.write("\n");
				// red font indicates that an actual backslash n (carriage
				// return character)
				// should be inserted in the code.
			} catch (IOException e) {
				System.err.println(e);
				return false;
			}
			return true;
		}

		void debug_print() {
			System.out.println("Name :" + name + ": Rooms : " + rooms
					+ ": at :" + location + ":");
		}

		int toInt(String value) {
			int i = 0;
			try {
				i = Integer.parseInt(value);
			} catch (NumberFormatException e) {
			}
			return i;
		}
	}
}
