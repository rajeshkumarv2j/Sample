package streams;

import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class BufferedOutputStreamEx {
	public static void main1(String args[]) throws Exception {
		FileOutputStream fout = new FileOutputStream("f1.txt");
		BufferedOutputStream bout = new BufferedOutputStream(fout);
		String s = "Sachin is my favorite player";
		byte b[] = s.getBytes();
		bout.write(b);

		bout.flush();
		bout.close();
		fout.close();
		System.out.println("success");
	}

	public static void main(String[] args) throws IOException {

		ByteArrayOutputStream baos = null;
		BufferedOutputStream bos = null;

		try {
			// create new output streams.
			baos = new ByteArrayOutputStream();
			bos = new BufferedOutputStream(baos);

			// assign values to the byte array
			byte[] bytes = { 1, 2, 3, 4, 5 };

			// write byte array to the output stream
			bos.write(bytes, 0, 5);

			// flush the bytes to be written out to baos
			bos.flush();

			for (byte b : baos.toByteArray()) {
				// prints byte
				System.out.print(b);
			}
		} catch (IOException e) {

			// if any IOError occurs
			e.printStackTrace();
		} finally {

			// releases any system resources associated with the stream
			if (baos != null)
				baos.close();
			if (bos != null)
				bos.close();
		}
	}
}