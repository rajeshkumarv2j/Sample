package streams;

import java.io.IOException;
import java.io.RandomAccessFile;

public class RandomAccessFileEx {
	public static void main(String argv[]) {
		try {
			RandomAccessFile raf = new RandomAccessFile("random.dat", "rw");
			raf.writeInt(12);
			long pointer = raf.getFilePointer();
			raf.writeInt(15);
			raf.writeInt(16);
			// Now read back the 2nd one
			raf.seek(pointer);
			int i = raf.readInt();
			System.out.println("Read " + i);
		} catch (IOException e) {
			System.out.println(e);
		}
	}
}
