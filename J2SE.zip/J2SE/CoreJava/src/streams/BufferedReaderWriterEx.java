package streams;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.StringTokenizer;

public class BufferedReaderWriterEx {
	static InputStream in;
	static{
		try {
			in = new FileInputStream("hotel.txt");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
	static BufferedReader system_in = new BufferedReader(new InputStreamReader(in));

	
	
	public static void main1(String argv[]) {
		// Create it
		{
			try {
				FileOutputStream fos = new FileOutputStream("text.dat");
				PrintWriter pw = new PrintWriter(fos);
				for (int i = 0; i < 3; i++) {
					Hotel3 a_hotel = new Hotel3();
					a_hotel.input(system_in);
					a_hotel.write_to_pw(pw);
				}
				pw.close();
			} catch (IOException e) {
				System.err.println(e);
			}
		}

		// Now read it
		{
			try {
				FileReader fr = new FileReader("text.dat");
				BufferedReader br = new BufferedReader(fr);
				Hotel3 a_hotel = new Hotel3();
				while (a_hotel.read_from_br(br)) {
					a_hotel.debug_print();
				}
				br.close();
			} catch (IOException e) {
				System.err.println(e);
			}
		}
	}
}

class Hotel3 {
	private String name;
	private int rooms;
	private String location;

	boolean input(BufferedReader in) {
		try {
			name = in.readLine();
			String temp = in.readLine();
			rooms = to_int(temp);
			location = in.readLine();
		} catch (IOException e) {
			System.err.println(e);
			return false;
		}
		return true;
	}

	boolean write_to_pw(PrintWriter pw) {
		pw.print(name);
		pw.print('|');
		pw.print(rooms);
		pw.print('|');
		pw.print(location);
		pw.println();
		return true;
	}

	boolean read_from_br(BufferedReader br) {
		try {
			String line = br.readLine();
			if (line == null)
				return false;
			StringTokenizer st = new StringTokenizer(line, "|");
			int count = st.countTokens();
			if (count < 3)
				return false;
			name = st.nextToken();
			String temp = st.nextToken();
			rooms = to_int(temp);
			location = st.nextToken();
		} catch (IOException e) {
			System.err.println(e);
			return false;
		}
		return true;
	}

	void debug_print() {
		System.out.println("Name :" + name + ": Rooms : " + rooms + ": at :"
				+ location + ":");
	}

	static int to_int(String value) {
		int i = 0;
		try {
			i = Integer.parseInt(value);
		} catch (NumberFormatException e) {
		}
		return i;
	}
}

class WriteFileDemo {
	   public static void main(String[] args) {
	      BufferedWriter bw = null;
	      try {
		 String mycontent = "This String would be written" +
		    " to the specified File";
	         //Specify the file name and path here
		 File file = new File("myfile.txt");

		 /* This logic will make sure that the file 
		  * gets created if it is not present at the
		  * specified location*/
		  /*if (!file.exists()) {
		     file.createNewFile();
		  }*/

		  FileWriter fw = new FileWriter(file);
		  bw = new BufferedWriter(fw);
		  bw.write(mycontent);
	          System.out.println("File written Successfully");

	      } catch (IOException ioe) {
		   ioe.printStackTrace();
		}
		finally
		{ 
		   try{
		      if(bw!=null)
			 bw.close();
		   }catch(Exception ex){
		       System.out.println("Error in closing the BufferedWriter"+ex);
		    }
		}
	   }
	}