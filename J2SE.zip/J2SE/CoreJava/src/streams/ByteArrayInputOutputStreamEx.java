package streams;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashSet;
import java.util.Set;

public class ByteArrayInputOutputStreamEx {

	public static void main1(String args[]) throws IOException {
		ByteArrayOutputStream bOutput = new ByteArrayOutputStream();
		File file = new File("i.txt");
		InputStream inputStream = new FileInputStream(file);
		int i = 0;
		while ((i = inputStream.read()) != -1) {
			System.out.print((char)i);
			bOutput.write(i);
		}
		byte b[] = bOutput.toByteArray();
		System.out.println("\n Print the content");
		for (int x = 0; x < b.length; x++) {
			System.out.print((char) b[x]);
		}
		int c;
		ByteArrayInputStream bInput = new ByteArrayInputStream(b);
		System.out.println("\n  Converting characters to Upper case ");
		while ((c = bInput.read()) != -1) {
			System.out.print(Character.toUpperCase((char) c));
		}
		bInput.reset();
	}
}