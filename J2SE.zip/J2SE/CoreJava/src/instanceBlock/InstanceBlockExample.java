package instanceBlock;

public class InstanceBlockExample {

	private static int i = 20;
	static {
		System.out.println(i);
		System.out.println("static..." + print1());
	}
	private static int j = 20;
	{
		int a = 30;
		System.out.println(a);
		System.out.println(print() + a);
	}

	int a = 30;

	int print() {
		return a;
	}

	private static int print1() {
		return j;
	}

	public static void main(String[] args) {
		System.out.println(new InstanceBlockExample().print());
	}
}
// 30
// 0
// 30