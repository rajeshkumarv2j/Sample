package stringEx;

public class Syntax {
	public static void main(String[] args) {
		System.out.println(new String("Rajeshkumar")+new String(".Velishoju"));
		System.out.println(new Object()+new String());
		System.out.println(new String());
		System.out.println(new Integer(1));
	}
}
