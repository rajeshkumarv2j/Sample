package stringEx;

public class Tester {
	public static void main(String[] args) {
		StringBuffer sb1 = new StringBuffer();
		System.out.println(sb1);
		System.out.println(sb1.append(true).toString());
		StringBuffer sb = new StringBuffer("javachamp");
		String s = new String("javachamp");
		boolean stmt1 = s.equals(sb);
		boolean stmt2 = sb.equals(s);
		boolean stmt3 = sb.toString() == s;
		boolean stmt4 = sb.toString().equals(s);
		boolean stmt5 = s.equals(sb.toString());
		System.out.println(stmt1);
		System.out.println(stmt2);
		System.out.println(stmt3);
		System.out.println(stmt4);
		System.out.println(stmt5);
	}
}