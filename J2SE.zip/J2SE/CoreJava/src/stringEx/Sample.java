package stringEx;

public class Sample {
	public static void main(String[] args) {
//		+ operator concats two strings and resulted new string
		System.out.println("Main Started");
		System.out.println(""+2+2);
		System.out.println(2+2+"");
		String p = "abc";
		String q = p;
		System.out.println((p==q)+"sd"+p);
		System.out.println(q);
		System.out.println((p==q)+"sd"+p==q);
		System.out.println(p==q);
		System.out.println("Main Ended");
	}
	public static void main2(String[] args) {
		String s = "abc";
		String s1 = new String("abc");
		System.out.println(s==s1);
		System.out.println(s.equals(s1));
		s1 = s1.intern();
		System.out.println(s==s1);
		System.out.println(s.equals(s1));
	}
	public static void main3(String[] args) {
		String s = new String("abc");
		String s1 = new String("abc");
		System.out.println(s==s1);
		System.out.println(s.equals(s1));
		
		s1 = s1.intern();
		System.out.println(s==s1);
		System.out.println(s.equals(s1));
		
		s = s.intern();
		System.out.println(s==s1);
		System.out.println(s.equals(s1));
	}
	public static void main4(String[] args) {
		String s1 = new String("test");
		String s2 = "test";
		String s3 = "test";
		System.out.println(s1==s2);
		System.out.println(s2==s3);
		s1 = s1.intern();
		System.out.println(s1==s3);
	}

	static String s;
	static String s1;
	
}