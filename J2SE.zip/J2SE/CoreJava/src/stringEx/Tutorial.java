package stringEx;

public class Tutorial {
	public static void main(String[] args) {
		StringBuffer buffer = new StringBuffer(100);
		System.out.println(buffer);
		buffer.append("Rajeshkumar.V");
		buffer.append(new Object());
		System.out.println(buffer);
		System.out.println(buffer.capacity());
		buffer.insert(0, "1234");
		System.out.println(buffer);
		buffer.delete(0, 1);
		System.out.println(buffer);
		buffer.deleteCharAt(0);
		System.out.println(buffer.reverse());
		System.out.println(buffer);
	}
	public static void main123(String[] args) {
		String s1 = "Hello";//String literal
		String s4 = new String("Hello");
		String s = new String();//String Object
		String s2 = new String(new byte[]{104,101,108,108,102});
		String s3 = new String(new char[]{'h','e','l','l','o'});
		String s5 = new String(new StringBuffer("Hello"));
		String s6 = new String(new StringBuilder("Hello"));


		System.out.println(s1.concat(" Friend"));// Hello, Hello Friend
		s1 = s1.concat(" Friend");
		System.out.println(s1.contains("Fri"));//true
		System.out.println(s1.charAt(0));//H
		System.out.println(s1.equals("Hello Friend"));//true
		System.out.println(s1.equalsIgnoreCase("HELLO Friend"));//true
		System.out.println(s1.indexOf("H"));//0
		System.out.println(s1.isEmpty());
		s1.intern();
		System.out.println(s1.length());//12
		System.out.println(s1.lastIndexOf("l"));//3
		System.out.println(s1.matches("(.ell.)"));
		System.out.println(s1.replace('e', 'i'));
		System.out.println(s1);
		System.out.println(s1.substring(0));//Hel
		System.out.println(s1.substring(0,12));//ell
		String[] sarr = s1.split("/s");
		System.out.println(s1.trim());
		System.out.println(s1.toCharArray());
		System.out.println(s1.toLowerCase());
		System.out.println(s1.toUpperCase());
		System.out.println(String.valueOf(21.12f));
		System.out.println(String.format("%12.5f", 21.12f));
	}
	public static void main2(String[] args) {
		String s1 = "hello";//constant
		String s2 = "hello1";//constant
		
		String s3 = "hello" + "hello1";//constant because JVM knows hello and hello1 are constants, so why it will do intern on resulted string object.
		String s4 = "hellohello1";//constant
		String s5 = s1 + s2;//it results false because.. JVM makes resulted string intern if and only if s1 or s2(string references) are constants and pointing to interned objects. 

		System.out.println(s3 == s4); // returns true
		System.out.println(s3 == s5); // return false
		System.out.println(s4 == s5); // return false
		
		String s6 = s1 + "hello1";
		System.out.println(s3 == s6); // return false
		System.out.println(s4 == s6); // return false
		
		final String s7 = new String("sobj").intern();
		String s8 = "sobj";
		System.out.println(s7==s8);
		
		
	}
	
	public static void main1(String[] args) {
		String s1 = new String("hello");
		String s = "hello";
		
		byte[] bs = new byte[] { 104, 101, 108, 108, 111 };
		String s2 = new String(bs);
		String s3 = new String(new char[] { 'h', 'e', 'l', 'l', 'o' });
		System.out.println(s3);
		String s4 = new String(new StringBuffer("hello"));
		String s5 = new String(new StringBuilder("hello"));
		String s6 = new String();
		System.out.println("s6"+s6.isEmpty());
		System.out.println(s.charAt(0));
		System.out.println(s.concat(" friend"));
		System.out.println(s.contains("ell"));
		System.out.println(s.equals("hello"));
		System.out.println(s.equalsIgnoreCase("HELLO"));
		System.out.println(String.format("name is %s","rajesh"));  
		System.out.println(String.format("value is %f",32.33434));  
		System.out.println(String.format("value is %32.12f",32.33434));
		System.out.println("javapoint".substring(2,4));//returns va  
		System.out.println("javapoint".substring(2));//returns vatpoint
		String[] words="java string split method by javatpoint".split("\\s");//splits the string based on whitespace  
		//using java foreach loop to print elements of string array  
		for(String w:words){  
		System.out.println(w);  
		}  
		
		int value=30;  
		String s11=String.valueOf(value);  
		System.out.println(s11+10);
		
		/*System.out.println(s.endsWith("o"));
		System.out.println("abaaa".indexOf('a'));
		System.out.println("abaaa".indexOf("aaa"));
		System.out.println("abaaa".indexOf('a', 2));
		System.out.println("abaaa".indexOf('a', 2));
		//		1
		System.out.println(new String("My Hunaa").intern());
		//		1
		System.out.println(new String("").isEmpty());
		//		4
		System.out.println("abaaaabaaa".lastIndexOf('a'));
		System.out.println("abaaaabaaa".lastIndexOf("aaa"));
		System.out.println("abaaaabaaa".lastIndexOf('a', 5));
		System.out.println("abaaaabaaa".lastIndexOf("aaa", 5));
		//		1
		System.out.println("abaaaabaaa".length());
		//		1
		System.out.println("abaaaabaaa".matches("(.*aaa*.)"));
		//		2
		System.out.println("abaaaabaaa".replace('a', 'I'));
		System.out.println("abaaaabaaa".replaceAll("(.*aaa*.)", "mine"));
		System.out.println("abaaaabaaa".replaceFirst("(.*ab*.)", "1st"));*/
	}
}
