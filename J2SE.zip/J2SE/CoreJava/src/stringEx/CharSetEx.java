package stringEx;

import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;

public class CharSetEx {
	public static byte[] stringToBytesASCII(String str) {
		char[] buffer = str.toCharArray();
		byte[] b = new byte[buffer.length];
		for (int i = 0; i < b.length; i++) {
			b[i] = (byte) buffer[i];
		}
		return b;
	}
	
	public static void main1(String[] args) {
		byte[] bs = stringToBytesASCII("Rajeshkumar.V");
		for(byte b : bs)
			System.out.print((char)b+"");
		System.out.println();
		
//		OR
		
		for(byte b : "Rajeshkumar.V".getBytes())
			System.out.print((char)b+"");
	}
	public static void main(String[] args) throws UnsupportedEncodingException {
		System.out.println(Charset.defaultCharset());
		System.out.println(Charset.availableCharsets());
		System.out.println(new String("Rajeshkumar.V".getBytes(), Charset.forName("UTF-8")/*"windows-1252"*/));
	}
}