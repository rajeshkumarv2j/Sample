package stringEx;

public class ReverseAList {
	public static void main(String[] args) {
		String s = "Actual";
		
//		1st way
		char[] cs  = s.toCharArray();
		for(int i = cs.length-1; i > -1; i--){
			System.out.print(cs[i]);
		}
		System.out.println();
		
//		2nd way
		StringBuffer buffer = new StringBuffer(s);
		System.out.println(buffer.reverse());
		
//		3rd way
		char[] temparray = s.toCharArray();
		int left, right = 0;
		right = temparray.length - 1;
		for (left = 0; left < right; left++, right--) {
			// Swap values of left and right
			char temp = temparray[left];
			temparray[left] = temparray[right];
			temparray[right] = temp;
		}
		for (char c : temparray)
			System.out.print(c);
		System.out.println();
	}
}