package defaultmethodI;

public class FuncInterface {
}

interface Y {
	default public void toString1() {
		System.out.println("Y::toString1");
	}
}

interface Z extends Y {
	default public void toString1() {
		System.out.println("Z::toString1");
	}
}

class X implements Z {

	public void toString1() {
		System.out.println("X::toString1");
	}

	public static void main(String[] args) {
		Y z = new X();
		z.toString1();
	}
}

interface AI {
	default void fun1() {
		System.out.println("AI::Default...");
	}

	public static void staticFun() {
		System.out.println("AI::staticFun");
	}

	public void fun2();
}

interface BI {
	default void fun1() {
		System.out.println("BI::Default...");
	}

	public static void staticFun() {
		System.out.println("BI::staticFun");
	}

	public void fun2();
}

class F implements BI {
	public void fun1() {
		System.out.println("F::Default...");
	}

	@Override
	public void fun2() {
		// TODO Auto-generated method stub

	}
}

class B extends F implements AI, BI {
	public void fun1() {
		super.fun1();
		AI.super.fun1();
//		 BI.super.fun1();//Error : Illegal reference to super method fun1() from type BI, cannot bypass the more specific override from type F
		System.out.println("B::fun1");
	}

	@Override
	public void fun2() {
		System.out.println("B::fun2");
	}

	public static void main(String[] args) {
		F ai = new B();
		ai.fun1();
		ai.fun2();
	}
}

class A extends B implements AI, BI {// , BI{

	@Override
	public void fun1() {
		fun1();
		super.fun1();
//		AI.super.fun1();   //This gives error since B already overriden fun1() in B    -->Illegal reference to super method fun1() from type AI, cannot bypass the more specific override from type B
//		BI.super.fun1();	//This gives error since B already overriden fun1() in B
	}

	@Override
	public String toString() { // TODO Auto-generated method stub
		return super.toString();
	}
}
