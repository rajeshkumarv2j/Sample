package streams;

import java.util.stream.LongStream;

public class StreamSyntax {
	public static void main(String[] args) {
		long start = System.currentTimeMillis();
		System.out.println("Start...1");
		System.out.println(isPrime(1111111111111111111L));
		System.out.println("End...1");
		System.out.println(System.currentTimeMillis()-start);
		start = System.currentTimeMillis();
		System.out.println("Start...2");
		System.out.println(isPrime1(1111111111111111111L));
		System.out.println("End...2");
		System.out.println(System.currentTimeMillis()-start);
	}

	// Traditional approach
	private static boolean isPrime(long number) {
		if (number < 2)
			return false;
		for (int i = 2; i < number; i++) {
			if (number % i == 0)
				return false;
		}
		return true;
	}

	// Declarative approach
	private static boolean isPrime1(long number) {
		return number > 1 && LongStream.range(2, number).noneMatch(index -> number % index == 0);
	}
}
