package lamba;

public class LambaExample {
	public static void main(String[] args) {
		Runnable r2 = new Runnable() {
			public void run() {
				System.out.println("My Runnable2");
			}
		};
		for (int i = 0; i < 10; i++)
			new Thread(r2).start();

		Runnable r1 = () -> System.out.println("My Runnable1");
		for (int i = 0; i < 10; i++)
			new Thread(r1).start();

		/*MyFunClass myFunClass = new MyFunClass() {
			@Override
			public void doIt() {
				System.out.println("This is MyFunClass...");
			}
		};*/
		
		
		callIt((String s) -> System.out.println("This is Java 8 feature..."+s));
		
	}

	public static void callIt(MyFunClass myFunClass) {
		myFunClass.doIt("Hi");
	}

	interface MyFunClass {
		public void doIt(String s);
//		public void doIt1();
	}
}
