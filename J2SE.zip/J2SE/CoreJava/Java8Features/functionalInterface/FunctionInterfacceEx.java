package functionalInterface;

@FunctionalInterface
public interface FunctionInterfacceEx {
	public void doIt();

	boolean equals(Object obj);// This wont give any error because it is a method from Object class
	/*int equals1(Object obj);*/ 	// This will give error because it is not an object class method and already we have a method which is not from object class
}

@FunctionalInterface
interface X {
	int m(Iterable<String> arg);
}

@FunctionalInterface
interface Y {
	int m(Iterable<String> arg);
}

@FunctionalInterface
interface Z extends X, Y {
	int m(Iterable<String> arg);
}

@FunctionalInterface
interface X1 {
	int m(Iterable<String> arg, Class c);
}

@FunctionalInterface
interface Y1 {
	int m(Iterable arg, Class<?> c);
}

/**
 * Invalid '@FunctionalInterface' annotation; Z1 is not a functional interface
	- Name clash: The method m(Iterable, Class<?>) of type Y1 has the same erasure as m(Iterable<String>, Class) of type X1 but does not 
	 override it
 */
/*@FunctionalInterface
interface Z1 extends X1, Y1 {
}*/

@FunctionalInterface
interface X2 {
	long m();
}

@FunctionalInterface
interface Y2 {
	int m();
}

/**
 * 	- The return types are incompatible for the inherited methods 
	 X2.m(), Y2.m()
	- Invalid '@FunctionalInterface' annotation; Z2 is not a functional 
	 interface
 *
 */
/*@FunctionalInterface
interface Z2 extends X2, Y2 {
}*/


