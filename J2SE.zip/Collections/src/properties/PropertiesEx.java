package properties;
 
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Properties;
import java.util.Set;
 
public class PropertiesEx {

	/*
	 * The Properties class represents a persistent set of properties. The
	 * Properties can be saved to a stream or loaded from a stream. Each key and
	 * its corresponding value in the property list is a string. Because
	 * Properties inherits from Hashtable, the put and putAll methods can be
	 * applied to a Properties object. Their use is strongly discouraged as they
	 * allow the caller to insert entries whose keys or values are not Strings.
	 * The setProperty method should be used instead. If the store or save
	 * method is called on a "compromised" Properties object that contains a
	 * non-String key or value, the call will fail. Similarly, the call to the
	 * propertyNames or list method will fail if it is called on a "compromised"
	 * Properties object that contains a non-String key.
	 */
	
	private static Properties prop1;
	 
    static{
        InputStream is = null;
        try {
            prop1 = new Properties();
            is = ClassLoader.class.getResourceAsStream("/sample.properties");
            prop1.load(is);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
	     
    public static String getPropertyValue1(String key){
        return prop1.getProperty(key);
    }
	    
	private Properties prop = null;
    
    public PropertiesEx(){
         
        InputStream is = null;
        try {
            this.prop = new Properties();
            is = this.getClass().getResourceAsStream("/sample.properties");
            prop.load(is);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
     
    public String getPropertyValue(String key){
//        return this.prop.getProperty(key);
    	
//    	How to assign default values for unavailable keys in properties file?
    	return this.prop.getProperty(key, "Its Default Value");
    }
    
	public static void main(String a[]) throws IOException{
        
//		How to load Properties file from a file system?
        InputStream is = null;
        Properties prop = null;
        try {
            prop = new Properties();
            is = new FileInputStream(new File("C:/sample.properties"));
            prop.load(is);
            System.out.println("db.host: "+prop.getProperty("db.host"));
            System.out.println("db.user: "+prop.getProperty("db.user"));
            System.out.println("db.password: "+prop.getProperty("db.password"));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        
//        How to load Properties file from the classpath?
        PropertiesEx mpc = new PropertiesEx();
        System.out.println("db.host: "+mpc.getPropertyValue("db.host"));
        System.out.println("db.user: "+mpc.getPropertyValue("db.user"));
        System.out.println("db.password: "+mpc.getPropertyValue("db.password"));
        
//        How to load Properties file from a static block or static method?
        System.out.println("db.host: "+getPropertyValue1("db.host"));
        System.out.println("db.user: "+getPropertyValue1("db.user"));
        System.out.println("db.password: "+getPropertyValue1("db.password"));
        
        Set<Object> keys = prop.keySet();
        System.out.println(keys);
        
//        How to store in to property ?
        OutputStream os = null;
        prop = new Properties();
        prop.setProperty("name", "java2novice");
        prop.setProperty("domain", "www.java2novice.com");
        prop.setProperty("email", "java2novice@gmail.com");
        try {
            os = new FileOutputStream("D:/MyProp.properties");
            prop.store(os, "Dynamic Property File");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        
//        How to store property file as xml file?
        prop = new Properties();
        prop.setProperty("name", "java2novice");
        prop.setProperty("domain", "www.java2novice.com");
        prop.setProperty("email", "java2novice@gmail.com");
        try {
            os = new FileOutputStream("D:/MyProp.xml");
            prop.storeToXML(os, "Dynamic Property File");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        
    }
}