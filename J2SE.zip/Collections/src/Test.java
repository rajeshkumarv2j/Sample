import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.Vector;


public class Test {
	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		List<String> names = new ArrayList<String>();
		names.add("rajraj");
		names.add("");
		names.add("1");
		names.add("2");
		names.add("rajraj");
		
		Object object = ((ArrayList<String>)names).clone();
		List<String> clonedNames = (List<String>) cast(object);
		System.out.println(clonedNames.hashCode());
		System.out.println(names.hashCode());
		System.out.println(clonedNames.add("as"));
		System.out.println(clonedNames);
		System.out.println(names);
		System.out.println(clonedNames.equals(names));
		
		List<String> toAdd = new ArrayList<String>();
		toAdd.add("1");
		toAdd.add("2");
		toAdd.add("3");
		
		names.addAll(toAdd);
		System.out.println(names);
		
		
//		String []s = (String[]) names.toArray();
//		System.out.println(s);
		
		Object []s1 = names.toArray();
		System.out.println(s1);
		
		String []s2 = new String[names.size()];
		s2 = names.toArray(s2);
		System.out.println(s2);
		
		
		
		List<String> sl = names.subList(0, 2);
		System.out.println(sl);
		
		
		System.out.println(names);
		Collections.sort(names);
		System.out.println(names);
		
		
		ArrayList<Emp> emps = new  ArrayList<Emp>();
		emps.add(new Emp(1,"one"));
		emps.add(new Emp(2,"two"));
		emps.add(new Emp(0,"zero"));
		
		System.out.println(emps);
		
		Collections.sort(emps, new Comparator<Emp>() {
			@Override
			public int compare(Emp o1, Emp o2) {
				return o1.getId().compareTo(o2.getId());
			}
		});
		
		System.out.println(emps);
		
		
		
		
		StringBuilder builder = new StringBuilder();
        
//      ***** New way of creating ArrayList****
      
      for(String element : new ArrayList<String>(){/**
		 * 
		 */
		private static final long serialVersionUID = 6691645004460188556L;

	{this.add("a"); this.add("b");}}){
      	if(builder.length()!=0)
      		builder.append(",");
      	builder.append(element);
      }
      System.out.println("CSV........"+String.valueOf(builder));
      
      
      List<String> list = new ArrayList<String>(){/**
		 * 
		 */
		private static final long serialVersionUID = -5467200854265828416L;

	{this.add("a"); this.add("b");}};
      String g = list.toString();
      System.out.println(g.substring(1, g.length()-1));
     
      
      
      
      
      
      
      
      
      
      
      
      LinkedList<String> arrl = new LinkedList<String>();
      arrl.add("Orange");
      arrl.add("Apple");
      arrl.add("Grape");
      arrl.add("Banana");
      System.out.println(arrl);
      System.out.println("Size of the linked list: "+arrl.size());
      System.out.println("Is LinkedList empty? "+arrl.isEmpty());
      System.out.println("Does LinkedList contains 'Grape'? "+arrl.contains("Grape"));
      
      Iterator<String> itr = arrl.iterator();
      while(itr.hasNext()){
          System.out.println(itr.next());
      }
      System.out.println("Actual LinkedList:"+arrl);
		LinkedList<String> copy = (LinkedList<String>) arrl.clone();
		System.out.println("Cloned LinkedList:"+copy);
		
		LinkedList<String> copyByCon = new LinkedList<String>(arrl); 
		System.out.println(copyByCon+"...................");
		System.out.println(arrl.element());
		System.out.println(arrl.element());
		System.out.println(arrl.element());
		System.out.println(arrl.element());
		System.out.println(copyByCon.equals(arrl));
		
	
		
        Vector<String> vct = new Vector<String>();
        //adding elements to the end
        vct.add("First");
        vct.add("First");
        vct.add("asasas");
        
        vct.add("Third");
        System.out.println(vct);
        
        
		LinkedHashSet<String> lhs = new LinkedHashSet<String>();
		//add elements to HashSet
		lhs.add("first1");
		lhs.add("second1");
		lhs.add("third1");
		lhs.add("first");
		lhs.add("third");
		lhs.add(null);
		lhs.add(null);
		lhs.add(null);
		
			
		System.out.println(lhs);
		
		

		HashSet<String> lhs1 = new HashSet<String>();
		//add elements to HashSet
		lhs1.add("first");
		lhs1.add("second");
		lhs1.add(null);
		lhs1.add("third");
		
		System.out.println(lhs1);
		
		
		TreeSet<String> ts = new TreeSet<String>();
		ts.add("three");
		ts.add("two");
		ts.add("one");
		System.out.println("Elements: "+ts);
		
		
		List<String> li = new ArrayList<String>();
        li.add("one");
        li.add("two");
        li.add("three");
        li.add("four");
        System.out.println("List: "+li);
        //create a treeset with the list
        TreeSet<String> myset = new TreeSet<String>(li);
        System.out.println("Set: "+myset);
        
   String[] strArr = {"one","two","three","four","four","five"};
        //convert string array to list
        List<String> tmpList = Arrays.asList(strArr);
        //create a treeset with the list, which eliminates duplicates
        TreeSet<String> unique = new TreeSet<String>(tmpList);
        System.out.println(unique);
     
        
        TreeSet<String> ts1 = new TreeSet<String>(new MyComp());
        ts1.add("RED");
        ts1.add("ORANGE");
        ts1.add("BLUE");
        ts1.add("GREEN");
        System.out.println(ts1);
        
 
        
        TreeSet<Empl> nameComp = new TreeSet<Empl>(new MyNameComp());
        nameComp.add(new Empl("Ram",3000));
        nameComp.add(new Empl("John",6000));
        nameComp.add(new Empl("Crish",2000));
        nameComp.add(new Empl("Tom",2400));
        nameComp.add(new Empl("Tom",2400));

        for(Empl e:nameComp){
            System.out.println(e);
        }
        System.out.println("===========================");
        //By using salary comparator (int comparison)
        TreeSet<Empl> salComp = new TreeSet<Empl>(new MySalaryComp());
        salComp.add(new Empl("Ram",3000));
        salComp.add(new Empl("John",6000));
        salComp.add(new Empl("Crish",2000));
        salComp.add(new Empl("Tom",2400));
        for(Empl e:salComp){
            System.out.println(e);
        }
        
        
        Hashtable<String,String> hm = new Hashtable<String,String>();
        //add key-value pair to hashtable
        hm.put("first", "FIRST INSERTED");
        hm.put("second", "SECOND INSERTED");
        hm.put("third","THIRD INSERTED");
        hm.put("", "");
        hm.put(" ", "");
        hm.put("  ", "Raj");
        hm.put("", "Raj");
        System.out.println(hm);   
        hm.entrySet();
     
        
        /*HashSet<Price> lhm = new HashSet<Price>();
        lhm.add(new Price("Banana", 20));
        lhm.add(new Price("Apple", 40));
        lhm.add(new Price("Orange", 30));
        lhm.add(new Price("Orange", 30));
        lhm.add(new Price("Orange", 30));
        for(Price pr:lhm){
            System.out.println(pr);
        }
        */
        
        
        System.out.println(".........................................................................");

        HashMap<Price, String> map = new HashMap<Price, String>();
        map.put(new Price("1", 10), "one");
        map.put(new Price("2", 10), "two");
        map.put(new Price("3", 10), "three");
        map.put(new Price("4", 10), "four");
        map.put(new Price("5", 10), "five");
        map.put(new Price("5", 10), "five");
        
        
        System.out.println(map);
        
        Set<Entry<Price,String>> entries = map.entrySet();
        
        for (Entry<Price, String> entry : entries) {
			System.out.println(entry);
		}
        List<Price> list2 = new ArrayList<Price>(map.keySet());
        
        Collections.sort(list2, new Comparator<Price>() {
        	@Override
        	public int compare(Price o1, Price o2) {
        		return o1.getItem().compareTo(o2.getItem());
        	}
		});
        
        LinkedHashMap<Price, String> lhm1 = new LinkedHashMap<Price, String>();
        for (Price price : list2) {
			lhm1.put(price, map.get(price));
		}
        
        System.out.println(lhm1);
        
        
//        other way is :
        
        /*TreeMap<String, String> treeMap = new TreeMap<String, String>(map);
        System.out.println(treeMap);
        */
        
        System.out.println("**********************************************************************************");

        HashMap<String, String> map1 = new HashMap<String, String>();
        map1.put("1", "one");
        map1.put("2", "two");
        map1.put("3",  "three");
        map1.put("4", "four");
        map1.put("5",  "five");
        map1.put("5",  "five");
        
        Set<Entry<String,String>> entries2 = map1.entrySet();
        
        TreeSet<Entry<String,String>> treeSet = new TreeSet<Entry<String,String>>(new Comparator<Entry<String, String>>() {
		@Override
		public int compare(Entry<String, String> o1,
				Entry<String, String> o2) {
			return o1.getValue().compareTo(o2.getValue());
		}
        });
        
        treeSet.addAll(entries2);
        
        
        System.out.println("*********************************************************");
        
        
        
        
        HashMap<String, Price> map12 = new HashMap<String, Price>();
        map12.put("1", new Price("1", 1));
        map12.put("2", new Price("2", 2));
        map12.put("3",  new Price("3", 3));
        map12.put("4", new Price("4", 4));
        map12.put("5",  new Price("5", 5));
        map12.put("5",  new Price("5", 5));
        
        Set<Entry<String,Price>> entries22 = map12.entrySet();
        
        TreeSet<Entry<String,Price>> treeSet1 = new TreeSet<Entry<String,Price>>(new Comparator<Entry<String, Price>>() {
		@Override
		public int compare(Entry<String, Price> o1,
				Entry<String, Price> o2) {
			return o1.getValue().getItem().compareTo(o2.getValue().getItem());
		}
        });
        
        treeSet1.addAll(entries22);
        
        
        
        System.out.println(treeSet1);
        
	}
	
	public static <T extends List<String>> T cast(Object t1){
		@SuppressWarnings("unchecked")
		T t = (T) t1;
		return t;
	}
	
	
}
class Empl {

    private String name;
    private int salary;
     
    public Empl(String n, int s){
        this.name = n;
        this.salary = s;
    }
     
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public int getSalary() {
        return salary;
    }
    public void setSalary(int salary) {
        this.salary = salary;
    }
    public String toString(){
        return "Name: "+this.name+"-- Salary: "+this.salary;
    }
}
class MyComp implements Comparator<String>{
	 
    @Override
    public int compare(String str1, String str2) {
        return str1.compareTo(str2);
    }
     
}

class MyStrComp implements Comparator<String>{
	 
    @Override
    public int compare(String str1, String str2) {
        return str1.compareTo(str2);
    }
     
}

/*class MyComp implements Comparator<String>{
	 
    @Override
    public int compare(String str1, String str2) {
        return str1.compareTo(str2);
    }
     
}*/

class MyNameComp implements Comparator<Empl>{
	 
    @Override
    public int compare(Empl e1, Empl e2) {
        return e1.getName().compareTo(e2.getName());
    }
}   
 
class MySalaryComp implements Comparator<Empl>{
 
    @Override
    public int compare(Empl e1, Empl e2) {
        if(e1.getSalary() > e2.getSalary()){
            return 1;
        } else {
            return -1;
        }
    }
}
class Price{
    
    private String item;
    private int price;
     
    public Price(String itm, int pr){
        this.item = itm;
        this.price = pr;
    }

    
    public int hashCode(){
        System.out.println("In hashcode");
        int hashcode = 0;
        hashcode = price*20;
        hashcode += item.hashCode();
        return hashcode;
    }
     
    public boolean equals(Object obj){
        System.out.println("In equals");
        if (obj instanceof Price) {
            Price pp = (Price) obj;
            return (pp.item.equals(this.item) && pp.price == this.price);
        } else {
            return false;
        }
    }   
     
    public String getItem() {
        return item;
    }
    public void setItem(String item) {
        this.item = item;
    }
    public int getPrice() {
        return price;
    }
    public void setPrice(int price) {
        this.price = price;
    }
     
    public String toString(){
        return "item: "+item+"  price: "+price;
    }
}