package treeset;
 
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
 
public class TreeSetEx {

	/*
	 * TreeSet is a NavigableSet implementation based on a TreeMap. The elements
	 * are ordered using their natural ordering, or by a Comparator provided at
	 * set creation time, depending on which constructor is used. This
	 * implementation provides guaranteed log(n) time cost for the basic
	 * operations (add, remove and contains).
	 */
	
public static void main(String a[]){
		
		TreeSet<String> ts = new TreeSet<String>();
		ts.add("one");
		ts.add("two");
		ts.add("three");
		System.out.println("Elements: "+ts);
		//check is set empty?
		System.out.println("Is set empty: "+ts.isEmpty());
		//delete all elements from set
		ts.clear();
		System.out.println("Is set empty: "+ts.isEmpty());
		ts.add("one");
		ts.add("two");
		ts.add("three");
		System.out.println("Size of the set: "+ts.size());
		//remove one string
		ts.remove("two");
		System.out.println("Elements: "+ts);
		
//		 how to create TreeSet with other collection. ?
		List<String> li = new ArrayList<String>();
        li.add("one");
        li.add("two");
        li.add("three");
        li.add("four");
        System.out.println("List: "+li);
        //create a treeset with the list
        TreeSet<String> myset = new TreeSet<String>(li);
        System.out.println("Set: "+myset);
        
//        iterate treeset
		Iterator<String> itr = ts.iterator();
		while(itr.hasNext()){
			System.out.println(itr.next());
		}
		
//		 easiest way to remove duplicate entries from the given array?
		String[] strArr = {"one","two","three","four","four","five"};
        //convert string array to list
        List<String> tmpList = Arrays.asList(strArr);
        //create a treeset with the list, which eliminates duplicates
        TreeSet<String> unique = new TreeSet<String>(tmpList);
        System.out.println(unique);
        
//      Add a comparator
        TreeSet<String> ts1 = new TreeSet<String>(new MyComp());
        ts1.add("RED");
        ts1.add("ORANGE");
        ts1.add("BLUE");
        ts1.add("GREEN");
        System.out.println(ts1);
        
        
        
        
      //By using name comparator (String comparison)
        TreeSet<Empl> nameComp = new TreeSet<Empl>(new MyNameComp());
        nameComp.add(new Empl("Ram",3000));
        nameComp.add(new Empl("John",6000));
        nameComp.add(new Empl("Crish",2000));
        nameComp.add(new Empl("Tom",2400));
        for(Empl e:nameComp){
            System.out.println(e);
        }
        System.out.println("===========================");
        //By using salary comparator (int comparison)
        TreeSet<Empl> salComp = new TreeSet<Empl>(new MySalaryComp());
        salComp.add(new Empl("Ram",3000));
        salComp.add(new Empl("John",6000));
        salComp.add(new Empl("Crish",2000));
        salComp.add(new Empl("Tom",2400));
        for(Empl e:salComp){
            System.out.println(e);
        }
        
//     SubSet of treeset
        TreeSet<String> ts2 = new TreeSet<String>(new MyStrComp());
        ts2.add("RED");
        ts2.add("ORANGE");
        ts2.add("BLUE");
        ts2.add("GREEN");
        ts2.add("WHITE");
        ts2.add("BROWN");
        ts2.add("YELLOW");
        ts2.add("BLACK");
        System.out.println(ts2);
        Set<String> subSet = ts2.subSet("GREEN", "WHITE");
        System.out.println("sub set: "+subSet);
        subSet = ts2.subSet("GREEN", true, "WHITE", true);
        System.out.println("sub set: "+subSet);
        subSet = ts2.subSet("GREEN", false, "WHITE", true);
        System.out.println("sub set: "+subSet);
 /*
  * 
  *        [BLACK, BLUE, BROWN, GREEN, ORANGE, RED, WHITE, YELLOW]
sub set: [GREEN, ORANGE, RED]
sub set: [GREEN, ORANGE, RED, WHITE]
sub set: [ORANGE, RED, WHITE]

  */
//        How you can get least value element from set?
//      First value after sorting        
        System.out.println("Least salary emp: "+salComp.first());
//        Last value after sorting
        System.out.println("Highest salary emp: "+salComp.last());
//      Get equals or more than that element
        System.out.println("Highest salary emp: "+salComp.ceiling(new Empl("Tom",2400)));        
//      Get Iterator with elements in Descending order 
        Iterator<Empl> iterator = salComp.descendingIterator();
        while(iterator.hasNext()){
        	System.out.println(iterator.next());
        }
//        Get set of elements in descending order
        Set<Empl> empls = salComp.descendingSet();
        Iterator<Empl> iterator2 = empls.iterator();
        while(iterator2.hasNext()){
        	System.out.println(iterator2.next());
        }
        
//      Get greatest element which is equal or less than below element
        System.out.println(salComp.floor(new Empl("Tom", 2400)));

//      Returns set of elements which are lesser than the given element
        System.out.println("Headset elements.."+salComp.headSet(new Empl("John", 6000)));

//      Returns set of elements which are lesser than the given element
        System.out.println("Headset elements.."+salComp.headSet(new Empl("John", 6000), true));
        
        
	}
}
class MyComp implements Comparator<String>{
	 
    @Override
    public int compare(String str1, String str2) {
        return str1.compareTo(str2);
    }
     
}

class MyNameComp implements Comparator<Empl>{
	 
    @Override
    public int compare(Empl e1, Empl e2) {
        return e1.getName().compareTo(e2.getName());
    }
}   
 
class MySalaryComp implements Comparator<Empl>{
 
    @Override
    public int compare(Empl e1, Empl e2) {
        if(e1.getSalary() > e2.getSalary()){
            return 1;
        } else {
            return -1;
        }
    }
}
 
class Empl{
     
    private String name;
    private int salary;
     
    public Empl(String n, int s){
        this.name = n;
        this.salary = s;
    }
     
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public int getSalary() {
        return salary;
    }
    public void setSalary(int salary) {
        this.salary = salary;
    }
    public String toString(){
        return "Name: "+this.name+"-- Salary: "+this.salary;
    }
}

class MyStrComp implements Comparator<String>{
	 
    @Override
    public int compare(String str1, String str2) {
        return str1.compareTo(str2);
    }
     
}