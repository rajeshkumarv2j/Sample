package hashset;
 
import java.util.HashSet;
import java.util.Iterator;
 
public class HashSetEx {

	/*
	 * The HashSet class implements the Set interface, backed by a hash table
	 * (actually a HashMap instance). It makes no guarantees as to the iteration
	 * order of the set; in particular, it does not guarantee that the order
	 * will remain constant over time. This class permits the null element. This
	 * class offers constant time performance for the basic operations (add,
	 * remove, contains and size), assuming the hash function disperses the
	 * elements properly among the buckets. Iterating over this set requires
	 * time proportional to the sum of the HashSet instance's size (the number
	 * of elements) plus the "capacity" of the backing HashMap instance (the
	 * number of buckets). Thus, it's very important not to set the initial
	 * capacity too high (or the load factor too low) if iteration performance
	 * is important.
	 */
    public static void main(String a[]){
        HashSet<String> hs = new HashSet<String>();
        //add elements to HashSet
        hs.add("first");
        hs.add("second");
        hs.add("third");
        hs.add(null);
        hs.add(null);//It will omit this null
        hs.add(null);//It will omit this null
        System.out.println(hs);
        System.out.println("Is HashSet empty? "+hs.isEmpty());
        hs.remove("third");
        System.out.println(hs);
        System.out.println("Size of the HashSet: "+hs.size());
        System.out.println("Does HashSet contains first element? "+hs.contains("first"));
        
//        Iterate the set
        Iterator<String> itr = hs.iterator();
		while(itr.hasNext()){
			System.out.println(itr.next());
		}
		
		System.out.println(hs);
		HashSet<String> subSet = new HashSet<String>();
		subSet.add("s1");
		subSet.add("s2");
		hs.addAll(subSet);
		System.out.println("HashSet content after adding another collection:");
		System.out.println(hs);
		
		/*
		 * OUTPUT :
		 * [second, third, first]
HashSet content after adding another collection:
[s2, s1, second, third, first
		 * 
		 */
		
		//clear the map
		hs.clear();
		
//		how to copy all elements from HashSet to an array. ?
		System.out.println("HashSet content: ");
        System.out.println(hs);
        String[] strArr = new String[hs.size()];
        hs.toArray(strArr);
        System.out.println("Copied array content:");
        for(String str:strArr){
            System.out.println(str);
        }
        
//      how to compare two sets, and retain the values which are common on both set objects?
        hs.clear();
        
        hs.add("first");
        hs.add("second");
        hs.add("third");
        hs.add("apple");
        hs.add("rat");
        System.out.println(hs);
        HashSet<String> subSet1 = new HashSet<String>();
        subSet1.add("rat");
        subSet1.add("second");
        subSet1.add("first");
        hs.retainAll(subSet);
        System.out.println("HashSet content:");
        System.out.println(hs);
        /*
         * 
         * OUTPUT :
         * 
         * [second, apple, rat, third, first]
			HashSet content:
			[second, rat, first]
         * 
         */
 
//        Adding User defined and avoiding duplicates on HashSet
        HashSet<Price> lhm = new HashSet<Price>();
        lhm.add(new Price("Banana", 20));
        lhm.add(new Price("Apple", 40));
        lhm.add(new Price("Orange", 30));
        for(Price pr:lhm){
            System.out.println(pr);
        }
        Price duplicate = new Price("Banana", 20);
        System.out.println("inserting duplicate object...");
        lhm.add(duplicate);
        System.out.println("After insertion:");
        for(Price pr:lhm){
            System.out.println(pr);
        }
     /*
      * How to find user defined objects from HashSet?
      */
        Price key = new Price("Banana", 20);
        System.out.println("Does set contains key? "+lhm.contains(key));
        
        /*
         * How to delete user defined objects from HashSet?
         */   
        Price key1 = new Price("Banana", 20);
        System.out.println("deleting key from set...");
        lhm.remove(key1);
        System.out.println("Elements after delete:");
        for(Price pr:lhm){
            System.out.println(pr);
        }
        
        
    }
}

class Price{
    
    private String item;
    private int price;
     
    public Price(String itm, int pr){
        this.item = itm;
        this.price = pr;
    }
     
    public int hashCode(){
        System.out.println("In hashcode");
        int hashcode = 0;
        hashcode = price*20;
        hashcode += item.hashCode();
        return hashcode;
    }
     
    public boolean equals(Object obj){
        System.out.println("In equals");
        if (obj instanceof Price) {
            Price pp = (Price) obj;
            return (pp.item.equals(this.item) && pp.price == this.price);
        } else {
            return false;
        }
    }
     
    public String getItem() {
        return item;
    }
    public void setItem(String item) {
        this.item = item;
    }
    public int getPrice() {
        return price;
    }
    public void setPrice(int price) {
        this.price = price;
    }
     
    public String toString(){
        return "item: "+item+"  price: "+price;
    }
}