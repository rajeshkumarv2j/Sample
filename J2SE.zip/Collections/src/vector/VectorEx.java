package vector;
 
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Vector;
 
public class VectorEx {

	/*
	 * The Vector class implements a growable array of objects. Like an array,
	 * it contains components that can be accessed using an integer index.
	 * However, the size of a Vector can grow or shrink as needed to accommodate
	 * adding and removing items after the Vector has been created.
	 */
	public static void main(String a[]){

        Vector<String> vct = new Vector<String>();
        //adding elements to the end
        vct.add("First");
        vct.add("Second");
        vct.add("Third");
        System.out.println(vct);
        //adding element at specified index
        vct.add(2,"Random");
        System.out.println(vct);
        //getting elements by index
        System.out.println("Element at index 3 is: "+vct.get(3));
        //getting first element
        System.out.println("The first element of this vector is: "+vct.firstElement());
        //getting last element
        System.out.println("The last element of this vector is: "+vct.lastElement());
        //how to check vector is empty or not
        System.out.println("Is this vector empty? "+vct.isEmpty());
        
        //With Enumeration
        Enumeration<String> en = null;
        en = vct.elements();
        while(en.hasMoreElements()){
            System.out.println(en.nextElement());
        }
        
        //with Iterator
        Iterator<String> it = null;
        it = vct.iterator();
        while(it.hasNext()){
            System.out.println(it.next());
        }
        
        //with ListIterator
        ListIterator<String> lit = null;
        lit = vct.listIterator();
        while(lit.hasNext()){
            System.out.println(lit.next());
        }
        while(lit.hasPrevious()){
            System.out.println(lit.previous());
        }
        
        
        //Clone the vector object
        Vector<String> copy = (Vector<String>) vct.clone();
        System.out.println("Cloned vector:"+copy);
        
        Vector<String> strings = new Vector<String>();
        
        System.out.println("Actual vector:"+vct);
        List<String> list = new ArrayList<String>();
        list.add("one");
        list.add("two");
        System.out.println("Does vector contains all list elements?: "+vct.containsAll(list));
        vct.addAll(list);
        System.out.println("Does vector contains all list elements?: "+vct.containsAll(list));
        System.out.println("After Copy: "+vct);
    
		// You can copy all elements of a vector object to an array. By passing
		// an array object to copyInto() method
        System.out.println("Actual vector:"+vct);
        String[] copyArr = new String[vct.size()];
        vct.copyInto(copyArr);
        System.out.println("Copied Array content:");
        for(String str:copyArr){
            System.out.println(str);
        }
        
		// You can copy a range of vector content. The method subList() helps us
		// to get sub range from the given vector object.
        System.out.println("Actual vector:"+vct);
        List<String> list1 = vct.subList(2, 4);
        System.out.println("Sub List: "+list1);
    }
}