package arraylist;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class ArrayListEx {

	/*
	 * ArrayList is a resizable-array implementation of the List interface.
	 * Implements all optional list operations, and permits all elements,
	 * including null. In addition to implementing the List interface, this
	 * class provides methods to manipulate the size of the array that is used
	 * internally to store the list. (This class is roughly equivalent to
	 * Vector, except that it is unsynchronized.)
	 */
	public static void main(String a[]) throws CloneNotSupportedException {

		
		ArrayList<String> arrl = new ArrayList<String>();
        //adding elements to the end
        arrl.add("First");
        arrl.add("Second");
        arrl.add("Third");
        arrl.add("Random");
        arrl.add(null);
        arrl.add(null);
//Cloning List
        System.out.println("Actual ArrayList:"+arrl);
        @SuppressWarnings("unchecked")
		ArrayList<String> copy = (ArrayList<String>) arrl.clone();
        System.out.println("Cloned ArrayList:"+copy);
        
//Add collection to list
        System.out.println("Actual ArrayList:"+arrl);
        List<String> list = new ArrayList<String>();
        list.add("one");
        list.add("two");
        arrl.addAll(list);
        System.out.println("After Copy: "+arrl);
        
//Copy list to an array
        System.out.println("Actual ArrayList:"+arrl);
        String[] strArr = new String[arrl.size()];
        arrl.toArray(strArr);
        System.out.println("Created Array content:");
        for(String str:strArr){
            System.out.println(str);
        }
		
//getting a sublist from list
        System.out.println("Actual ArrayList:"+arrl);
        List<String> list3 = arrl.subList(2, 4);
        System.out.println("Sub List: "+list3);
        
/*Q) How to sort a list consist of user defined employee objects?
		How many ways to sort? Ans is below.*/
//adding user defined objects and sorting        
        List<Emp> emps = new ArrayList<Emp>();
        emps.add(new Emp("raj",1));
        emps.add(new Emp("sai",2));
        emps.add(new Emp("dinesh",3));
        emps.add(new Emp("barath",4));
		
        System.out.println("Before sorting..."+emps);
        
//**** Inside the Collections.sort() and sort(T, Comparator<T>), Arrays.sort methods only they 
        //are calling, No extra logic they are using
        
		// This below code need to write, when your Emp class has not
		// implemented the Comparable interface and override the compareTo
		// method.
        /*Collections.sort(emps, new Comparator<Emp>() {
        	@Override
        	public int compare(Emp o1, Emp o2) {
        		return o1.getName().compareTo(o2.getName());
        	}
		});*/
//        OR
/*//To Collections.sort() to sort user defined objects we need to pass either 
        //comparable implemented objects or normal objects and comparator object, then only sort() will work.
        Collections.sort(emps, null);
        */
//        OR ToSort is an inner class
        /*Collections.sort(emps, new ToSort());
        System.out.println("After sorting..."+emps);
        */
//        OR below is static inner class with comparator logic
        Collections.sort(emps, new Emp.ToSort.ToSort1().new ToSort11());
        System.out.println("After sorting..."+emps);
        
//      OR below is inner class with comparator logic
        /*Collections.sort(emps, new Emp().new ToSort());
        System.out.println("After sorting..."+emps);
                */
        
//        OR Emp object we are passing as it has comparator logic
        Collections.sort(emps, new Emp());
        System.out.println("After sorting..."+emps);
        
        list.add("Java");
        list.add("Cric");
        list.add("Play");
        list.add("Watch");
        list.add("Glass");
        list.add("Movie");
        list.add("Girl");
         // how to shuffle elements in the ArrayList?
        Collections.shuffle(list);
        System.out.println("Results after shuffle operation:");
        for(String str: list){
            System.out.println(str);
        }
         
        Collections.shuffle(list);
        System.out.println("Results after shuffle operation:");
        for(String str: list){
            System.out.println(str);
        }	
        // how to swap two elements in the ArrayList?
        Collections.swap(list, 2, 5);
        System.out.println("Results after swap operation:");
        for(String str: list){
            System.out.println(str);
        }
        
//      How to convert given list of strings to comma separated values (csv) format?
        
        StringBuilder builder = new StringBuilder();
        
//        ***** New way of creating ArrayList****
        
        for(String element : new ArrayList<String>(){{this.add("a"); this.add("b");}}){
        	if(builder.length()!=0)
        		builder.append(",");
        	builder.append(element);
        }
        System.out.println("CSV........"+String.valueOf(builder));
        
        
        
        List<String> myList = new ArrayList<String>();
		myList.add("Java");
		myList.add("Unix");
		myList.add("Oracle");
		myList.add("C++");
		

		//To add elements at specific location.
		myList.add(0, "Perl");
		myList.add(1, "Perl1");
		System.out.println(myList.get(0).equals("Perl"));
		System.out.println(myList.hashCode());
		
		//get the index of particular element
		System.out.println(myList.indexOf("Perl1"));
		
		//replace the old element with new element of specific index
		myList.set(0, "NoPerl");
		
		//get the sublist from exixting list
		System.out.println(myList.subList(2, 4));
		
		//convert to array
		Object[] g = myList.toArray();
		System.out.println(g);
		
		//To check weither list is empty or not
		System.out.println(myList.isEmpty());
		
		//check object exist in list
		System.out.println(myList.contains("Perl"));
		
		//get the iterator
		Iterator<String> itr = myList.iterator();
		while (itr.hasNext()) {
			System.out.println(itr.next());
		}
		
		// Using ListIterator, we can iterate all elements of a list in either
		// direction. You can access next element by calling next() method, and
		// also you can access previous element by calling previous() method on
		// the list.
		
		//get the ListIterator -> we can get next and previous elements also
		System.out.println("Elements in forward directiton");
		ListIterator<String> listItr = myList.listIterator();
		while ((listItr).hasNext()) {
			System.out.println(listItr.next());
		}
		System.out.println("Elements in backward directiton");
		while(listItr.hasPrevious()){
            System.out.println(listItr.previous());
        }
	}
}

class ToSort implements Comparator<Emp>{

	@Override
	public int compare(Emp o1, Emp o2) {
		return o1.getName().compareTo(o2.getName());
	}
}

class Emp implements Comparable<Emp>,Comparator<Emp>{

	private String name;
	private Integer age;
	
	public Emp() {
	}
	
	public Emp(String name, int age) {
		this.age = age;
		this.name = name;
	}

	public void setAge(Integer age) {
		this.age = age;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public Integer getAge() {
		return age;
	}
	
	public String getName() {
		return name;
	}
	
	@Override
	public String toString() {
		return "Emp [name=" + name + ", age=" + age + "]";
	}

	@Override
	public int compareTo(Emp o) {
		return this.getName().compareTo(o.getName());
	}
	
/*	public static class ToSort implements Comparator<Emp>{

		@Override
		public int compare(Emp o1, Emp o2) {
			return o1.getName().compareTo(o2.getName());
		}
	}*/
	/*public class ToSort implements Comparator<Emp>{

		@Override
		public int compare(Emp o1, Emp o2) {
			return o1.getName().compareTo(o2.getName());
		}
	}*/
	
	public static class ToSort implements Comparator<Emp> {
@Override
public int compare(Emp o1, Emp o2) {
	// TODO Auto-generated method stub
	return 0;
}
	public static class ToSort1
	implements Comparator<Emp> {
		@Override
		public int compare(Emp o1, Emp o2) {
			// TODO Auto-generated method stub
			return 0;
	}

		public class ToSort11
		implements Comparator<Emp> {
			@Override
			public int compare(Emp o1, Emp o2) {
				// TODO Auto-generated method stub
				return 0;
		}
		}
		
	}
	}
	
	@Override
	public int compare(Emp o1, Emp o2) {
		return o1.getName().compareTo(o2.getName());
	}
}
