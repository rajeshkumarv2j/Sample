package headfirst.factory.pizzaaf;

public class Eggplant implements Veggies {

	public String toString() {
		return "Eggplant";
	}
}
