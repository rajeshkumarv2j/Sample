package threadEx;

public class ThreadDemo implements Runnable {

	static Thread s;
   public void run() {
      Thread t = Thread.currentThread();
      System.out.print(t.getName());
      //checks if this thread is alive
      for (int i=0; i<2000; i++) {
		System.out.print(i++);
	}
      System.out.println(", status = " + t.isAlive());
   }

   public static void main(String args[]) throws Exception {
      System.out.println("Start");
      s = Thread.currentThread();
	   Thread t = new Thread(new ThreadDemo());
      // this will call run() function
      t.start();
      // waits for this thread to die
      t.join();
      System.out.print(t.getName());
      //checks if this thread is alive
      System.out.println(", status = " + t.isAlive());
      System.out.println("End");
   }
}