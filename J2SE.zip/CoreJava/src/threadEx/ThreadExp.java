package threadEx;

public class ThreadExp {
	public static void main(String[] args) throws InterruptedException {
		Thread11 t1 = new Thread11();
		t1.start();
		synchronized (t1) {
			for (int i = 0; i < 10; i++) {
				t1.notify();
				System.out.println("Producer...." + i);
				if (i == 9) {
					t1.z = i;
					t1.wait();
					if (t1.z == 1) {
						i = 0;
						continue;
					}
				}
			}
		}
	}
}

class Thread11 extends Thread {
	int z = 0;

	@Override
	public void run() {
		synchronized (this) {
			for (int i = 9; i > 0; i--) {
				notify();
				System.out.println("Consumer...." + i);
				if (i == 1) {
					z = i;
					try {
						wait();
						if (z == 9) {
							i = 9;
							continue;
						}
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}
		}
	}
}