package threadEx;
 public class ThreadExample{
	public static void main(String[] args) throws InterruptedException {
		Thread1 thread1 = new Thread1();
		thread1.start();
		synchronized (thread1) {
			System.out.println("First Statement");
			thread1.wait();
		}
	}
 }
 class Thread1 extends Thread{
	 @Override
	public void run() {
		 synchronized (this) {
			 for(int i=0; i<100; i++){
				 System.out.println(i);
			 }
			 notify();
		 }
	}
 }