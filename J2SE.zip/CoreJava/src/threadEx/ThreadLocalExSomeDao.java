package threadEx;

import java.text.SimpleDateFormat;
import java.util.Date;

public class ThreadLocalExSomeDao {

	private static final ThreadLocal<SimpleDateFormat> dateFormat = new ThreadLocal<SimpleDateFormat>(){
		@Override
		protected SimpleDateFormat initialValue() {
			return new SimpleDateFormat("MM DD YYYY");
		}
	};

	void select1Operation(Date date) {
		// After executing query.. We get Date object that needs to format and set to some VO object
		String dateSg = dateFormat.get().format(date);
		System.out.println(dateSg);
	}
}