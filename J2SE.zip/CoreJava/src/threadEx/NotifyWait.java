package threadEx;

import threadEx.NotifyWait.SharedResource;

public class NotifyWait {

	class ThreadA extends Thread {
		
		private SharedResource b;
		public ThreadA(SharedResource resource) {
			b = resource;
		}
		@Override
		public void run() {
			synchronized (b) {
				System.out.println("Started...ThreadA");
				try {
					System.out.println("Waiting for b to complete...");
					b.wait();
					System.out.println("after wait...");
				} catch (InterruptedException e) {
					e.printStackTrace();
				}

				System.out.println("Total is: " + b.total);
				System.out.println("Ended...ThreadA");
			}
		}
	}

	class ThreadB extends Thread {
		private SharedResource r;

		public ThreadB(SharedResource resource) {
			r =resource;
		}

		@Override
		public void run() {
			System.out.println("Hi");
			synchronized (r) {
				System.out.println("Started...ThreadB");
				for (int i = 0; i < 100; i++) {
					r.total += i;
				}
				r.notify();
			}
		}
	}
	
	static class SharedResource {
		public int total;

		void function(){
			System.out.println("Function...");
		}
	}
	
	public static void main(String[] args) throws InterruptedException {
		System.out.println("Start");
		NotifyWait notifyWait = new NotifyWait();

		SharedResource resource = new SharedResource();

		ThreadB threadB = notifyWait.new ThreadB(resource);
		ThreadA threadA = notifyWait.new ThreadA(resource);
		
		threadA.start();
		threadB.start();
		
		threadA.join();
		threadB.join();
		
		System.out.println("Total is: " + resource.total);
		System.out.println("End");
	}
}