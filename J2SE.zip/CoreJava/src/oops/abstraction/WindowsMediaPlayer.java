package oops.abstraction;

public class WindowsMediaPlayer extends AbstractPlayer{

	public WindowsMediaPlayer() {
	}
	
	public WindowsMediaPlayer(String player) {
		super(player);
	}
	
	@Override
	public void start() {
		System.out.println("WindowsMediaPlayer Player has Started !!!");
	}

	@Override
	public void stop() {
		System.out.println("WindowsMediaPlayer Player has Stoped !!!");
	}

}