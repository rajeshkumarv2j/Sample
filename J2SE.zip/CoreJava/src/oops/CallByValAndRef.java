package oops;

import java.util.ArrayList;

public class CallByValAndRef {
	public static void main(String[] args) {
		Emp s = new Emp("Rajesh");
		System.out.println(s);
		changeHere(s);
		System.out.println(s);
		
		ArrayList<String> strings = new ArrayList<String>();
		strings.add("1");
		strings.add("2");
		strings.add("3");
		strings.add("4");
		System.out.println(strings);
		changeListHere(strings);
		System.out.println(strings);
		
		
		
		
		/*CallByValAndRef andRef = new CallByValAndRef();
		String s1 = "Rajesh";
		andRef.changeHere1(s1);
		System.out.println(s1);
		
		ArrayList<String> strings1 = new ArrayList<String>();
		strings1.add("1");
		strings1.add("2");
		strings1.add("3");
		strings1.add("4");
		System.out.println(strings1);
		andRef.changeListHere1(strings1);
		System.out.println(strings1);*/
	}

	private static void changeListHere(ArrayList<String> strings) {
//		Old value got changed
		strings.add("Did u see this...?");
		
		/**
		 * But new object can`t be passed to called method, it available only to
		 * local method..
		 */
		strings = new ArrayList<String>();
		strings.add("xxx");
		
	}

	private static void changeHere(Emp s) {
		s.setS("Kumar");
		
		s= new Emp("Velishoju");
	}

	private void changeListHere1(ArrayList<String> strings) {
		strings.add("Did u see this...?");
	}

	private void changeHere1(String s) {
		s = "kumar";
		
	}
		
	
}
class Emp{
	String s;
	public Emp() {
	}
	public Emp(String s) {
		super();
		this.s = s;
	}


	public void setS(String s) {
		this.s = s;
	}
	public String getS() {
		return s;
	}
	@Override
	public String toString() {
		return "Emp [s=" + s + "]";
	}
	
}
