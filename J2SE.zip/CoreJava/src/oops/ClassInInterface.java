package oops;

public interface ClassInInterface {
	int i = 0;
	void method();
	class MyImpl{
		public static void main(String[] args) {
			System.out.println("Hi...");
		}
	}
	public interface HelloInterface {
		 
	    public static class HelloException extends Exception {
	         public HelloException(String msg){
	               super(msg);
	         }
	    }
	 
	    public void hello() throws HelloException;
	 
	}
}
