package bitwiseoperators;

public class BinaryExample {

	public static void main(String[] args) {
		System.out.println(Integer.toBinaryString(10));
		System.out.println(Integer.toBinaryString(20));
		// 1010 = binary value of 10 base 2
		// 10100 = binary value of 20 base 2

		// OR=>0 0 0 remaining 1
		System.out.println(6 | 5);
		// AND=>1 1 1 remaining 0
		System.out.println(6 & 5);
		// XOR=>0 0 0 and 1 1 0 remaining 1
		System.out.println(6 ^ 5);

		int number1 = 2; // 0010

		// example of bitwise unary complement operator (~)
		System.out.println(" value of number before: " + number1);
		System.out.println(" value of number after negation: " + ~number1);

		int number = 8; // 0000 1000
		System.out.println("Original number : " + number);

		// left shifting bytes with 1 position
		number = number << 1; // should be 16 i.e. 0001 0000

		// equivalent of multiplication of 2
		System.out.println("value of number after left shift:(number<<1) "
				+ number);

		number = -8;
		// right shifting bytes with sign 1 position
		number = number >> 1;

		// equivalent of division of 2
		System.out
				.println("value of number after right shift with sign: (number>>1) "
						+ number);

		number = -8;
		// right shifting bytes without sign 1 position
		number = number >>> 1;

		// equivalent of division of 2
		System.out
				.println("value of number after right shift with sign: (number>>>1) "
						+ number);
	}
}