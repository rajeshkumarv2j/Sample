package instanceBlock;

public class InstanceBlockExample {

	{
		int a=30;
		System.out.println(a);
		System.out.println(print());
	}
	
	int a = 30;
	
	int print(){
		return a;
	}
	
	public static void main(String[] args) {
		System.out.println(new InstanceBlockExample().print());
	}
} 
//30
//0
//30