package finalEx;

class A1 {

	int i=10;
	final char ch;
	A1() {
		i =0;
		ch = 'a';
	}
	A1(int x, char c){
		i = x;
		ch = c;
	}
	public static void main(String[] args) {
		A1 a = new A1();
		a.i=10;
//		a.ch = 'z';
		System.out.println(a.ch);
		a = new A1(1, 'z');
		System.out.println(a.ch);
	}
	
}
