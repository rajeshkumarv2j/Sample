package finalEx;
	public class AA{
		public void method(){
			System.out.println("A");
		}
	}
	final class BB extends AA{
		@Override
		public void method(){
			System.out.println("B");
		}
		public static void main(String[] args) {
			AA aa = new AA();
			aa.method();
			BB bb = new BB();
			bb.method();
			AA aa2 = new BB();
			aa2.method();
//			BB bb2 = new AA();
//			bb2.method();
		}
	}