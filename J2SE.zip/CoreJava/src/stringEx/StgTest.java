package stringEx;

public class StgTest {
	
	public static void main(String[] args) {
//		1)
		String s1 = "sdd";
		String s2 = new String("sdd");
		
		System.out.println(s1==s2);
		System.out.println(s1.equals(s2));
		
		String a1 = "sdd";
		String a2 = a1;
		System.out.println("................................."+(a1==a2));
		System.out.println(a1.equals(a2));
		
		
		String b1 = new String("sdd");
		String b2 = b1.toString();
		String b3 = b2.concat("as");
		System.out.println(b3);
		String b4 = new String("sddas");
		
		System.out.println(b1==b2);
		System.out.println(b1.equals(b2));
		System.out.println(b3 == b4);
		System.out.println(b3.equals(b4));
		
		System.out.println(b4.charAt(0));
		System.out.println(b4.compareTo("sdda"));
		System.out.println(b4.contains("sddas"));
		System.out.println(b4.getBytes());
		System.out.println(new String(b4.getBytes()));
		System.out.println(b4 == new String(b4.getBytes()));
		System.out.println(b4.equals(new String(b4.getBytes())));
		
		
		
	}
}
