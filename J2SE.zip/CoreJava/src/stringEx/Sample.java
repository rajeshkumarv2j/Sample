package stringEx;

public class Sample {
	public static void main(String[] args) {
//		+ operator concats two strings and resulted new string
		System.out.println("Main Started");
		System.out.println(""+2+2);
		System.out.println(2+2+"");
		String p = "abc";
		String q = p;
		System.out.println((p==q)+"sd"+p);
		System.out.println(q);
		System.out.println((p==q)+"sd"+p==q);
		System.out.println(p==q);
		System.out.println("Main Ended");
	}
}
