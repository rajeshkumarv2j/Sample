package stringEx;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;

public class StringExamples {
	public static void main(String[] args) {

		// The easiest way to create a Java String object is using a string
		// literal:
		String str1 = "I can't be changed once created!";

		
		// A Java string literal is a reference to a String object. Since a
		// String literal is a reference, it can be manipulated like any other
		// String reference. i.e. it can be used to invoke methods of String
		// class.
		int myLenght = "Hello world".length();
		


		// The Java language provides special support for the string
		// concatenation operator (+), which has been overloaded for Java
		// Strings objects. String concatenation is implemented through the
		// StringBuffer class and its append method.
		String finalString = "Hello" + "World";
		
		String finalString1 = new StringBuffer().append("Hello").append("World").toString();
//		Both are similar
		

		// The Java compiler optimizes handling of string literals. Only one
		// String object is shared by all strings having same character
		// sequence. Such strings are said to be interned, meaning that they
		// share a unique String object. The Java String class maintains a
		// private pool where such strings are interned.
		String str11="Hello";
		String str2="Hello";
		if(str11 == str2)
		        System.out.println("Equal");
		
		

		// Since the Java String objects are immutable, any operation performed
		// on one String reference will never have any effect on other
		// references denoting the same object.
		
		
		// Note: Invoking String constructor creates a new string object, means
		// it does not intern the String. Interned String object reference can
		// be obtained by using intern() method of the String class.
		
		

		// String also provides constructors that take byte and char array as an
		// argument and returns String object
		
		
		String str111="Hello";
		String str222="Hello";
		String str333=new String("Hello"); //Using constructor.
		 
		if(str111 == str222)
		        System.out.println("Equal 1");
		else
		        System.out.println("Not Equal 1");
		 
		if(str111 == str333)
		        System.out.println("Equal 2");
		else
		         System.out.println("I am constructed using constructor, hence not interned");
		 
		if( str111.equals(str333) )
		        System.out.println("Equal 3");
		else
		        System.out.println("Not Equal 3");
		
		
		
		// System.out.println(new X() + new X());	//It will error as there is no
													//defination for + operator overloading for user defined 
													//objects
		
		
//		How to Check if string contains valid number example..???
		String[] str = new String[]{"10.20", "123456", "12.invalid"};
        
        for(int i=0 ; i < str.length ; i ++)
        {
               
                if( str[i].indexOf(".") > 0 )
                {
               
                        try
                        {
                                /*
                                 * To check if the number is valid decimal number, use
                                 * double parseDouble(String str) method of
                                 * Double wrapper class.
                                 *
                                 * This method throws NumberFormatException if the
                                 * argument string is not a valid decimal number.
                                 */
                                Double.parseDouble(str[i]);
                                System.out.println(str[i] + " is a valid decimal number");
                        }
                        catch(NumberFormatException nme)
                        {
                                System.out.println(str[i] + " is not a valid decimal number");
                        }
                       
                }
                else
                {
                        try
                        {
                                /*
                                 * To check if the number is valid integer number, use
                                 * int parseInt(String str) method of
                                 * Integer wrapper class.
                                 *
                                 * This method throws NumberFormatException if the
                                 * argument string is not a valid integer number.
                                 */

                                Integer.parseInt(str[i]);
                                System.out.println(str[i] + " is valid integer number");
                        }
                        catch(NumberFormatException nme)
                        {
                                System.out.println(str[i] + " is not a valid integer number");
                        }
                }
        }
        
        
//      How to Convert String to Character Array Example..?
        String strOrig = "Hello World";
        //declare the char array
        char[] stringArray;
       
        //How to convert string into array using toCharArray() method of string class
        stringArray = strOrig.toCharArray();
       
        //display the array
        for(int index=0; index < stringArray.length; index++)
          System.out.println(stringArray[index]);
       
        
        
//      How to make Java ArrayList to String Array Example...???
        List<String> aListDays = new ArrayList<String>();
        aListDays.add("Sunday");
        aListDays.add("Monday");
        aListDays.add("Tuesday");
        
        String[] sArray = new String[aListDays.size()];
    	sArray = aListDays.toArray(sArray);
		
		System.out.println(sArray.length);
		for (String string : sArray) {
			System.out.println(string);
		}
		
//	OR
		
		Object[] objDays = aListDays.toArray();
        
        //Second Step: convert Object array to String array
        String[] strDays = Arrays.copyOf(objDays, objDays.length, String[].class);
       
        System.out.println(strDays.length);
		for (String string : strDays) {
			System.out.println(string);
		}
		
//		How to convert Char array to String ...??
		char[] charArray = new char[]{'J','a','v','a'};
        
        /*
         * To convert char array to String in Java, use
         * String(Char[] ch) constructor of Java String class.
         */
       
        System.out.println("Char array converted to String: " + new String(charArray));
        
        
//      How to convert Integer array to String ..???
        int[] intNumbers = new int[]{1, 2, 3, 4, 5};
        StringBuffer buffer = new StringBuffer();
		for (int i : intNumbers) {
			buffer.append(i).append(" ");
		}
		System.out.println(buffer.toString());
		
//		OR
		
		System.out.println(Arrays.toString(intNumbers));
		
		//you can use replaceAll method to replace brackets and commas
		System.out.println(Arrays.toString(intNumbers).replaceAll(", ", " ")
				.replace("[", "").replace("]", ""));
        
		
//		How to convert Date to String...??
		Date date = new Date();
		System.out.println(date.toString());
//		OR
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd-hh-mm-ss");
		System.out.println(dateFormat.format(date));
		
		
//		How to convert Java InputStream to String ..???
		try {
			InputStream is = new FileInputStream("D:/passwords.txt");
			InputStreamReader isr = new InputStreamReader(is);
			BufferedReader br = new BufferedReader(isr);
			StringBuffer sb = new StringBuffer();
			String line;
			try {
				while((line = br.readLine()) != null)
					sb.append(line);
			} catch (IOException e) {
				e.printStackTrace();
			}
			System.out.println(sb.toString());
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
//		How to reverse a String...???
		String s = "Actual";
		System.out.println(new StringBuffer(s).reverse());
		System.out.println(new StringBuilder(s).reverse());
		
//		How to reverse a string array..???
		String[] strs = new String[] { "Sunday", "Monday", "Tuesday",
				"Wednesday" };
		for (String string : strs) {
			System.out.println(string);
		}
		List<String> strings = Arrays.asList(strs);
		Collections.reverse(strings);
		String[] reversedStrs = new String[strings.size()]; 
		reversedStrs = strings.toArray(reversedStrs);
		for (String string : reversedStrs) {
			System.out.println(string);
		}
		
//		How to user indexOf and lastIndexOf ..???
		System.out.println("Hi, How are you..?".indexOf('H',1));
		System.out.println("Hi, How are you Hi..?".indexOf("Hi",1));
		System.out.println("Hi, How are you Hi..?".lastIndexOf("Hi"));
		
		
//		How to sort String Array...???
		
//		By default sorting is case sensitive
		String[] sts = new String[] { "Sunday", "monday", "Tuesday",
		"Wednesday" };
		for (String string : sts) {
			System.out.print(string);
		}
		System.out.println();
		Arrays.sort(sts);
		for (String string : sts) {
			System.out.print(string);
		}
		System.out.println();
		
		
//		How to Sort sorting with case in sensitive...???
		sts = new String[] { "Sunday", "monday", "Tuesday",
		"Wednesday" };
		for (String string : sts) {
			System.out.print(string);
		}
		System.out.println();
		Arrays.sort(sts, String.CASE_INSENSITIVE_ORDER);
		for (String string : sts) {
			System.out.print(string);
		}
		System.out.println();

//		How to convert Java Stack trace to String ...???
		try{
			Integer.parseInt("Hi How r u..???");
		}catch (Exception e) {
			try {
				/*PrintStream printStream = new PrintStream("D:/passwords.txt");
				e.printStackTrace(printStream);
				printStream.close();
				*/
				PrintWriter printWriter = new PrintWriter("D:/passwords.txt");
				e.printStackTrace(printWriter);
				printWriter.close();
				
				StringWriter stringWriter = new StringWriter();
				PrintWriter printWriter1 = new PrintWriter(stringWriter);
				e.printStackTrace(printWriter1);
				System.out.println(stringWriter.toString());
				
			} catch (FileNotFoundException e1) {
				e1.printStackTrace();
			}
		}
		
		
		
//		How to convert Java String Array To List ...???
		
		//create String array
        String[] numbers = new String[]{"one", "two", "three"};
       
        /*
         * To covert String array to java.util.List object, use
         * List asList(String[] strArray) method of Arrays class.
         */
       
        List<String> list = (List<String>) Arrays.asList(numbers);
       
//        list.add("");
        /****Exception in thread "main" java.lang.UnsupportedOperationException
        U acnt add any element to above list*/
        
        
        //display elements of List
        System.out.println("String array converted to List");
        for(int i=0; i < list.size(); i++){
                System.out.println(list.get(i));
        }
        
		List anotherList = new ArrayList();
        Collections.addAll(anotherList, numbers);
        anotherList.add("");
		System.out.println(anotherList);
		
		
		
//		How to convert Java String Array to String ....???
		String[] strArray =
            new String[]{"Java", "String", "Array", "To", "String", "Example"};
   
   
	    /*
	     * 1. Using Arrays.toString method
	     * This method returns string like [element1, element2..]
	     */
	   
	    str1 = Arrays.toString(strArray);               
	    //replace starting "[" and ending "]" and ","
	    str1 = str1.substring(1, str1.length()-1).replaceAll(",", "");
	   
	    System.out.println("String 1: " + str1);
	    /*
	     * 2. Using Arrays.asList method followed by toString.
	     * This method also returns string like [element1, element2..]
	     */
	   
	    str2 = Arrays.asList(strArray).toString();
	    //replace starting "[" and ending "]" and ","
	    str2 = str2.substring(1, str2.length()-1).replaceAll(",", "");
	    System.out.println("String 2: " + str2);
	   
	    /*
	     * PLEASE NOTE that if the any of the array elements contain ",", it will be
	     * replaced too. So above both methods does not work 100%.
	     */
	   
	    //3. Using StringBuffer.append method
	    StringBuffer sbf = new StringBuffer();
	   
	    if(strArray.length > 0){
	           
	            sbf.append(strArray[0]);
	            for(int i=1; i < strArray.length; i++){
	                    sbf.append(" ").append(strArray[i]);
	            }
	           
	    }
	    System.out.println("String 3: " + sbf.toString());
	    
	    
//    How to compare Strings..??
	    String strr = "Hello World";
	    String anotherString = "hello world";
	    Object objStr = strr;
	   
	    /* compare two strings, case sensitive */
	    System.out.println( strr.compareTo(anotherString) );
	    /* compare two strings, ignores character case  */
	    System.out.println( strr.compareToIgnoreCase(anotherString) );
	    /* compare string with object */
	    System.out.println( strr.compareTo((String) objStr) );
	   
	    
//    How to concat Strings...???
	    String str1111 = "Hello";
        String str22 = " World";
       
        //1. Using + operator
        String str3 = str1111 + str22;
        System.out.println("String concat using + operator : " + str3);
       
        /*
         * Internally str1111 + str 2 statement would be executed as,
         * new StringBuffer().append(str1111).append(str22)
         *
         * String concatenation using + operator is not recommended for large number
         * of concatenation as the performance is not good.
         */
       
        //2. Using String.concat() method
        String str4 = str1111.concat(str22);
        System.out.println("String concat using String concat method : " + str4);
       
        //3. Using StringBuffer.append method
        String str5 = new StringBuffer().append(str1111).append(str22).toString();         
        System.out.println("String concat using StringBuffer append method : " + str5);
        
//		How to use String contains...???
        str1111 = "Hello World";
        str22 = " World";
        boolean blnFound = str1111.contains(str22);
        System.out.println("String contains another string? : " + blnFound);
        
		
//		How to user replace in strings..???
        String strz="Replace Region";
        
        /*
        Replaces all occourances of given character with new one and returns new
        String object.
        */
        System.out.println( strz.replace( 'R','A' ) );
        
        /*
        Replaces only first occourances of given String with new one and
        returns new String object.
        */
        System.out.println( strz.replaceFirst("Re", "Ra") );
       
        /*
        Replaces all occourances of given String with new one and returns
        new String object.
        */
        System.out.println( strz.replaceAll("Re", "Ra") );
        
        
        
//        How to use split() in String...???
        
        /* String to split. */
        String strx = "one-two-three";
        String[] temp;
       
        /* delimiter */
        String delimiter = "-";
        /* given string will be split by the argument delimiter provided. */
        temp = strx.split(delimiter);
        /* print substrings */
        for(int i =0; i < temp.length ; i++)
          System.out.println(temp[i]);
       
        /*
        IMPORTANT : Some special characters need to be escaped while providing them as
        delimiters like "." and "|".
        */
       
        System.out.println("");
        strx = "one.two.three";
        delimiter = "\\.";
        temp = strx.split(delimiter);
        for(int i =0; i < temp.length ; i++)
          System.out.println(temp[i]);
       
        /*
        Using second argument in the String.split() method, we can control the maximum
        number of substrings generated by splitting a string.
        */
       
        System.out.println("");
        temp = strx.split(delimiter,2);
        for(int i =0; i < temp.length ; i++)
          System.out.println(temp[i]);
        
        
        
        
//        How to use trim() in String...???
        String strzx = "   String Trim Example   ";
        String strTrimmed = strzx.trim();
        System.out.println("New String is: " + strzx);
        System.out.println("New String is: " + strTrimmed);
        
//        How to use endsWith() in String...???
        String strOrig1 = "Hello World";
        
        if(strOrig1.endsWith("World")){
          System.out.println("String ends with World");
        }else{
          System.out.println("String does not end with World");
        }
        
        
//        How to check string is empty..???
        String s1 = "";
        String s2 = null;
        String s3 = "Hello World";
       
        /*
         * To check whether the String is empty or not, use
         * boolean isEmpty() method of Java String class.
         *
         * This method returns true if and only if string.length() is 0.
         */
       
        System.out.println("Is String 1 empty? :" + s1.isEmpty());
       
        //this will throw NullPointerException since str2 is null
//        System.out.println("Is String 2 empty? :" + s2.isEmpty());
       
        System.out.println("Is String 3 empty? :" + s3.isEmpty());
        
        
// How to use endsWith...??
        strOrig = "Hello World";
        if(strOrig.startsWith("Hello")){
            System.out.println("String starts with Hello");
          }else{
            System.out.println("String does not start with Hello");
          }
        
//        How to convert String ArrayList...???
        String strNumbers = "1,2,3,4,5";
        String[] ss = strNumbers.split(",");
        ArrayList<String> strings22 = new ArrayList<String>(Arrays.asList(ss));
        strings22.add("");
        System.out.println(strings22);
//        Direct Arrays.asList() list, we cant add and remove.. so only user constructor
        
        
//        How to convert String to InputStream...??
        InputStream is = new ByteArrayInputStream("Java convert String to InputStream Example".getBytes());
        
//        Lower Case : String strLower = str.toLowerCase();
//        Upper Case : String strLower = str.toUpperCase();
        
        
        
//        How to use valueOf()s in String...???
        int i=10;
        float f = 10.0f;
        long l = 10;
        double d=10.0d;
        char c='a';
        boolean b = true;
        Object o = new String("Hello World");
       
        /* convert int to String */
        System.out.println( String.valueOf(i) );
        /* convert float to String */
        System.out.println( String.valueOf(f) );
        /* convert long to String */
        System.out.println( String.valueOf(l) );
        /* convert double to String */
        System.out.println( String.valueOf(d) );
        /* convert char to String */
        System.out.println( String.valueOf(c) );
        /* convert boolean to String */
        System.out.println( String.valueOf(b) );
        /* convert Object to String */
        System.out.println( String.valueOf(o) );
        
//      How to use SubString..???
        String name="Hello World";
        
        /*
        This will print the substring starting from index 6
        */
        System.out.println(name.substring(6));
       
        /*
        This will print the substring starting from index 0 upto 4 not 5.
        IMPORTANT : Here startIndex is inclusive while endIndex is exclusive.
        */
        System.out.println(name.substring(0,5));
        
        
//How to remove a particular character from a string ?
        String sas = "this is Java";
        System.out.println(removeCharAt(sas, 3));
    
        
        
//        How to search,...??/
        
        strOrig.indexOf("Hello");
        
        
		System.out.println("End Of The Main");
	}
	public static String removeCharAt(String s, int pos) {
	      return s.substring(0, pos) + s.substring(pos + 1);
	   }
	
	
}
class X{
	
}
