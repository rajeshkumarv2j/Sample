package designpatterns.factory;

interface Currency {
	String getSymbol();
}