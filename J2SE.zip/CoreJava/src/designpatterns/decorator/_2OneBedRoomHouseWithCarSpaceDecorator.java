package designpatterns.decorator;

public class _2OneBedRoomHouseWithCarSpaceDecorator extends
		_2AbstractHouseDecorator {
	public _2HouseComponent house;

	public _2OneBedRoomHouseWithCarSpaceDecorator(_2HouseComponent house) {
		this.house = house;
	}

	@Override
	public String getHouseDescription() {
		return house.getHouseDescription() + " with one car space";
	}

	@Override
	public Double getPrice() {
		Double modifiedPrice = house.getPrice() + house.getPrice() * .10;
		return modifiedPrice;
	}

}
