package designpatterns.decorator;

public class _2OneBedRoomHouse extends _2HouseComponent {

	public _2OneBedRoomHouse() {
		description = "1 BHK";
	}

	@Override
	public Double getPrice() {
		return 300000.00;
	}

}
