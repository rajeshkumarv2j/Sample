package designpatterns.decorator;

//Decorator

public abstract class _1Decorator extends _1Currency{

 public abstract String getCurrencyDescription();

}
