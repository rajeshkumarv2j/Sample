package designpatterns.decorator;

//Another Concrete Component

public class _1Dollar extends _1Currency {
	double value;

	public _1Dollar() {
		description = "Dollar";
	}

	public double cost(double v) {
		value = v;
		return value;
	}

}
