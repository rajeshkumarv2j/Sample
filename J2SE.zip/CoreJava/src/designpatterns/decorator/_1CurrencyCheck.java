package designpatterns.decorator;

public class _1CurrencyCheck {

	public static void main(String[] args) {

		// without adding decorators

		_1Currency curr = new _1Dollar();

		System.out.println(curr.getCurrencyDescription() + " dollar. "
				+ curr.cost(2.0));

		// adding decorators

		_1Currency curr2 = new _1USDDecorator(new _1Dollar());

		System.out.println(curr2.getCurrencyDescription() + " dollar. "
				+ curr2.cost(4.0));

		_1Currency curr3 = new _1SGDDecorator(new _1Dollar());

		System.out.println(curr3.getCurrencyDescription() + " dollar. "
				+ curr3.cost(4.0));
	}
}