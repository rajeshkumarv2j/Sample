package designpatterns.decorator;

//Concrete Decorator

public class _1USDDecorator extends _1Decorator {

	_1Currency currency;

	public _1USDDecorator(_1Currency currency) {
		this.currency = currency;
	}

	@Override
	public String getCurrencyDescription() {
		return currency.getCurrencyDescription() + " ,its US Dollar";
	}

	@Override
	public double cost(double value) {
		return currency.cost(value);
	}

}
