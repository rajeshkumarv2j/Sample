package designpatterns.decorator;

public class _1Rupee extends _1Currency {
	double value;

	public _1Rupee() {
		description = "indian rupees";
	}

	public double cost(double v) {
		value = v;
		return value;
	}

}
