package designpatterns.decorator;

public abstract class _1Currency {
	String description = "Unknown currency";

	public String getCurrencyDescription() {
		return description;
	}

	public abstract double cost(double value);

}
