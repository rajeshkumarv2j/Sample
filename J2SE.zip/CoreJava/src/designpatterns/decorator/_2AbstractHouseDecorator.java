package designpatterns.decorator;

public abstract class _2AbstractHouseDecorator extends _2HouseComponent {

	public abstract String getHouseDescription();

}
