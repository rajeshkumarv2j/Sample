package collectionsEx;

import java.util.Comparator;
import java.util.HashMap;
import java.util.TreeMap;

public class SortByVal {

	public static void main(String[] args) {
		final HashMap<String, Double> map = new HashMap<String, Double>();
		map.put("B", 67.4);
		map.put("C", 67.4);
		map.put("A", 99.5);
		map.put("D", 67.3);

		System.out.println(map);

		// Below TreeMap will sort the above map based on Keys, Not values.
		TreeMap<String, Double> keysSortedTreeMap = new TreeMap<String, Double>(map);
		System.out.println(keysSortedTreeMap);

		
		// Below TreeMap will sort the above map based on values, Not Keys.
		TreeMap<String, Double> valuesSortedTreeMap = new TreeMap<String, Double>(
				new Comparator<String>() {
					@Override
					public int compare(String a, String b) {
						if (map.get(a) <= map.get(b)) {
							return -1;
						} else {
							return 1;
						} // returning 0 would merge keys
					}
				});
		valuesSortedTreeMap.putAll(map);
		System.out.println(valuesSortedTreeMap);
	}
}