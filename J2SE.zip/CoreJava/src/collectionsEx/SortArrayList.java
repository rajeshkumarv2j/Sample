package collectionsEx;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.TreeSet;


public class SortArrayList {

	/*public static void main(String[] args) {
		Integer[] integers = {1,54,222,4,7777,32,98,34,23,97,543,66};
		ArrayList<Integer> arrayList = new ArrayList<Integer>(Arrays.asList(integers));
		System.out.println(arrayList);
		Collections.sort(arrayList);
		System.out.println(arrayList);
	}*/
	public static void main(String[] args) {
		Integer[] integers = {1,54,222,4,7777,32,98,34,23,97,543,66};
		ArrayList<Integer> arrayList = new ArrayList<Integer>(Arrays.asList(integers));
		System.out.println(arrayList);
		TreeSet<Integer> treeSet = new TreeSet<Integer>(arrayList);
		System.out.println(treeSet);
	}
}