package collectionsEx;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.TreeMap;
import java.util.Vector;

public class LinkedListTest1 {

	private static final int NUMBER = 10000;

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		testAddEnd(new ArrayList());
		testAddEnd(new LinkedList());
		testAddEnd(new Vector());
		testAddMiddle(new ArrayList());
		testAddMiddle2(new LinkedList());
		testAddMiddle(new Vector());
		testAddStart(new ArrayList());
		testAddStart(new LinkedList());
		testAddStart(new Vector());
	}

	private static final void testAddEnd(List list) throws Exception {
		long time = System.currentTimeMillis();
		for (int i = 0; i < NUMBER; i++) {
			list.add(Integer.valueOf(i));
		}
		System.out.println("Add End (" + list.getClass().getName() + "): "
				+ (System.currentTimeMillis() - time));
		Thread.sleep(2000);
	}

	private static final void testAddMiddle(List list) throws Exception {
		long time = System.currentTimeMillis();
		for (int i = 0; i < NUMBER; i++) {
			if (list.size() > 0) {
				list.add(i / 2, Integer.valueOf(i));
			} else {
				list.add(Integer.valueOf(i));
			}
		}
		System.out.println("Add Middle (" + list.getClass().getName() + "): "
				+ (System.currentTimeMillis() - time));
		Thread.sleep(2000);
	}

	private static final void testAddMiddle2(LinkedList list) throws Exception {
		long time = System.currentTimeMillis();
		for (int i = 0; i < NUMBER; i++) {
			if (list.size() > 0) {
				list.add(i / 2, Integer.valueOf(i));
			} else {
				list.add(Integer.valueOf(i));
			}
		}
		System.out.println("Add Middle (" + list.getClass().getName() + "): "
				+ (System.currentTimeMillis() - time));
		Thread.sleep(2000);
	}

	private static final void testAddStart(List list) throws Exception {
		long time = System.currentTimeMillis();
		for (int i = 0; i < NUMBER; i++) {
			if (list.size() > 0) {
				list.add(0, Integer.valueOf(i));
			} else {
				list.add(Integer.valueOf(i));
			}
		}
		System.out.println("Add Start (" + list.getClass().getName() + "): "
				+ (System.currentTimeMillis() - time));
		Thread.sleep(2000);
	}
}