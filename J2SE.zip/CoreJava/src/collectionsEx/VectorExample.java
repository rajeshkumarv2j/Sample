package collectionsEx;

import java.util.Enumeration;
import java.util.Vector;

public class VectorExample {

	public static void main(String[] args) {
		Vector<String> strings = new Vector<String>();
		strings.add("a");
		strings.add("x");
		strings.add("s");
		strings.add("e");
		strings.add("f");
		strings.add("v");
		strings.add("d");
		strings.add("e");
		System.out.println(strings);
		Enumeration<String> en = strings.elements();
		while (en.hasMoreElements()) {
			String type = (String) en.nextElement();
			if(type.equals("e"))
				strings.remove(type);
		}
		System.out.println(strings);
	}

}