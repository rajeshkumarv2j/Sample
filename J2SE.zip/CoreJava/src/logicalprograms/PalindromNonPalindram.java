package logicalprograms;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class PalindromNonPalindram {

	/*public static void main(String[] args) {
		Integer[] integers = { 11, 22, 23, 232, 141, 515, 12, 43, 56, 83738,
				987656789 };
		List<Integer> palindromList = new ArrayList<Integer>();
		List<Integer> nonPalindromList = new ArrayList<Integer>();
		for (Integer integer : integers) {
			if (integer == Integer.parseInt(new StringBuffer("")
					.append(String.valueOf(integer)).reverse().toString())) {
				palindromList.add(integer);
			} else {
				nonPalindromList.add(integer);
			}
		}
		System.out.println("palindromList..."+palindromList);
		System.err.println("nonPalindromList..."+nonPalindromList);
		
	}*/
	
	public static void main(String[] args) {
		Integer[] integers = { 11, 22, 23, 232, 141, 515, 12, 43, 56, 83738,
				987656789 };
		List<Integer> palindromList = new ArrayList<Integer>();
		List<Integer> nonPalindromList = new ArrayList<Integer>();
		for (Integer integer : integers) {
			if (integer == reverse(integer)) {
				palindromList.add(integer);
			} else {
				nonPalindromList.add(integer);
			}
		}
		System.out.println("palindromList..."+palindromList);
		System.err.println("nonPalindromList..."+nonPalindromList);
	}

	private static int reverse(int number) {
		int reverse = 0;
		while (number != 0) {
			reverse = reverse * 10 + number % 10;
			number = number / 10;
		}
		return reverse;
	}
	
	void anotherWayOfPalindrum(){
		 InputStream is = System.in;
	        InputStreamReader isr = new InputStreamReader(is);
	        BufferedReader br = new BufferedReader(isr);
	        int number = 0;
	        try {
				number = Integer.parseInt(br.readLine());
			} catch (IOException e) {
				e.printStackTrace();
			}
	        
			int num = number;
			int reverseNo = 0;
		
			while(num > 0){
				reverseNo = reverseNo * 10 + num % 10;
				num = num / 10;
			}
			
			if(number == reverseNo)
	            System.out.println(number + " is a palindrome number");
		    else
		            System.out.println(number + " is not a palindrome number");
		    }
}