package innerclassEx;
//nestedClasslocalinnerclass
class Outer3 {

	int i;
	char ch;
	void set(){
		class Local{
			public void display(){
				System.out.println("LocalDisplay..."+i);
				System.out.println("LocalDisplay..."+ch);
			}
		}
		Local local = new Local();
		local.display();
	}

	public static void main(String[] args) {
		Outer3 outer = new Outer3();
		outer.set();
	}
}
