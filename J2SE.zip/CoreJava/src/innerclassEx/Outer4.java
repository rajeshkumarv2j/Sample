package innerclassEx;
//nestedClassStaticExm
 class Outer4 {
	 transient	static final int i =100;
	char ch;
	public static void main(String[] args) {
//		Outer.Inner in = new Outer.Inner(); //If Inner is static
//		Inner inner = new Inner(); //If Inner is static
//		Inner inner = new Outer().new Inner(); //If Inner is not static
	}
	void insideMethod(){
		Outer4 outer = new Outer4();
		Inner inner2 = outer.new Inner(); //This wont work for static Inner class
		Outer4.Inner in = new Outer4.Inner(); //If Inner is static
		Inner inner = new Inner(); //If Inner is static
		Inner inner1 = new Outer4().new Inner(); //This wont work for static Inner class
		Inner inner3 = this.new Inner();
	}
	class Inner{
		float f;
		int i;
		public Inner() {
			System.out.println(this);
		}
		void disp(){
			System.out.println(i);
		}
	}
}