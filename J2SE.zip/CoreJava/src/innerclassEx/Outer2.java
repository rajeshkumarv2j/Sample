package innerclassEx;

class Outer2 {

	Inner in = new Inner();
	int i;
	char ch;
	public Outer2() {
		System.out.println(this);
		System.out.println(in);
	}
	void set(){
//		in.disp();
		Inner inner = new Inner();
	}
	private class Inner{
		float f;
		int i;
		public Inner() {
			System.out.println(this);
			System.out.println(in);
		}
		void disp(){
			System.out.println(i);
			System.out.println(ch);
		}
	}
	public static void main(String[] args) {
		Outer2 outer = new Outer2();
		Inner in = outer.new Inner();
		in.disp();
	}
}
