package innerclassEx;
//nestedClassAnonyinnerclass
class Outer extends A{

	private int data = 30;
	int i;
	char ch;

	/**
	 * Member Inner Class
	 * @author Jatin
	 *
	 */
	protected class Inner {
		void msg() {
			System.out.println("data is " + data);
		}
	}
	 
	void set(){
		/**
		 * Local Inner class
		 * @author Jatin
		 *
		 */
		class Local{
			public void display(){
				System.out.println("LocalDisplay..."+i);
				System.out.println("LocalDisplay..."+ch);
			}
		}
		Local local = new Local();
		local.display();
		
		
		/**
		 * Anonymous Inner Class (A inner class without any name to it)
		 */
		new Object(){
			public String toString(){
				return "";
			}
		};
		new A(){
			public void display(){
				System.out.println("LocalDisplay..."+i);
				System.out.println("LocalDisplay..."+ch);
			}
		}.display();
	}

	
	
	public static void main(String[] args) {
		Outer outer = new Outer();
		outer.set();
	}
}
