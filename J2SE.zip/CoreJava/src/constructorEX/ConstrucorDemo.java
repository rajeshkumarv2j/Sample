package constructorEX;

public class ConstrucorDemo{

	public ConstrucorDemo() {
		System.out.println("Base constryuctor called");
//		System.out.println(this);
		this.a();
	}
	
	public static void main(String[] args) {
		ConstrucorDemo construcorDemo = new ConstrucorDemo();
		System.out.println("hi how r u ?");
	}
	
	public void a() {
		System.out.println("This is a method");
		this.b();
//		System.out.println(this);
	}
	
	public void b() {
		System.out.println("b method");
	}
}