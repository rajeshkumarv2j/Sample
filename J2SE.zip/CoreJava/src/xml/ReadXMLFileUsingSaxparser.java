package xml;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class ReadXMLFileUsingSaxparser{

       private static Account acct;
       private static String temp;
       private static ArrayList<Account> accList = new ArrayList<Account>();

       /** The main method sets things up for parsing */
       public static void main(String[] args){

		try {
			SAXParserFactory.newInstance().newSAXParser()
					.parse("bank.xml", new DefaultHandler() {
						public void startElement(String uri, String localName,
								String qName, Attributes attributes)
								throws SAXException {
							temp = "";
							if (qName.equalsIgnoreCase("Account")) {
								acct = new Account();
								acct.setType(attributes.getValue("type"));

							}
						}

						public void endElement(String uri, String localName,
								String qName) throws SAXException {
							if (qName.equalsIgnoreCase("Account")) {
								// add it to the list
								accList.add(acct);

							} else if (qName.equalsIgnoreCase("Name")) {
								acct.setName(temp);
							} else if (qName.equalsIgnoreCase("Id")) {
								acct.setId(Integer.parseInt(temp));
							} else if (qName.equalsIgnoreCase("Amt")) {
								acct.setAmt(Integer.parseInt(temp));
							}
						}

						public void characters(char[] ch, int start, int length)
								throws SAXException {
							temp = new String(ch, start, length);
						}
					});
		} catch (SAXException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		}
		System.out.println("No of  the accounts in bank '" + accList.size()  + "'.");
        Iterator<Account> it = accList.iterator();
        while (it.hasNext()) {
               System.out.println(it.next().toString());
        }
	}
}