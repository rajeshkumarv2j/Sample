package security;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.logging.Logger;

import org.apache.commons.codec.binary.Base32;

public class PasswordService {
	private static Logger logger = Logger.getAnonymousLogger();
	private static PasswordService passwordService;
	private static MessageDigest messageDigest;

	public static String encript(String password) {
		try {
			messageDigest = MessageDigest.getInstance("SHA");
		} catch (NoSuchAlgorithmException e) {
			logger.info(e.getMessage());
		}
		messageDigest.update(password.getBytes());
		byte[] bytes = messageDigest.digest();
		return new String(new Base32().encode(bytes));

	}

	private String decript(String password) {
		// try {
		// messageDigest = MessageDigest.getInstance("SHA");
		// } catch (NoSuchAlgorithmException e) {
		// e.printStackTrace();
		// }
		// messageDigest.update(password.getBytes());
		// byte[] bytes = messageDigest.digest();
		return new String(new Base32().decode(password.getBytes()));
	}

	private static PasswordService getInstance() {
		if (passwordService == null)
			synchronized (PasswordService.class) {
				if (passwordService == null)
					passwordService = new PasswordService();
			}
		return passwordService;
	}

	public static void main1(String[] args) {
		System.out
				.println(PasswordService.getInstance().encript("Rajeshkumar"));
		// ZUKY23KRLJFPCUBTTE6DOVZJHUB2NZBC
		System.out.println(PasswordService.getInstance().decript(
				"ZUKY23KRLJFPCUBTTE6DOVZJHUB2NZBC"));
	}

	public static void main(String[] args) {
		String toEncode = "Rajeshkumar";

		Base32 base32 = new Base32();
		String encoded = new String(base32.encode(toEncode.getBytes()));

		System.out.println(encoded);

		String decoded = new String(base32.decode(encoded.getBytes()));

		System.out.println(decoded);
	}
}
