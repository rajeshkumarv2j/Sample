package io;

import java.io.*;

public class CopyFile {
	public static void main(String args[]) {
		FileInputStream in = null;
		FileOutputStream out = null;

		int c;
		try {
			File file = new File("input.txt");
			
			in = new FileInputStream("input.txt");
			out = new FileOutputStream("output.txt");
			while ((c = in.read()) != -1) {
				out.write(c);
			}
			if (in != null) {
				in.close();
			}
			if (out != null) {
				out.close();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}