package mat.outoffmemoryanalyer;

import java.util.ArrayList;
import java.util.List;

public class Main {

  
/**
   * @param args
   */

  public static void main(String[] args) {
    List<String> list = new ArrayList<String>();
    while (1<2){
      list.add("OutOfMemoryError soon");
    }

  }

} 