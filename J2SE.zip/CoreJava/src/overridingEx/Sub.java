package overridingEx;

import java.sql.SQLException;

public class Sub extends Super{

	int a=10;
	
	@Override
	public void c() {
		String s = "sdgsd";
//		s.to
	}
	
	public Sub() {
		System.out.println(this.a);
		
		System.out.println("a..."+a);
		System.out.println("super.a..."+super.a);
		a = addTenMore(a);
		super.a = addTenMore(super.a);
		System.out.println("a..."+a);
		System.out.println("super.a..."+super.a);
	}
	

	private int addTenMore(int a2) {
		a2 = a2+10;
		return a2;
	}
	

	public static void main(String[] args) throws SQLException {
		System.out.println("main start");
//		new Sub();
		/*Super super1 = new Sub();
		super1.c();*/
		Super super1 = new Sub();
		System.out.println("super1.a........."+super1.a);
		System.out.println("new Sub().a......."+new Sub().a);
		System.out.println("main end");
	}
	
}