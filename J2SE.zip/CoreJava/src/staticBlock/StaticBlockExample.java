package staticBlock;

public class StaticBlockExample {
	static int a = 30;
	static {
		int a=30;
		System.out.println(a);
		System.out.println(print());
	}
	static int b = 30;
	static {
		int a=30;
		System.out.println(a);
		System.out.println(print1());
	}
	static int print(){
		return a;
	}
	static int print1(){
		return b;
	}
	public static void main(String[] args) throws ClassNotFoundException {
		Class.forName("staticBlock.StaticBlockExample");
	}
} 
/*30
30
30
30*/