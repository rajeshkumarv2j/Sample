package objectclassmethods;

import java.util.ArrayList;
import java.util.HashSet;

public class Test1 {

	private int i;
	private String name;
	
	

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + i;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}


	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Test1 other = (Test1) obj;
		if (i != other.i)
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}

	public static void main(String[] args) {
		Test1 test1 = new Test1();
		test1.i =10;
		
		Test1 test2 = new Test1();
		test2.i =10;
		
		System.out.println(test1.equals(test2));
		
		/*HashSet<Test1> arrayList = new HashSet<Test1>();
		arrayList.add(test1);
		System.out.println(arrayList);
		System.out.println(arrayList.contains(test2));*/
		

		// while adding elements in to hashset, Hash Set checks for hashCode() first. 
		// If it returns true (nothing but both hashcode is same),then it will check for equals method,
//		If equlas also returns true, then it will omit that element
		
		HashSet<Test1> arrayList = new HashSet<Test1>();
		arrayList.add(test1);
		arrayList.add(test2);
		
		System.out.println(arrayList);
		
//		System.out.println(arrayList.contains(test2));
	}
}