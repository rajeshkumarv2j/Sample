package objectclassmethods;

public class Test {
	public static void main(String[] args) {
		EqualsHashCodeClass class1 = new EqualsHashCodeClass();
//		class1.setId(12l);
		EqualsHashCodeClass class2 = new EqualsHashCodeClass();
//		class2.setId(11l);
		System.out.println(class1.equals(class2));
		System.out.println(class2.equals(class1));
		System.out.println(class1.hashCode());
		System.out.println(class2.hashCode());
	}
}