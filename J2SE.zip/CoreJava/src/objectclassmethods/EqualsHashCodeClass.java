package objectclassmethods;

public class EqualsHashCodeClass {
	private Long id;
	private String name;
	private Object object;

	public EqualsHashCodeClass(Long id, String name, Object object) {
		super();
		this.id = id;
		this.name = name;
		this.object = object;
	}

	public EqualsHashCodeClass() {
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Object getObject() {
		return object;
	}

	public void setObject(Object object) {
		this.object = object;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((object == null) ? 0 : object.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		
		if (obj == null || (getClass() != obj.getClass()))
			return false;
		
		EqualsHashCodeClass other = (EqualsHashCodeClass) obj;
		
		return id == other.id
				&& ((name == other.name) || (name != null && name
						.equals(other.name)))
				&& ((object == other.object) || (object != null && object
						.equals(other.object)));
	}

	@Override
	public String toString() {
		return "DTOClass [id=" + id + ", name=" + name + ", object=" + object
				+ "]";
	}
	
	

}