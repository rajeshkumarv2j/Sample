package foreachEx;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

/**
  * Java class to demonstrate inner working of for-each loop in Java
  * @author Javin Paul
  **/
public class ForEachTest2 {  
   
    public static void main(String args[]){
        Collection<String> list = new ArrayList<String>();
        list.add("Android");
        list.add("iPhone");
        list.add("Windows Mobile");
       
        // Which Code will throw ConcurrentModificationException, both, 
        // none or one of them
       
        // example 1        
        Iterator<String> itr = list.iterator();
        while(itr.hasNext()){
            String lang = itr.next();
            list.remove(lang);
//            java.util.ConcurrentModificationException
        }
       
         // example 2
        for(String language: list){
            list.remove(language);
//            java.util.ConcurrentModificationException
        }
    }
}


