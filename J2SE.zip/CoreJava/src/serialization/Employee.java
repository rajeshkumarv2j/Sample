package serialization;
import java.io.Serializable;
 
public class Employee extends SuperEmployee {
	public String firstName;
	private static final long serialVersionUID = 5462223600l;
}
 
@SuppressWarnings("serial")
class SuperEmployee implements Serializable{
	
//	private static final long serialVersionUID = -853825634037570915L;
	public String lastName;
	public final String lastName1="rajesh";
	public final String lastName2="Kumar";
	static String companyName = "TATA";
	transient final String address = "DEL123";
	static transient String companyCEO = "Jayshree";
}