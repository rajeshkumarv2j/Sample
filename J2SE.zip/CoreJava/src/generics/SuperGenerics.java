package generics;

import java.util.ArrayList;
import java.util.List;

public class SuperGenerics {

	@SuppressWarnings("unchecked")
	<E> List<? extends E> list1(){
		List<E> emps=null;
		emps = (List<E>) new ArrayList<Person>();
		return emps;
	}
	

	public static void main(String[] args) {
		SuperGenerics generics = new SuperGenerics();
		System.out.println(generics.list1());
	}

	class Person {
		String name;
		String address;

		public Person() {
		}

		public Person(String name, String address) {
			super();
			this.name = name;
			this.address = address;
		}

	}

	class Student extends Person {
		public Student(String name, String address) {
			super(name, address);
		}

		public Student() {
		}

		int cId = 1;
		String cName = "xyz";
	}

	class Emp extends Person {
		public Emp(String name, String address) {
			super(name, address);
		}

		public Emp() {
		}

		int id = 1;
		String name = "jatin";
	}
}
