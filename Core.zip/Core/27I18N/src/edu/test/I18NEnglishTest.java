package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.util.Locale;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/*
*
* @author Varma 
*
*/
public class I18NEnglishTest {
	private static ApplicationContext context = new ClassPathXmlApplicationContext(
			"spring-config.xml");

	public static void main(String[] args) {
		// English....
		Locale english = Locale.ENGLISH;
		// Locale english = new Locale("en");
		System.out.println(".StudentNo."
				+ context.getMessage("studentNo", null, english));

	}
}
