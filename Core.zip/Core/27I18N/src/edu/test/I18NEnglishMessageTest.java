package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.util.Locale;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/*
*
* @author Varma 
*
*/
public class I18NEnglishMessageTest {
	private static ApplicationContext context = new ClassPathXmlApplicationContext(
			"spring-config.xml");

	public static void main(String[] args) {
		Locale english = Locale.ENGLISH;
		System.out.println(".StudentName."
				+ context.getMessage("studentName", new Object[] { "N@It1",
						"N@It2" }, english));
	}
}
