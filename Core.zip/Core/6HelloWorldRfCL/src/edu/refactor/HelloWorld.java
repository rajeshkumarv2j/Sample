package edu.refactor;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

/*
*
* @author Varma 
*
*/
public class HelloWorld {
	public static void main(String[] args) {
		System.out.println(".HelloWorld.");
	}
}
