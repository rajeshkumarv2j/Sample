package edu.service;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import edu.dao.Dao;

/*
*
* @author Varma 
*
*/
public class ServiceOne {
	private Dao dao;

	public ServiceOne(Dao dao) {
		this.dao = dao;
	}

	public void serviceMethod() {
		System.out.println(".ServiceOne.serviceMethod().START");
		dao.daoMethod();
		System.out.println(".ServiceOne.serviceMethod().END");
	}

}
