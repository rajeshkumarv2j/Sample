package edu.service;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import edu.dao.Dao;

/*
*
* @author Varma 
*
*/
public class Service {
	private Dao dao;

	public Service(Dao dao) {
		this.dao = dao;
		System.out.println("Service.Service(Dao dao)-Constructor");
	}

	public void setDaoOne(Dao dao) {
		this.dao = dao;
		System.out.println("Service.setDaoOne(Dao dao)");
	}

	public void serviceMethod() {
		System.out.println(".Service.serviceMethod().START");
		dao.daoMethod();
		System.out.println(".Service.serviceMethod().END");
	}

}
