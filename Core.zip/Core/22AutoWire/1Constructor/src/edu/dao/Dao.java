package edu.dao;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

/*
*
* @author Varma 
*
*/
public class Dao {

	public void daoMethod() {
		System.out.println(".Dao.daoMethod()");
	}
}
