package edu.main;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import edu.service.Service;

/*
*
* @author Varma 
*
*/
public class SpringServiceDaoTest {
	private static ApplicationContext context = new ClassPathXmlApplicationContext(
			"spring-config.xml");

	public static void main(String[] args) {
		Service service = (Service) context.getBean("service");
		System.out.println(".CoreServiceDaoTest.main().START");
		service.serviceMethod();
		System.out.println(".CoreServiceDaoTest.main().END");
	}
}
