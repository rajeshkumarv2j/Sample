package edu.main;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/*
*
* @author Varma 
*
*/
public class ApplicationContextTest {
	private static ApplicationContext context = new ClassPathXmlApplicationContext(
			"spring-config.xml");

	public static void main(String[] args) {
		// Check the Console Whether Bean objects are created or not
		// If we read the configuration file, It creates bean object
		// The objects are created while reading the configuration file
		// and It provides I18N and event Handling, So it's heavy weight
	}
}
