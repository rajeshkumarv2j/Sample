package edu.main;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

/*
*
* @author Varma 
*
*/
public class BeanFactoryTest {
	private static BeanFactory factory = new XmlBeanFactory(
			new ClassPathResource("spring-config.xml"));

	public static void main(String[] args) {
		// Check the Console Whether Bean objects are created or not
		// If we call call factory.getBean(), It creates bean object
	}
}
