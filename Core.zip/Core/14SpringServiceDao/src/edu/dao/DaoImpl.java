package edu.dao;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

/*
*
* @author Varma 
*
*/
public class DaoImpl implements Dao {
	public void daoMethod() {
		System.out.println(".DaoImpl.daoMethod().Persistence.Logic");
	}
}
