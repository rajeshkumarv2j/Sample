package edu.service;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import edu.dao.Dao;

/*
*
* @author Varma 
*
*/
public class ServiceImpl implements Service {
	private Dao dao;

	public ServiceImpl() {
	}

	public ServiceImpl(Dao dao) {
		System.out.println(".ServiceImpl.ServiceImpl(Dao dao)");
		this.dao = dao;
	}

	public void setDao(Dao dao) {
		System.out.println(".ServiceImpl.setDao(Dao dao)");
		this.dao = dao;
	}

	public void serviceMethod() {
		System.out.println(".ServiceImpl.serviceMethod().START");
		dao.daoMethod();
		System.out.println(".ServiceImpl.serviceMethod().END");
	}

}
