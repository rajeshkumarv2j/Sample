package edu.core;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

// StudentThread - B
//Runnable & Thread - A
/*
*
* @author Varma 
*
*/
class StudentThread extends Thread {

	public void run() {
		System.out.println(".StudentThread.run()");
	}
}

public class ThreadTest {

	public static void main(String[] args) throws Exception {
		// Dev
		// Thread.start(); start is a native Method and it's going to call
		// StudentThread class run Method.
		// JVM
		// A a = new B();
		Runnable runnable = (Runnable) Class.forName("edu.core.StudentThread")
				.newInstance();
		// a.x();
		runnable.run();
	}
}
