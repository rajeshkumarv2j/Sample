package edu.servlet;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

/*
*
* @author Varma 
*
*/
interface Servlet {
	public abstract void service(StringBuffer serlvetReq);
}

abstract class GenericSerlvet implements Servlet {
	public abstract void service(StringBuffer serlvetReq);
}

class HttpServlet extends GenericSerlvet {
	public void doGet() {
		System.out.println(".HttpServlet.doGet()");
	}

	protected void service(String httpSerlvetReq) {
		System.out.println("PROTECTED.HttpServlet.service(httpSerlvetReq)");
		// String method = request.getMethod();
		// if("GET".equalsIgnoreCase(method))
		doGet();
	}

	// serlvetReq - points To -> HttpServletReq/Res Object
	public void service(StringBuffer serlvetReq) {
		String httpSerlvetReq = (String) serlvetReq.toString();
		System.out.println("PUBLIC.HttpServlet.service(serlvetReq)");
		service(httpSerlvetReq);
	}
}

class EmployeeServlet extends HttpServlet {
	public void service(StringBuffer serlvetReq) {
		System.out.println("PUBLIC.EmployeeServlet.service(serlvetReq)");
		super.service(serlvetReq);
	}

	public void doGet() {
		System.out.println(".EmployeeServlet.doGet()");
	}
}

public class ServletLifeCycle {
	public static void main(String[] args) throws Exception {
		Servlet servlet = (Servlet) Class
				.forName("edu.servlet.EmployeeServlet").newInstance();
		// Call Public Service and Pass HttpServletReq Object
		servlet.service(new StringBuffer());
	}
}
