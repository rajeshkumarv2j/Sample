package edu.jdbc;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.sql.Connection;
import java.sql.DriverManager;

/*
*
* @author Varma 
*
*/
public class PolyJdbcTest {

	public static void main(String[] args) throws Exception {
		// Class.forName - Loading & Registering [Wrong]
		// Class.forName - Just To load Class
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection connection = DriverManager.getConnection("");
		// connection - points To ->
		// Type I - sun.jdbc.odbc.JdbcOdbcConnection
		// Type IV - oracle.jdbc.driver.OracleConnection
		// Connection - A
		// JdbcOdbcConnection / OracleConnection - B
		// a.x();
		connection.createStatement();
	}
}

// OracleDriver - Internal Code
// public class OracleDriver implements Driver {
// static {
// DriverManager.registerDriver(--);
// }
// }
