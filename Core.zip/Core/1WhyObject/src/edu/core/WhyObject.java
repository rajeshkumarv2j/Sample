package edu.core;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

/*
*
* @author Varma 
*
*/
public class WhyObject {
	public static Long whyObjectMethod1(Long studentNo) {
		return studentNo;
	}

	public static String whyObjectMethod2(String studentName) {
		return studentName;
	}

	// ArrayList add/get methods..
	// Object Ref - points to -> Long/String Objects
	public static Object whyObjectMethod(Object object) {
		return object;
	}

	public static void main(String[] args) {
		Long studentNo = whyObjectMethod1(new Long(1));
		String studentName = whyObjectMethod2("N@It");
		studentNo = (Long) whyObjectMethod(new Long(1));
		Object object = whyObjectMethod("N@It");
		// object - points to -> String object
		System.out.println(".Class Name." + object.getClass().getName());
		// System.out.println(".Student Name length()." + object.length());
		studentName = (String) object;
		System.out.println(".Student Name length()." + studentName.length());
	}
}
