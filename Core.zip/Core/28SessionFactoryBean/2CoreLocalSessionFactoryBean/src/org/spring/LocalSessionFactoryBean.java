package org.spring;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.sql.SQLException;
import java.util.Properties;

import javax.sql.DataSource;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.springframework.beans.factory.InitializingBean;

import edu.test.CoreLocalSessionFactoryBeanTest;

/*
*
* @author Varma 
*
*/
public class LocalSessionFactoryBean implements InitializingBean {
	
	private Properties hibernateProperties;

	private String mappingResources;

	private DataSource dataSource;
	
	private SessionFactory sessionFactory;

	public void setHibernateProperties(Properties hibernateProperties) {
		this.hibernateProperties = hibernateProperties;
	}

	public void setMappingResources(String mappingResources) {
		this.mappingResources = mappingResources;
	}

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}
	
	public void afterPropertiesSet() throws Exception {
		Configuration configuration = new Configuration();
		configuration.setProperties(hibernateProperties);

		configuration.addInputStream(CoreLocalSessionFactoryBeanTest.class
				.getClassLoader().getResourceAsStream(mappingResources));
		sessionFactory = configuration.buildSessionFactory();
	}

	public Session openSession() throws SQLException {
		return sessionFactory.openSession(dataSource.getConnection());
	}
}
