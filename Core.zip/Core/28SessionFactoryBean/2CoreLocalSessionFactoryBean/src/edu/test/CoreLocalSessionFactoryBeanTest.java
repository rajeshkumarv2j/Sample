package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.spring.LocalSessionFactoryBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import edu.model.Student;

/*
*
* @author Varma 
*
*/
public class CoreLocalSessionFactoryBeanTest {
	private static ApplicationContext context = new ClassPathXmlApplicationContext(
			"spring-config.xml");

	public static void main(String[] args) throws Exception {
		LocalSessionFactoryBean localSessionFactoryBean = (LocalSessionFactoryBean) context
				.getBean("sessionFactory");

		Session session = localSessionFactoryBean.openSession();
		Transaction transaction = session.beginTransaction();

		Student student = new Student();
		student.setStudentName("N@It");
		try {
			session.save(student);
			transaction.commit();
		} catch (HibernateException e) {
			transaction.rollback();
			System.out.println(".." + e.getMessage());
		}

	}
}
