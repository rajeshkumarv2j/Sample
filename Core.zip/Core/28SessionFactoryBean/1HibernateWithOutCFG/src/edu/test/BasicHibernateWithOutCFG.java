package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import edu.model.Student;

/*
*
* @author Varma 
*
*/
public class BasicHibernateWithOutCFG {

	public static void main(String[] args) throws Exception {
		Configuration configuration = new Configuration();
		// Step 1.1
		Properties hibernateProperties = new Properties();
		hibernateProperties.setProperty("hibernate.dialect",
				"org.hibernate.dialect.Oracle9Dialect");
		hibernateProperties.setProperty("hibernate.show_sql", "true");
		configuration.setProperties(hibernateProperties);
		// Step 1.2
		configuration.addInputStream(BasicHibernateWithOutCFG.class
				.getClassLoader().getResourceAsStream(
						"edu/mappings/student.hbm.xml"));
		// Step 1.3
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		// Step 2.1
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection connection = DriverManager
				.getConnection("jdbc:oracle:thin:@localhost:1521:STUDEV1",
						"SYSTEM", "MANAGER");
		// Step 2.2
		Session session = sessionFactory.openSession(connection);
		// Step 3
		Transaction transaction = session.beginTransaction();
		Student student = new Student();
		student.setStudentName("N@It");
		try {
			session.save(student);
			transaction.commit();
		} catch (HibernateException e) {
			transaction.rollback();
		}
	}
}
