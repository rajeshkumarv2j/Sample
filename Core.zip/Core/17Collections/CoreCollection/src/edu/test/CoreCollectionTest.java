package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.util.ArrayList;
import java.util.List;

import edu.model.Student;

/*
*
* @author Varma 
*
*/
public class CoreCollectionTest {
	public static void main(String[] args) {
		List studentList = new ArrayList();
		studentList.add("8");
		studentList.add("N@It");
		Student student = new Student();
		student.setStudentList(studentList);
	}
}
