package edu.model;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.util.Set;

/*
*
* @author Varma 
*
*/
public class Student {
	private Set studentSet;
	private String[] stringArray;


	public Set getStudentSet() {
		return studentSet;
	}

	public void setStudentSet(Set studentSet) {
		this.studentSet = studentSet;
	}

	public String[] getStringArray() {
		return stringArray;
	}

	public void setStringArray(String[] stringArray) {
		this.stringArray = stringArray;
	}

}
