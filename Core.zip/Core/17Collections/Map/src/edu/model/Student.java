package edu.model;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.util.Map;

/*
*
* @author Varma 
*
*/
public class Student {
	private Map studentMap;

	public Map getStudentMap() {
		return studentMap;
	}

	public void setStudentMap(Map studentMap) {
		this.studentMap = studentMap;
	}

}
