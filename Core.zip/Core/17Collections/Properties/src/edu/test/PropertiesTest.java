package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.util.Properties;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import edu.model.Student;

/*
*
* @author Varma 
*
*/
public class PropertiesTest {
	private static ApplicationContext context = new ClassPathXmlApplicationContext(
			"spring-config.xml");

	public static void main(String[] args) {
		Student student = (Student) context.getBean("student");
		Properties properties = student.getProperties();
		System.out.println(".StudentNo." + properties.getProperty("studentNo"));
		System.out.println(".StudentName."
				+ properties.getProperty("studentName"));
	}
}
