package edu.service;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import edu.dao.Dao;

/*
*
* @author Varma 
*
*/
public class Service {
	private Dao dao;

	public void setDao(Dao dao) {
		this.dao = dao;
	}

	public void serviceMethod() {
		dao.daoMethod();
		System.out.println(".Dao Ref :" + dao);
	}

}
