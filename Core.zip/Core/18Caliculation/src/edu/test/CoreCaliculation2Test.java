package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import org.spring.CaliculationTwo;

/*
*
* @author Varma 
*
*/
public class CoreCaliculation2Test {

	public static void main(String[] args) throws Exception {
		CaliculationTwo caliculation = new CaliculationTwo(8);
		caliculation.setB(4);
		int sum = caliculation.sum();
		int sub = caliculation.sub();
		System.out.println(".sum." + sum);
		System.out.println(".sub." + sub);
	}

}
