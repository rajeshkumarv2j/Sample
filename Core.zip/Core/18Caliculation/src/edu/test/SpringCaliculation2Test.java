package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import org.spring.CaliculationTwo;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/*
*
* @author Varma 
*
*/
public class SpringCaliculation2Test {
	private static ApplicationContext context = new ClassPathXmlApplicationContext(
			"spring-config.xml");

	public static void main(String[] args) {

		CaliculationTwo caliculation = (CaliculationTwo) context
				.getBean("caliculationTwo");
		int sum = caliculation.sum();
		int sub = caliculation.sub();
		System.out.println(".sum." + sum);
		System.out.println(".sub." + sub);
	}
}
