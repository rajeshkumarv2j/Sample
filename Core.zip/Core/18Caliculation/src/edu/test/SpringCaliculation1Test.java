package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import org.spring.CaliculationOne;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/*
*
* @author Varma 
*
*/
public class SpringCaliculation1Test {
	private static ApplicationContext context = new ClassPathXmlApplicationContext(
			"spring-config.xml");

	public static void main(String[] args) {

		CaliculationOne caliculation = (CaliculationOne) context
				.getBean("caliculationOne");
		int sum = caliculation.sum(4, 4);
		int sub = caliculation.sub(4, 4);
		System.out.println(".sum." + sum);
		System.out.println(".sub." + sub);
	}
}
