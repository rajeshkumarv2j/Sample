package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import org.spring.CaliculationOne;

/*
*
* @author Varma 
*
*/
public class CoreCaliculation1Test {

	public static void main(String[] args) throws Exception {
		CaliculationOne caliculation = new CaliculationOne();
		int sum = caliculation.sum(4, 4);
		int sub = caliculation.sub(4, 4);
		System.out.println(".sum." + sum);
		System.out.println(".sub." + sub);
	}

}
