package org.spring;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

/*
*
* @author Varma 
*
*/
public class CaliculationTwo {
	private int a;
	private int b;

	public CaliculationTwo(int a) {
		this.a = a;
	}

	public int getB() {
		return b;
	}

	public void setB(int b) {
		this.b = b;
	}

	public int sum() {
		return a + b;
	}

	public int sub() {
		return a - b;
	}
}
