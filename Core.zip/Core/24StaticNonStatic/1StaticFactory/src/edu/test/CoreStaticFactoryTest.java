package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import edu.model.Student;

/*
*
* @author Varma 
*
*/
public class CoreStaticFactoryTest {

	public static void main(String[] args) {
		String studentName = Student.getStudentName();
		System.out.println(".StudentName." + studentName);
	}
}
