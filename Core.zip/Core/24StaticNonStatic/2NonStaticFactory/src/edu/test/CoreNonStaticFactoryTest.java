package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import edu.model.Student;

/*
*
* @author Varma 
*
*/
public class CoreNonStaticFactoryTest {
	public static void main(String[] args) {
		Student student = new Student();
		String studentName = student.getStudentName();
		System.out.println(".StudentName." + studentName);
	}
}
