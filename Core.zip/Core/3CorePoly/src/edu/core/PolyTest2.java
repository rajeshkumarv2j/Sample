package edu.core;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.io.IOException;
import java.util.Properties;

/*
*
* @author Varma 
*
*/
abstract class A2 {
	public void x() {
		System.out.println(".A.x()");
		y();
	}

	public abstract void y();

	// public void y() { }
	public void z() {
		System.out.println(".A.z()");
	}
}

class B2 extends A2 {
	public void y() {
		System.out.println(".B.y()");
		z();
	}
}

class C2 extends A2 {
	public void y() {
		System.out.println(".C.y()");
		z();
	}
}

public class PolyTest2 {
	private static Properties properties = new Properties();
	static {
		try {
			properties.load(PolyTest2.class.getClassLoader()
					.getResourceAsStream("poly.properties"));
		} catch (IOException e) {
			throw new InstantiationError(e.getMessage());
		}
	}

	public static void main(String[] args) throws Exception {
		String className = properties.getProperty("className");
		A2 a = (A2) Class.forName(className).newInstance();
		a.x();
	}
}
