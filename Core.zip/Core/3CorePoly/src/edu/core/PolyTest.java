package edu.core;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

/*
*
* @author Varma 
*
*/
class A {
	public void x() {
		System.out.println(".A.x()");
	}
}

class B extends A {
	public void x() {
		System.out.println(".B.x()");
	}
}

public class PolyTest {
	public static void main(String[] args) {
		// Technically Correct
		// Understanding wise it's wrong
		A a = new B();
		a.x();
		B b = new B();
		// Difference between calling a.y() and b.y()
		a.x();
		b.x();
	}
}
