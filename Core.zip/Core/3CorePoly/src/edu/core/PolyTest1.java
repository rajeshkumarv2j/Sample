package edu.core;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

/*
*
* @author Varma 
*
*/
abstract class A1 {
	public void x() {
		System.out.println(".A.x()");
		y();
	}

	public abstract void y();

	// public void y() { }
	public void z() {
		System.out.println(".A.z()");
	}
}

class B1 extends A1 {
	public void y() {
		System.out.println(".B.y()");
		z();
	}
}

public class PolyTest1 {
	public static void main(String[] args) {
		// Technically Correct
		// Understanding wise it's wrong
		A1 a = new B1();
		a.x();

		// B1 b = new B1();
		// Difference between calling a.y() and b.y()
		// a.y();
		// b.y();
	}
}
