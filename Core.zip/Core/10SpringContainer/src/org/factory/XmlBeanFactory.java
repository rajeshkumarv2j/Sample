package org.factory;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/*
*
* @author Varma 
*
*/
public class XmlBeanFactory implements BeanFactory {
	private static String className;
	private static Map singleTonMap = new HashMap();
	static {
		Properties properties = new Properties();
		String singleTon = null;
		String id = null;
		try {
			properties.load(XmlBeanFactory.class.getClassLoader()
					.getResourceAsStream("spring-config.properties"));
			className = properties.getProperty("className");
			id = properties.getProperty("id");
			singleTon = properties.getProperty("singleTon");
			if ("true".equals(singleTon)) {
				Object object = Class.forName(className).newInstance();
				singleTonMap.put(id, object);
			}
		} catch (Exception e) {
		}
	}

	public Object getBean(String key) {
		Object object = singleTonMap.get(key);
		if (object != null) {
			return object;
		}
		try {
			object = Class.forName(className).newInstance();
		} catch (Exception e) {
		}
		return object;
	}
}
