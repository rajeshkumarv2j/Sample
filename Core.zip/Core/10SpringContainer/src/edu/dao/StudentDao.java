package edu.dao;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

/*
*
* @author Varma 
*
*/
public interface StudentDao {
	public void daoMethod();
}
