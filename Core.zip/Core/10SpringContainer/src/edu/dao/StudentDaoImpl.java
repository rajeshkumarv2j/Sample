package edu.dao;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

/*
*
* @author Varma 
*
*/
public class StudentDaoImpl implements StudentDao {

	public void daoMethod() {
		System.out.println(".StudentDaoImpl.daoMethod()");
	}

}
