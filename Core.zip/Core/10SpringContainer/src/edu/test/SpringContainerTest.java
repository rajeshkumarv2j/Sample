package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import org.factory.BeanFactory;
import org.factory.XmlBeanFactory;

import edu.dao.StudentDao;

/*
*
* @author Varma 
*
*/
public class SpringContainerTest {
	private static BeanFactory factory = new XmlBeanFactory();

	public static void main(String[] args) {
		StudentDao studentDao = (StudentDao) factory.getBean("studentDao");
		studentDao.daoMethod();
		StudentDao studentDao1 = (StudentDao) factory.getBean("studentDao");
		StudentDao studentDao2 = (StudentDao) factory.getBean("studentDao");
		System.out.println(".studentDao1."+studentDao1);
		System.out.println(".studentDao2."+studentDao2);
	}
}
