package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import edu.bean.B;

/*
*
* @author Varma 
*
*/
public class InjectAtoBTest {
	private static ApplicationContext context = new ClassPathXmlApplicationContext(
			"spring-config.xml");

	public static void main(String[] args) {
		B b1 = (B) context.getBean("b1");
		B b2 = (B) context.getBean("b2");
	}
}
