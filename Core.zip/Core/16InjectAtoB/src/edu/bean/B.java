package edu.bean;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

/*
*
* @author Varma 
*
*/
public class B {
	private A a;

	public void setA(A a) {
		this.a = a;
	}

	public void bMethod() {
		// Implement common Logic and use A
	}
}
