package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.io.IOException;
import java.util.Properties;

import edu.message.Message;

/*
*
* @author Varma 
*
*/
public class MessageTest {
	private static Properties properties = new Properties();
	private static String messageClass;
	static {
		try {
			properties.load(MessageTest.class.getClassLoader()
					.getResourceAsStream("message.properties"));
			messageClass = properties.getProperty("message.class");
		} catch (IOException e) {
			System.err.println(e);
		}
	}

	public static void main(String[] args) throws Exception {
		Message message = (Message) Class.forName(messageClass).newInstance();
		System.out.println(message.getMessage());
	}

}
