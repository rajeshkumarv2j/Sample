package edu.message;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

/*
*
* @author Varma 
*
*/
public class HaiMessage implements Message{

	public String getMessage() {
		return "HaiMessage";
	}

}
