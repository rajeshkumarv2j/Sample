package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import edu.model.Student;

/*
*
* @author Varma 
*
*/
public class StudentTest {
	private static ApplicationContext context = new ClassPathXmlApplicationContext(
			"spring-config.xml");

	public static void main(String[] args) {
		// Student parent = (Student) context.getBean("parent");
		// We can't get the parent object, Becaz It's abstract...
		Student subClassOne = (Student) context.getBean("subClassOne");
		System.out.println(".Student No :" + subClassOne.getStudentNo());
		// StudentNo we are getting it from parent
		System.out.println(".Student Name :" + subClassOne.getStudentName());
		// StudentName is null, becaz we are not injecting
		Student subClassTwo = (Student) context.getBean("subClassTwo");
		System.out.println(".Student No :" + subClassTwo.getStudentNo());
		// StudentNo we are getting it from parent
		System.out.println(".Student Name :" + subClassTwo.getStudentName());
		// StudentName we can get it, Becaz we are injecting to sub...
	}
}
