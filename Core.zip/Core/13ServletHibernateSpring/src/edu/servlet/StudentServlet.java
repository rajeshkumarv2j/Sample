package edu.servlet;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.factory.ServiceFactory;
import edu.model.Student;
import edu.service.StudentService;

/*
*
* @author Varma 
*
*/
public class StudentServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		Student student = new Student();
		student.setStudentNo(Long.parseLong(req.getParameter("studentNo")));
		student.setStudentName(req.getParameter("studentName"));
		StudentService studentService = null;
		RequestDispatcher rd = null;
		try {
			studentService = ServiceFactory.getStudentService();
			studentService.insertStudent(student);
			rd = req.getRequestDispatcher("/success.jsp");
			rd.forward(req, resp);
		} catch (Exception e) {
			rd = req.getRequestDispatcher("/failure.jsp");
			rd.forward(req, resp);
		}
	}
}
