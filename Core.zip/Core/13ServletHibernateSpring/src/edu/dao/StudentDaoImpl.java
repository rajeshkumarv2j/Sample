package edu.dao;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import edu.model.Student;

/*
*
* @author Varma 
*
*/
public class StudentDaoImpl extends HibernateDaoSupport implements StudentDao {

	public void insertStudent(Student student) {
		getSession().save(student);
	}
}
