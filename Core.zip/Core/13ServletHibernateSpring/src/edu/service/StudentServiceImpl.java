package edu.service;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import edu.dao.StudentDao;
import edu.model.Student;

/*
*
* @author Varma 
*
*/
public class StudentServiceImpl implements StudentService {
	private StudentDao studentDao;

	public void setStudentDao(StudentDao studentDao) {
		this.studentDao = studentDao;
	}

	public void insertStudent(Student student) {
		studentDao.insertStudent(student);
	}
}
