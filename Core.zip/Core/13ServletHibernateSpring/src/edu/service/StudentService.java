package edu.service;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import edu.model.Student;

/*
*
* @author Varma 
*
*/
public interface StudentService {

	public void insertStudent(Student student);
}
