package edu.factory;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import edu.service.StudentService;

/*
*
* @author Varma 
*
*/
public class ServiceFactory {
	private static ApplicationContext context = new ClassPathXmlApplicationContext(
			"spring-config.xml");
	private static String STUDENT_SERVICE = "studentService";

	public static StudentService getStudentService() {
		return (StudentService) context.getBean(ServiceFactory.STUDENT_SERVICE);
	}
}
