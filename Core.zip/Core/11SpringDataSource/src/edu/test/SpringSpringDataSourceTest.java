package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

/*
*
* @author Varma 
*
*/
public class SpringSpringDataSourceTest {

	public static void main(String[] args) throws SQLException {
		BeanFactory factory = new XmlBeanFactory(new ClassPathResource(
				"spring-config.xml"));
		DataSource dataSource = (DataSource) factory.getBean("dataSource");
		System.out.println(".DataSource." + dataSource.getConnection());
	}

}
