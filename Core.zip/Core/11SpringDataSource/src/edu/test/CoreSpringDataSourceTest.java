package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.sql.SQLException;

import org.springframework.jdbc.datasource.DriverManagerDataSource;

/*
*
* @author Varma 
*
*/
public class CoreSpringDataSourceTest {

	public static void main(String[] args) throws SQLException {
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName("oracle.jdbc.driver.OracleDriver");
		dataSource.setUrl("jdbc:oracle:thin:@localhost:1521:SERVER");
		dataSource.setUsername("scott");
		dataSource.setPassword("tiger");
		System.out.println(dataSource.getConnection());
	}
}
