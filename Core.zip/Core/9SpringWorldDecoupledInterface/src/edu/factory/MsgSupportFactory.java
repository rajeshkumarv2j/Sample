package edu.factory;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

/*
*
* @author Varma 
*
*/
import edu.decoupledinterface.MsgRender;

public class MsgSupportFactory {
	private static BeanFactory factory = new XmlBeanFactory(
			new ClassPathResource("spring-config.xml"));

	public static MsgRender getMessageRender() {
		return (MsgRender) factory.getBean("render");
	}

}
