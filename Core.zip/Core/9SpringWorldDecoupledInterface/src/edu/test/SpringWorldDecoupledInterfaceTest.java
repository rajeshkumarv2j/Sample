package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

/*
*
* @author Varma 
*
*/
import edu.decoupledinterface.MsgRender;
import edu.factory.MsgSupportFactory;

public class SpringWorldDecoupledInterfaceTest {
	public static void main(String[] args) {
		MsgRender msgRender = MsgSupportFactory.getMessageRender();
		msgRender.render();
	}
}
