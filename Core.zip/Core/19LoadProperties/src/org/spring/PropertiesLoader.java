package org.spring;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.io.IOException;
import java.util.Properties;

import org.springframework.beans.factory.InitializingBean;

/*
*
* @author Varma 
*
*/
public class PropertiesLoader implements InitializingBean {
	private Properties properties = new Properties();
	private String location;

	public void setLocation(String location) {
		this.location = location;
	}

	public void afterPropertiesSet() throws Exception {
		loadProperties();
	}

	public void loadProperties() throws IOException {
		properties.load(PropertiesLoader.class.getClassLoader()
				.getResourceAsStream(location));
	}

	public String getProperty(String key) {
		return properties.getProperty(key);
	}
}
