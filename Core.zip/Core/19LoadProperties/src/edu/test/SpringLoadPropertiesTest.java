package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import org.spring.PropertiesLoader;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/*
*
* @author Varma 
*
*/
public class SpringLoadPropertiesTest {
	private static ApplicationContext context = new ClassPathXmlApplicationContext(
			"spring-config.xml");

	public static void main(String[] args) {
		PropertiesLoader propertiesLoader = (PropertiesLoader) context
				.getBean("propertiesLoader");
		System.out.println(".StudentNo."
				+ propertiesLoader.getProperty("studentNo"));
		System.out.println(".StudentName."
				+ propertiesLoader.getProperty("studentName"));
	}
}
