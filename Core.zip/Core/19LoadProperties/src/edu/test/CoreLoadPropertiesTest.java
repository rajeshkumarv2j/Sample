package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.util.Properties;

/*
*
* @author Varma 
*
*/
public class CoreLoadPropertiesTest {

	public static void main(String[] args) throws Exception {
		Properties properties = new Properties();
		properties.load(CoreLoadPropertiesTest.class.getClassLoader()
				.getResourceAsStream("student.properties"));
		System.out.println(".StudentNo." + properties.getProperty("studentNo"));
		System.out.println(".StudentName."
				+ properties.getProperty("studentName"));
	}
}
