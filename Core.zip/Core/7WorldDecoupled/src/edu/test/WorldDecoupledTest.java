package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import edu.decoupled.HaiWorldMsgProvider;
import edu.decoupled.HelloWorldMsgProvider;
import edu.decoupled.StdErrMsgRenderer;
import edu.decoupled.StdOutMsgRenderer;

/*
*
* @author Varma 
*
*/
public class WorldDecoupledTest {
	public static void main(String cArgs[]) {
		HaiWorldMsgProvider haiMsgProvider = new HaiWorldMsgProvider();
		HelloWorldMsgProvider helloMsgProvider = new HelloWorldMsgProvider();
//		StdErrMsgRenderer stdErrMsgRenderer = new StdErrMsgRenderer(helloMsgProvider);
		StdOutMsgRenderer stdOutMsgRenderer = new StdOutMsgRenderer();
		// stdOutMsgRenderer.setMsgProvider(haiMsgProvider);

	}
}
