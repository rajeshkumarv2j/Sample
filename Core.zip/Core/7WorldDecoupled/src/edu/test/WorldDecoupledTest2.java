package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import edu.decoupled.HaiWorldMsgProvider;
import edu.decoupled.StdErrMsgRenderer;

/*
*
* @author Varma 
*
*/
public class WorldDecoupledTest2 {
	public static void main(String cArgs[]) {
		HaiWorldMsgProvider msgProvider = new HaiWorldMsgProvider();
		StdErrMsgRenderer stdErrMsgRenderer = new StdErrMsgRenderer(msgProvider);
		stdErrMsgRenderer.render();
	}
}
