package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import edu.decoupled.HelloWorldMsgProvider;
import edu.decoupled.StdOutMsgRenderer;

/*
*
* @author Varma 
*
*/
public class WorldDecoupledTest1 {
	public static void main(String cArgs[]) {
		// Step 1:
		HelloWorldMsgProvider msgProvider = new HelloWorldMsgProvider();
		// Step 2:
		StdOutMsgRenderer stdOutMsgRenderer = new StdOutMsgRenderer();
		// Step 3:
		stdOutMsgRenderer.setMsgProvider(msgProvider);
		// Step 4:
		stdOutMsgRenderer.render();
	}
}
