package edu.decoupled;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

/*
*
* @author Varma 
*
*/
public class StdErrMsgRenderer {
	private HaiWorldMsgProvider msgProvider = null;

	public StdErrMsgRenderer(HaiWorldMsgProvider msgProvider) {
		this.msgProvider = msgProvider;
	}

	public void render() {
		if (msgProvider == null) {
			throw new RuntimeException("Message Provider is required");
		}
		System.err.println(msgProvider.getMessage());
	}
}
