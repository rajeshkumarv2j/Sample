package edu.decoupled;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

/*
*
* @author Varma 
*
*/
public class StdOutMsgRenderer {
	private HelloWorldMsgProvider msgProvider = null;

	public void setMsgProvider(HelloWorldMsgProvider msgProvider) {
		this.msgProvider = msgProvider;
	}

	public void render() {
		if (msgProvider == null) {
			throw new RuntimeException("Message Provider is required");
		}
		System.out.println(msgProvider.getMessage());
	}
}
