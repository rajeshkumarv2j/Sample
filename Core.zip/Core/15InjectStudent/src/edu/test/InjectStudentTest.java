package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import edu.model.Student;

/*
*
* @author Varma 
*
*/
public class InjectStudentTest {
	private static ApplicationContext context = new ClassPathXmlApplicationContext(
			"spring-config.xml");

	public static void main(String[] args) {
		Student student = (Student) context.getBean("student");
		System.out.println(".StudentNo." + student.getStudentNo());
		System.out.println(".StudentName." + student.getStudentName());
		String[] aliasesNames = (String[]) context.getAliases("student");
		System.out.println(".AliasesNames." + aliasesNames[0] + " ,"
				+ aliasesNames[1]);
	}
}
