/*
*
* @author Varma 
*
*/
package edu.decoupledinterface;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

public class StdOutMsgRender implements MsgRender {
	private MsgProvider msgProvider;

	public void setMsgProvider(MsgProvider msgProvider) {
		this.msgProvider = msgProvider;
	}

	public MsgProvider getMsgProvider() {
		return msgProvider;
	}

	public void render() {
		if (msgProvider == null) {
			throw new RuntimeException("Message Provider is required");
		}
		System.out.println(msgProvider.getMessage());
	}

}
