/*
*
* @author Varma 
*
*/
package edu.decoupledinterface;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

public interface MsgProvider {
	public String getMessage();
}
