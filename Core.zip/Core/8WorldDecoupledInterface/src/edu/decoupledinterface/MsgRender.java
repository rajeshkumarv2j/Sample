/*
*
* @author Varma 
*
*/
package edu.decoupledinterface;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

public interface MsgRender {
	public void render();

	public MsgProvider getMsgProvider();

	public void setMsgProvider(MsgProvider msgProvider);
}
