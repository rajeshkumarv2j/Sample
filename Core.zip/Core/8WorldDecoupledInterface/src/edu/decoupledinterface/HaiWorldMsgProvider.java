/*
*
* @author Varma 
*
*/
package edu.decoupledinterface;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

public class HaiWorldMsgProvider implements MsgProvider {
	public String getMessage() {
		return "Hai World";
	}
}
