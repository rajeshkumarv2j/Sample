package edu.factory;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.io.IOException;
import java.util.Properties;

/*
*
* @author Varma 
*
*/
import edu.decoupledinterface.MsgProvider;
import edu.decoupledinterface.MsgRender;

public class MsgSupportFactory {
	private static MsgSupportFactory msgSupportFactory = new MsgSupportFactory();
	private static Properties props = new Properties();
	private static MsgRender msgRenderer;
	private static MsgProvider msgProvider;

	static {
		try {
			props.load(MsgSupportFactory.class.getClassLoader()
					.getResourceAsStream("messagefactory.properties"));
			String rendererClass = props.getProperty("renderer.class");
			String providerClass = props.getProperty("provider.class");
			msgRenderer = (MsgRender) Class.forName(rendererClass)
					.newInstance();
			msgProvider = (MsgProvider) Class.forName(providerClass)
					.newInstance();

		} catch (ClassNotFoundException e) {
			System.err.println(e);
		} catch (IOException e) {
			System.err.println(e);
		} catch (InstantiationException e) {
			System.err.println(e);
		} catch (IllegalAccessException e) {
			System.err.println(e);
		}
	}

	public static MsgSupportFactory getInstance() {
		return msgSupportFactory;
	}

	public MsgRender getMessageRender() {
		return msgRenderer;
	}

	public MsgProvider getMessageProvider() {
		return msgProvider;
	}

}
