package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

/*
*
* @author Varma 
*
*/
import edu.decoupledinterface.MsgProvider;
import edu.decoupledinterface.MsgRender;
import edu.factory.MsgSupportFactory;

public class HelloWorldDecoupledWithFactoryTest {
	public static void main(String[] args) {
		MsgProvider msgProvider = MsgSupportFactory.getInstance()
				.getMessageProvider();
		MsgRender msgRender = MsgSupportFactory.getInstance()
				.getMessageRender();
		msgRender.setMsgProvider(msgProvider);
		msgRender.render();
	}
}
