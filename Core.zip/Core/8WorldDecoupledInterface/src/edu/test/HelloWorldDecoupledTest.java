package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

/*
*
* @author Varma 
*
*/
public class HelloWorldDecoupledTest {
	public static void main(String[] args) {
		// MsgRenderer msgRenderer = new SomeMsgRenderer();
		// MsgProvider msgProvider = new SomeMsgProvider();
		// msgRenderer.setMsgProvider(msgProvider);
		// msgRenderer.render();
	}
}
