package edu.core;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

/*
*
* @author Varma 
*
*/
public class WhyTypeCast {
	public static void main(String[] args) {
		// 1st Point
		Object object = new Object();
		Long studentNo = new Long(1);
		String studentName = new String("N@It");
		// 2nd Point
		Object studentNoObj = new Long(1);
		Object studentNameObj = new String("N@It");
//		System.out.println(".Student Name length()." + studentNameObj.length());
		String studentNameRef = (String) studentNameObj;
		System.out.println(".Student Name length()." + studentNameRef.length());
//		studentNameRef = (String) object;
	}
}
