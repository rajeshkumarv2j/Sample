package edu.util;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import edu.exception.ResourceHelperException;

/*
*
* @author Varma 
*
*/
public class ResourceHelper {
	private static Map<String, DataSource> cache = new HashMap<String, DataSource>();
	private static String NARESH_JNDI = "java:comp/env/jdbc/nareshJNDI";

	public static Connection getConnection() throws ResourceHelperException {
		Context context = null;
		DataSource dataSource = null;
		Connection connection = null;
		try {
			dataSource = (DataSource) cache.get(ResourceHelper.NARESH_JNDI);
			if (dataSource != null) {
				return dataSource.getConnection();
			}
			context = new InitialContext();
			dataSource = (DataSource) context
					.lookup(ResourceHelper.NARESH_JNDI);
			cache.put(ResourceHelper.NARESH_JNDI, dataSource);
			connection = dataSource.getConnection();
		} catch (NamingException e) {
			throw new ResourceHelperException(e.getMessage());
		} catch (SQLException e) {
			throw new ResourceHelperException(e.getMessage());
		}
		return connection;
	}
}
