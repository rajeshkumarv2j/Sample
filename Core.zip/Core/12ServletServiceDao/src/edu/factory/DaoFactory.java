package edu.factory;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import edu.dao.StudentDao;
import edu.dao.StudentDaoImpl;

/*
*
* @author Varma 
*
*/
public class DaoFactory {
	private static StudentDao studentDao = new StudentDaoImpl();

	public static StudentDao getStudentDao() {
		return studentDao;
	}

}
