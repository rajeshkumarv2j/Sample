package edu.factory;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import edu.service.StudentService;
import edu.service.StudentServiceImpl;

/*
*
* @author Varma 
*
*/
public class ServiceFactory {
	private static StudentService studentService = new StudentServiceImpl();
	public static StudentService getStudentService() {
		return studentService;
	}

}
