package edu.service;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import edu.exception.StudentException;
import edu.model.Student;

/*
*
* @author Varma 
*
*/
public interface StudentService {

	public boolean insertStudent(Student student) throws StudentException;
}
