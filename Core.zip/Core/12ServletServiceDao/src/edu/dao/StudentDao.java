package edu.dao;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import edu.exception.StudentException;
import edu.model.Student;

/*
*
* @author Varma 
*
*/
public interface StudentDao extends AbstractDao{

	public boolean insertStudent(Student student) throws StudentException;
}
