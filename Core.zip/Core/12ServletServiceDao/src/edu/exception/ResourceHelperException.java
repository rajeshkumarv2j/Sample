package edu.exception;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

/*
*
* @author Varma 
*
*/
public class ResourceHelperException extends Exception {
	String exceptionMessage = "";

	public ResourceHelperException() {
		super();
	}

	public ResourceHelperException(String exceptionMessage) {
		super(exceptionMessage);
		this.exceptionMessage = exceptionMessage;
	}

	public String toString() {
		return exceptionMessage;
	}
}
