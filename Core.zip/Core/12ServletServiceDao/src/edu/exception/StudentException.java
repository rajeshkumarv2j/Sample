package edu.exception;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

/*
*
* @author Varma 
*
*/
public class StudentException extends Exception {
	String exceptionMessage = "";

	public StudentException() {
		super();
	}

	public StudentException(String exceptionMessage) {
		super(exceptionMessage);
		this.exceptionMessage = exceptionMessage;
	}

	public String toString() {
		return exceptionMessage;
	}
}
