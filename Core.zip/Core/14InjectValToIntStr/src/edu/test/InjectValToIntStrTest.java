package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/*
*
* @author Varma 
*
*/
public class InjectValToIntStrTest {
	private static ApplicationContext context = new ClassPathXmlApplicationContext(
			"spring-config.xml");

	public static void main(String[] args) {
		Integer studentNo = (Integer) context.getBean("studentNo");
		System.out.println(".StudentNo." + studentNo);
		String studentName = (String) context.getBean("studentName");
		System.out.println(".StudentName." + studentName);
	}
}
