package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

/*
*
* @author Varma 
*
*/
public class CoreInjectValToIntStrTest {

	public static void main(String[] args) {
		Integer studentNo = new Integer(8);
		System.out.println(".StudentNo." + studentNo);
		String studentName = new String("N@It");
		System.out.println(".StudentName." + studentName);
	}

}
