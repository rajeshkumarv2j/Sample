import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class Dao {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@25.162.3.31:1521:PEOD01","PORTAL","portal");
		
	}
}
