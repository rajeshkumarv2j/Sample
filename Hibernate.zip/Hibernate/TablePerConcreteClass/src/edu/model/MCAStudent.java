package edu.model;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

/*
*
* @author Varma 
*
*/
public class MCAStudent extends Student {
	private String mcaStream;

	public String getMcaStream() {
		return mcaStream;
	}

	public void setMcaStream(String mcaStream) {
		this.mcaStream = mcaStream;
	}
}
