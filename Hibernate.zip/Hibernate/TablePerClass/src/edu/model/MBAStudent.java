package edu.model;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

/*
*
* @author Varma 
*
*/
public class MBAStudent extends Student {

	private String mbaStream;

	public MBAStudent(String studentName, String mbaStream) {
		super(studentName);
		this.mbaStream = mbaStream;
	}

	public String getMbaStream() {
		return mbaStream;
	}
}
