package edu.model;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

/*
*
* @author Varma 
*
*/
public class Student {
	private Long studentNo;
	private String studentName;

	public Student(String studentName) {
		this.studentName = studentName;
	}

	public Long getStudentNo() {
		return studentNo;
	}

	public String getStudentName() {
		return studentName;
	}

}
