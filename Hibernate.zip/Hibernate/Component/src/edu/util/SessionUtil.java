package edu.util;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

/*
*
* @author Varma 
*
*/
public class SessionUtil {

	private static final SessionFactory SESSION_FACTORY;
	static {
		try {
			SESSION_FACTORY = new Configuration()
					.configure("hibernate.cfg.xml").buildSessionFactory();
		} catch (HibernateException ex) {
			throw new ExceptionInInitializerError(
					"Exception building SessionFactory: " + ex.getMessage());
		}
	}

	public static Session getSession() throws HibernateException {
		Session session = SESSION_FACTORY.openSession();
		return session;
	}

	public static void closeSession(Session session) throws HibernateException {
		if (session != null) {
			session.close();
		}
	}
}
