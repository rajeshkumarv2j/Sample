package edu.model;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.util.Map;

/*
*
* @author Varma 
*
*/
public class Student {
	private Long studentNo;
	private String studentName;
	private Map<String, Course> courseMap;

	public Long getStudentNo() {
		return studentNo;
	}

	public void setStudentNo(Long studentNo) {
		this.studentNo = studentNo;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public Map<String, Course> getCourseMap() {
		return courseMap;
	}

	public void setCourseMap(Map<String, Course> courseMap) {
		this.courseMap = courseMap;
	}

}
