package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import edu.util.SessionUtil;

/*
*
* @author Varma 
*
*/
public class HQLTest {
	public static void main(String[] args) {
		Session session = SessionUtil.getSession();
		Transaction tx = session.beginTransaction();
		try {
			// <code Snippet - START>
			String studentQuery = "INSERT INTO StudentTest"
					+ "(studentNo,studentName) "
					+ "SELECT student.studentNo,student.studentName "
					+ "FROM Student student";

			Query query = session.createQuery(studentQuery);
			int noOfRecords = query.executeUpdate();
			System.out.println(".NoOfRecords :" + noOfRecords);
			// <code Snippet - END>

			tx.commit();
		} catch (HibernateException e) {
			System.err.println(".HibernateException." + e.getClass().getName()
					+ " -- " + e.getMessage());
			tx.rollback();
		}
	}
}
