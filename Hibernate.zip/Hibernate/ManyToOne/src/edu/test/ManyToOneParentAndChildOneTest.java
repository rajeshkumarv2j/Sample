package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import edu.model.Course;
import edu.model.Student;
import edu.util.SessionUtil;

/*
*
* @author Varma 
*
*/
public class ManyToOneParentAndChildOneTest {
	public static void main(String[] args) {
		Session session = SessionUtil.openSession();
		Transaction transaction = session.beginTransaction();
		try {
			// Step I
			Student student = new Student();
			Course course = new Course();
			// Step II.1
			student.setStudentName("N@It1");
			// Step II.2
			course.setCourseName("MCA");
			// Step II.3
			student.setCourse(course);
			// Step III
			session.save(student);
			transaction.commit();
			System.out.println(".SUCCESS.");
		} catch (HibernateException e) {
			transaction.rollback();
			System.err.println(".ManyToOneTest.main(String[])" + e);
		} finally {
			SessionUtil.closeSession(session);
		}
	}
}
