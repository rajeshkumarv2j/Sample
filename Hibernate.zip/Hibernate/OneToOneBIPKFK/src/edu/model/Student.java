package edu.model;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

/*
*
* @author Varma 
*
*/
public class Student {
	private Long studentNo = null;
	private String studentName = null;
	private StudentXtra studentXtra = null;
	public Long getStudentNo() {
		return studentNo;
	}
	public void setStudentNo(Long studentNo) {
		this.studentNo = studentNo;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public StudentXtra getStudentXtra() {
		return studentXtra;
	}
	public void setStudentXtra(StudentXtra studentXtra) {
		this.studentXtra = studentXtra;
	}
	
}
