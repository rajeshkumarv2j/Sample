package edu.test;

import java.util.HashMap;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.criterion.Conjunction;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Disjunction;
import org.hibernate.criterion.Expression;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.type.Type;

import edu.model.Student;
import edu.util.SessionUtil;

public class CriteriaTest {
	public static void main(String[] args) {
		/*Session session = SessionUtil.getSession();
		Criteria criteria = session.createCriteria(Student.class);
		List<Student> students = criteria.list();
		for(Student student: students){
			System.out.println(student);
		}
		SessionUtil.closeSession(session);
		*/
//		sum of student no..
		Session session = SessionUtil.getSession();
		Criteria criteria = session.createCriteria(Student.class);
//		criteria.add(Restrictions.sqlRestriction("SNO=? and SNAME=?",new Object[]{"1","HYD"},new Type[]{Hibernate.STRING,Hibernate.STRING}));//not(Restrictions.allEq(new HashMap<String, String>(){{put("studentNo", "1");put("studentName", "HYD");}})));//isNotNull("studentName"));
//		System.out.println(criteria.uniqueResult());//org.hibernate.NonUniqueResultException if more than 1 record comes
		/*Criterion snoCriterion = Restrictions.gt("studentNo", "1");
		Criterion snameCriterion = Restrictions.eq("studentName", "Chennai");
		Criterion sno1Criterion = Restrictions.eq("studentNo", "3");
		
		Disjunction disjunction = Restrictions.disjunction();
		disjunction.add(snoCriterion);
		disjunction.add(snameCriterion);
		disjunction.add(sno1Criterion);
		
		Conjunction disjunction1 = Restrictions.conjunction();
		disjunction1.add(snoCriterion);
		disjunction1.add(snameCriterion);
		disjunction1.add(sno1Criterion);
		criteria.add(disjunction1);*/
//		criteria.add(Restrictions.sqlRestriction("{alias}.SNAME like '%Y%'"));
		
//		criteria.setFirstResult(3);
//		criteria.setMaxResults(2);

//		criteria.setMaxResults(1);
//		criteria.addOrder(Order.asc("studentName"));
		
//		criteria.setProjection(Projections.rowCount());
//		System.out.println(criteria.uniqueResult());//list());
		
		/*ProjectionList list = Projections.projectionList();
		list.add(Projections.max("studentNo"));
		list.add(Projections.min("studentNo"));
		list.add(Projections.count("studentNo"));
		list.add(Projections.countDistinct("studentName"));
		criteria.setProjection(list);
		Object[] objects = (Object[]) criteria.uniqueResult();
		for(Object o : objects){
			System.out.print(" "+o);
		}*/
		
		
		ProjectionList list = Projections.projectionList();
		list.add(Projections.property("studentNo"));
		list.add(Projections.property("studentName"));
		criteria.setProjection(list);
		List list1 = criteria.list();
		for(Object o : list1){
			if(o instanceof Object[]){
				for(Object o1 : (Object[])o){
					System.out.print(" "+o1);
				}
				System.out.println();
			}
			else System.out.println(o);
		}
		SessionUtil.closeSession(session);
	}
}

