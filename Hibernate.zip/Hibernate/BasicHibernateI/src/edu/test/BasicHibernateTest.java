package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.sql.SQLException;

import org.hibernate.HibernateException;
import org.hibernate.ReplicationMode;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Environment;

import edu.model.Student;
import edu.util.SessionUtil;

/*
*
* @author Varma 
*
*/
public class BasicHibernateTest {
	public static void main(String[] args) {
		Session session = SessionUtil.getSession();
		Transaction tx = session.beginTransaction();
		try {
			try {
				System.out.println(session.connection().getTransactionIsolation());
				System.out.println(Environment.isolationLevelToString(session.connection().getTransactionIsolation()));
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			// <code Snippet - START>
			Student student = (Student) session.get(Student.class, "1");
			session.evict(student);
			session.replicate(student, ReplicationMode.LATEST_VERSION);
			student.setStudentName("N@It - U");
			// <code Snippet - END>
			tx.commit();
		} catch (HibernateException e) {
			System.err.println(".HibernateException." + e.getClass().getName() + " -- " + e.getMessage());
			tx.rollback();
		}
	}
}
