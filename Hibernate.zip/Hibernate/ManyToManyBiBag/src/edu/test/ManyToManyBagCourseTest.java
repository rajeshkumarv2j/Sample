package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import edu.model.Course;
import edu.model.Student;
import edu.util.SessionUtil;

/*
*
* @author Varma 
*
*/
public class ManyToManyBagCourseTest {
	public static void main(String[] args) throws Exception {
		Session session = SessionUtil.openSession();
		Transaction transaction = session.beginTransaction();
		try {
			// Step I
			Student studentOne = new Student();
			Student studentTwo = new Student();
			List<Student> studentSet = new ArrayList<Student>();

			Course courseOne = new Course();
			Course courseTwo = new Course();
			// Step II.
			studentOne.setStudentName("N@It1");
			studentTwo.setStudentName("N@It2");
			// Step II.1
			studentSet.add(studentOne);
			studentSet.add(studentTwo);
			// Step II.2
			courseOne.setCourseName("Java");
			courseTwo.setCourseName(".Net");
			// Step II.3
			courseOne.setStudentList(studentSet);
			courseTwo.setStudentList(studentSet);
			// Step III
			session.save(courseOne);
			session.save(courseTwo);
			transaction.commit();
			System.out.println(".SUCCESS.");
		} catch (HibernateException e) {
			transaction.rollback();
			System.err.println(".ManyToManyMapTest.main(String[])" + e);
		} finally {
			SessionUtil.closeSession(session);
		}
	}
}
