package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import edu.util.SessionUtil;

/*
*
* @author Varma 
*
*/
public class NamedQueriesTest {
	public static void main(String[] args) {
		Session session = SessionUtil.getSession();
		Transaction tx = session.beginTransaction();
		try {
			// <code Snippet - I - START>
			Query query = session.getNamedQuery("sqlQuery");
			List studentList = query.list();
			System.out.println(".No Of Records :" + studentList.size());
			// <code Snippet - I - END>
			tx.commit();
		} catch (HibernateException e) {
			System.err.println(".HibernateException." + e.getClass().getName()
					+ " -- " + e.getMessage());
			tx.rollback();
		}
	}
}
