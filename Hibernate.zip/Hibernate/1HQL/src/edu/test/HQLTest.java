package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import edu.util.SessionUtil;

/*
*
* @author Varma 
*
*/
public class HQLTest {
	public static void main(String[] args) {
		Session session = SessionUtil.getSession();
		Transaction tx = session.beginTransaction();
		try {
			// <code Snippet - START>
			String hqlQuery = "SELECT COUNT(studentNo), studentName FROM Student GROUP BY studentName";
			Query query = session.createQuery(hqlQuery);
			List studentList = query.list();
			System.out.println(".No of Records :" + studentList.size());
			// <code Snippet - END>
			tx.commit();
		} catch (HibernateException e) {
			System.err.println(".HibernateException." + e.getClass().getName()
					+ " -- " + e.getMessage());
			tx.rollback();
		}
	}
}
