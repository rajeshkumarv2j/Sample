package edu.id;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.hibernate.HibernateException;
import org.hibernate.engine.SessionImplementor;
import org.hibernate.id.IdentifierGenerator;

import edu.model.Student;

/*
*
* @author Varma 
*
*/
public class StudentNoGenerator implements IdentifierGenerator {

	public Serializable generate(SessionImplementor session, Object object)
			throws HibernateException {
		System.out.println(".object." + object);
		Student student = (Student) object;
		String location = student.getLocation();
		String studentNo = null;
		Statement statement = null;
		ResultSet resultSet = null;
		String studentNoSeqQuery = "SELECT TO_CHAR(STUDENTNO_SEQ.NEXTVAL, 'FM000' ) FROM DUAL";
		try {
			statement = session.getBatcher().prepareSelectStatement(
					studentNoSeqQuery);
			resultSet = statement.executeQuery(studentNoSeqQuery);
			if (resultSet != null && resultSet.next()) {
				studentNo = location + "" + resultSet.getString(1);
			}
		} catch (SQLException sqlException) {
			System.out.println(".SQLException." + sqlException);
		}
		return studentNo;
	}
}
