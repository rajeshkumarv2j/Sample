package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import org.hibernate.Hibernate;
import org.hibernate.HibernateException;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;

import edu.util.SessionUtil;

/*
*
* @author Varma 
*
*/
public class NativeSQLTest {
	public static void main(String[] args) {
		Session session = SessionUtil.getSession();
		Transaction tx = session.beginTransaction();
		try {
			String query = "SELECT AVG(SNO) sno FROM STUDENT";
			SQLQuery sqlQuery = session.createSQLQuery(query);
			sqlQuery.addScalar("sno", Hibernate.DOUBLE);
			Object object = sqlQuery.uniqueResult();
			System.out.println(".Result Object Type :"
					+ object.getClass().getName());
			System.out.println(".AVG :" + object);
			tx.commit();
		} catch (HibernateException e) {
			System.err.println(".HibernateException." + e.getClass().getName()
					+ " -- " + e.getMessage());
			tx.rollback();
		}
	}
}
