package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projections;

import edu.model.Student;
import edu.util.SessionUtil;

/*
*
* @author Varma 
*
*/
public class CriteriaTest {
	public static void main(String[] args) {
		Session session = SessionUtil.getSession();
		Transaction tx = session.beginTransaction();
		try {
			// <code Snippet - START>
			Object object = session.createCriteria(Student.class)
					.setProjection(Projections.sum("studentNo")).uniqueResult();
			System.out.println(".SUM :" + object);
			// <code Snippet - END>
			tx.commit();
		} catch (HibernateException e) {
			System.err.println(".HibernateException." + e.getClass().getName()
					+ " -- " + e.getMessage());
			tx.rollback();
		}
	}
}
