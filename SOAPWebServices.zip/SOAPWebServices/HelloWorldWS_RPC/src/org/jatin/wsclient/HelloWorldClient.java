package org.jatin.wsclient;

import java.net.MalformedURLException;
import java.net.URL;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;

import org.jatin.ws.HelloWorld;

public class HelloWorldClient {
	public static void main(String[] args) {
		URL url = null;
		try {
			url = new URL("http://localhost:9999/ws/hello?wsdl");
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
		QName qName = new QName("http://ws.jatin.org/", "HelloWorldImplService");
		Service service = Service.create(url, qName);
		HelloWorld helloWorld = service.getPort(HelloWorld.class);
		System.out.println(helloWorld.getHelloWorldAsString("Rajesh"));
	}
}
