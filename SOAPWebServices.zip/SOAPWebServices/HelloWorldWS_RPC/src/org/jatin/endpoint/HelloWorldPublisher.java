package org.jatin.endpoint;

import javax.xml.ws.Endpoint;

import org.jatin.ws.HelloWorldImpl;

public class HelloWorldPublisher{
	public static void main(String[] args) {
		Endpoint.publish("http://localhost:9999/", new HelloWorldImpl());
	}
}
