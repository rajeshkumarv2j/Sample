@javax.xml.bind.annotation.XmlSchema(namespace = "http://ws.mkyong.com/")
package com.mkyong.ws;
