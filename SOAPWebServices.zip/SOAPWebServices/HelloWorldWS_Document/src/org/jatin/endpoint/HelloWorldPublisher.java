package org.jatin.endpoint;

import javax.xml.ws.Endpoint;

import org.jatin.ws.HelloWorldImpl;

public class HelloWorldPublisher {
	public static void main(String[] args) {
		Endpoint.publish("http://localhost:9999/ws/", new HelloWorldImpl());
	}
}
/*Oct 27, 2016 12:08:17 AM com.sun.xml.internal.ws.model.RuntimeModeler getRequestWrapperClass
INFO: Dynamically creating request wrapper Class org.jatin.ws.jaxws.GetHelloWorldAsString
Oct 27, 2016 12:08:17 AM com.sun.xml.internal.ws.model.RuntimeModeler getResponseWrapperClass
INFO: Dynamically creating response wrapper bean Class org.jatin.ws.jaxws.GetHelloWorldAsStringResponse*/
