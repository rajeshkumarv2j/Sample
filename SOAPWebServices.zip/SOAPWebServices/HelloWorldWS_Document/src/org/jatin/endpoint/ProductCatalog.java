package org.jatin.endpoint;

public class ProductCatalog {
	public List<Pro> getProducts(String category) {
		
	}
}
