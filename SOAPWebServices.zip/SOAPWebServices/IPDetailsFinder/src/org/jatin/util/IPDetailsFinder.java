package org.jatin.util;

import net.webservicex.GeoIP;
import net.webservicex.GeoIPService;
import net.webservicex.GeoIPServiceSoap;

public class IPDetailsFinder {
	public static void main(String[] args) {
		String ipAddress = "157.240.7.35";//[0];
		GeoIPService geoIPService = new GeoIPService();
		GeoIPServiceSoap geoIPServiceSoap = geoIPService.getGeoIPServiceSoap();
		GeoIP geoIP = geoIPServiceSoap.getGeoIP(ipAddress);
		System.out.println(geoIP.getCountryCode());
		System.out.println(geoIP.getIP());
		System.out.println(geoIP.getCountryName());
	}
}
