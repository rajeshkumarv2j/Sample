package org.jatin.client;

import java.net.MalformedURLException;
import java.net.URL;
import java.rmi.RemoteException;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;

import org.jatin.ws.HelloWorld;
import org.jatin.ws.HelloWorldImplService;

public class HelloWorldTest {
	public static void main(String[] args) throws RemoteException, MalformedURLException {
		URL url = new URL("http://localhost:9999/ws/hello?wsdl");
		QName qName = new QName("http://ws.jatin.org/", "HelloWorldImplService");
		Service service = Service.create(url, qName);
		HelloWorld helloWorld = service.getPort(HelloWorld.class);
		System.out.println(helloWorld.getHelloWorldAsString("Rajesh"));
	}

	public static void main1(String[] args) {
		HelloWorldImplService helloWorldImplService = new HelloWorldImplService();
		System.out.println(helloWorldImplService.getHelloWorldImplPort()
				.getHelloWorldAsString("Rajesh"));
	}
}
