package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import edu.model.MBAStudent;
import edu.model.MCAStudent;
import edu.util.SessionUtil;

/*
*
* @author Varma 
*
*/
public class TablePerConcreteClassTest {

	public static void main(String[] args) {
		Session session = null;
		Transaction transaction = null;
		session = SessionUtil.getSession();
		transaction = session.beginTransaction();

		try {
			MCAStudent mcaStudent = new MCAStudent();
			mcaStudent.setStudentName("MCAName");
			mcaStudent.setMcaStream("Computers");
			MBAStudent mbaStudent = new MBAStudent();
			mbaStudent.setStudentName("MBAName");
			mbaStudent.setMbaStream("Marketing");
			session.save(mcaStudent);
			session.save(mbaStudent);
			transaction.commit();
		} catch (HibernateException e) {
			transaction.rollback();
		} finally {
			SessionUtil.closeSession(session);
		}
		System.out.println(".SUCCESS.");
	}
}
