package edu.model;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

/*
*
* @author Varma 
*
*/
public class MBAStudent extends Student {

	private String mbaStream;

	public String getMbaStream() {
		return mbaStream;
	}

	public void setMbaStream(String mbaStream) {
		this.mbaStream = mbaStream;
	}
}
