package edu.model;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

/*
*
* @author Varma 
*
*/
public class MCAStudent extends Student {
	private String mcaStream;

	public MCAStudent(String studentName, String mcaStream) {
		super(studentName);
		this.mcaStream = mcaStream;
	}

	public String getMcaStream() {
		return mcaStream;
	}
}
