package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import org.hibernate.HibernateException;
import org.hibernate.LockMode;
import org.hibernate.Session;
import org.hibernate.Transaction;

import edu.model.Student;
import edu.util.SessionUtil;

/*
*
* @author Varma 
*
*/
public class BasicHibernateTest {
	public static void main(String[] args) {
		Session session = SessionUtil.getSession();
		Transaction tx = session.beginTransaction();
		try {
			// <code Snippet - START>
			Student student = (Student) session.get(Student.class, "1");
			student.setStudentName("N@It - U");
			session.merge(student);
			// <code Snippet - END>
			tx.commit();
		} catch (HibernateException e) {
			System.err.println(".HibernateException." + e.getClass().getName()
					+ " -- " + e.getMessage());
			tx.rollback();
		}
	}
}
