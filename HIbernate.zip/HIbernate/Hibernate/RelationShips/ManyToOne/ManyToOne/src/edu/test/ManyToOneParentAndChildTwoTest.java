package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import edu.model.Course;
import edu.model.Student;
import edu.util.SessionUtil;

/*
*
* @author Varma 
*
*/
public class ManyToOneParentAndChildTwoTest {
	public static void main(String[] args) {
		Session session = SessionUtil.openSession();
		Transaction transaction = session.beginTransaction();
		try {
			// Step I
			Student studentOne = new Student();
			Student studentTwo = new Student();
			Course course = new Course();
			// Step II.1
			studentOne.setStudentName("N@It1");
			studentTwo.setStudentName("N@It2");
			// Step II.2
			course.setCourseName("MCA");
			// Step II.3
			studentOne.setCourse(course);
			studentTwo.setCourse(course);
			// Step III
			session.save(studentOne);
			session.save(studentTwo);
			transaction.commit();
			System.out.println(".SUCCESS.");
		} catch (HibernateException e) {
			transaction.rollback();
			System.err.println(".ManyToOneTest.main(String[])" + e);
		} finally {
			SessionUtil.closeSession(session);
		}
	}
}
