package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import edu.model.Student;
import edu.model.StudentXtra;
import edu.util.SessionUtil;

/*
*
* @author Varma 
*
*/
public class OneToOneITest {
	public static void main(String[] args) {
		Session session = SessionUtil.openSession();
		Transaction transaction = session.beginTransaction();
		try {
			// Step I
			Student student = new Student();
			StudentXtra studentXtra = new StudentXtra();
			// Step II
			student.setStudentName("N@It");
			studentXtra.setStudentAge("20");
			// Step III
			session.save(student);
			session.save(studentXtra);
			// We are persisting student and studentXtra separately, It's wrong.
			transaction.commit();
			System.out.println(".SUCCESS.");
		} catch (HibernateException e) {
			transaction.rollback();
			System.out.println(".OneToOneITest.main(String[])" + e);
		} finally {
			SessionUtil.closeSession(session);
		}
	}
}
