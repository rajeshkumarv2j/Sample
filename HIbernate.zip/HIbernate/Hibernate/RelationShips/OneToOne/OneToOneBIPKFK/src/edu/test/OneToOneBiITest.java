package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import edu.model.Student;
import edu.model.StudentXtra;
import edu.util.SessionUtil;

/*
*
* @author Varma 
*
*/
public class OneToOneBiITest {
	public static void main(String[] args) {
		Session session = SessionUtil.openSession();
		Transaction transaction = session.beginTransaction();
		try {
			// Step I
			StudentXtra studentXtra = new StudentXtra();
			Student student = new Student();
			// Step II.1
			studentXtra.setStudentAge("14");
			student.setStudentName("N@It");
			// Step II.2.1
			studentXtra.setStudent(student);
			// Step II.2.2
			student.setStudentXtra(studentXtra);
			// Step III.
			session.save(student); // OR session.save(studentXtra);
			transaction.commit();
			System.out.println(".SUCCESS.");
		} catch (HibernateException e) {
			transaction.rollback();
			System.out.println(".OneToOneITest.main(String[])" + e);
		} finally {
			SessionUtil.closeSession(session);
		}
	}
}
