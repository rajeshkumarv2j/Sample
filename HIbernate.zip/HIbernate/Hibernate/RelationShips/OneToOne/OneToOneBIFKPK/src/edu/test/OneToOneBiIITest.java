package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import edu.model.Student;
import edu.model.Library;
import edu.util.SessionUtil;

/*
*
* @author Varma 
*
*/
public class OneToOneBiIITest {
	public static void main(String[] args) {
		Session session = SessionUtil.openSession();
		Transaction transaction = session.beginTransaction();
		try {
			// Step I
			Student student = new Student();
			Library library = new Library();
			// Step II.1
			student.setStudentName("N@It");
			library.setLibraryName("Java");
			// Step II.2
			student.setLibrary(library);
			// Step II.3
			library.setStudent(student);
			// Step III
			session.save(library); // OR session.save(student);
			transaction.commit();
			System.out.println(".SUCCESS.");
		} catch (HibernateException e) {
			transaction.rollback();
			System.out.println(".OneToOneBiIITest.main(String[])" + e);
		} finally {
			SessionUtil.closeSession(session);
		}
	}
}
