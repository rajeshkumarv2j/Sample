package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import edu.model.Course;
import edu.model.Student;
import edu.util.SessionUtil;

/*
*
* @author Varma 
*
*/
public class LoadCourseManyToManyListTest {
	public static void main(String[] args) throws Exception {
		Session session = SessionUtil.openSession();
		Transaction transaction = session.beginTransaction();
		try {
			// Step I
			Course courseOne = null;
			Course courseTwo = null;
			List<Course> courseList = new ArrayList<Course>();
			Student student = new Student();
			// Step II.1
			courseOne = (Course) session.load(Course.class, new Long(1));
			courseTwo = (Course) session.load(Course.class, new Long(2));
			// Step II.2
			courseList.add(courseOne);
			courseList.add(courseTwo);
			// Step II.3
			student.setStudentName("N@It1");
			// Step II.4
			student.setCourseList(courseList);
			// Step III
			session.save(student);
			transaction.commit();
			System.out.println(".SUCCESS.");
		} catch (HibernateException e) {
			transaction.rollback();
			System.err.println(".OneToManyUniArrayTest.main(String[])" + e);
		} finally {
			SessionUtil.closeSession(session);
		}
	}
}
