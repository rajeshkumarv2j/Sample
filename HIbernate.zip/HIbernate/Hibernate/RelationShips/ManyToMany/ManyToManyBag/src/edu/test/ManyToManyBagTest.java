package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import edu.model.Course;
import edu.model.Student;
import edu.util.SessionUtil;

/*
*
* @author Varma 
*
*/
public class ManyToManyBagTest {
	public static void main(String []args) throws Exception {
		Session session = SessionUtil.openSession();
		Transaction transaction = session.beginTransaction();
		try {
			// Step I
			Course courseOne = new Course();
			Course courseTwo = new Course();
			List<Course> courseList = new ArrayList<Course>();
			Student studentOne = new Student();
			Student studentTwo = new Student();
			// Step II.1
			courseOne.setCourseName("Java");
			courseTwo.setCourseName(".Net");
			// Step II.2
			courseList.add(courseOne);
			courseList.add(courseTwo);
			// Step II.3
			studentOne.setStudentName("N@It1");
			studentTwo.setStudentName("N@It2");
			// Step II.4
			studentOne.setCourseList(courseList);
			studentTwo.setCourseList(courseList);
			// Step III
			session.save(studentOne);
			session.save(studentTwo);
			transaction.commit();
			System.out.println(".SUCCESS.");
		} catch (HibernateException e) {
			transaction.rollback();
			System.err.println(".OneToManyUniArrayTest.main(String[])" + e);
		} finally {
			SessionUtil.closeSession(session);
		}
	}
}
