package edu.util;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

/*
*
* @author Varma 
*
*/
public class SessionUtil {
	private static final SessionFactory SESSION_FACTORY;

	private SessionUtil() {
	}

	static {
		try {
			SESSION_FACTORY = new Configuration().configure(
					"hibernate.cfg.xml").buildSessionFactory();
		} catch (Throwable ex) {
			throw new ExceptionInInitializerError(
					"Initial SessionFactory creation failed. "
							+ ex.getMessage());
		}
	}

	public static Session openSession() {
		return SESSION_FACTORY.openSession();
	}

	public static void closeSession(Session session) {
		if (session != null) {
			session.close();
			session = null;
		}
	}
}
