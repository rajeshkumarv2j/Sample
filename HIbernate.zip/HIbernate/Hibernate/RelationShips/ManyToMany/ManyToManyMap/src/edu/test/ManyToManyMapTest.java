package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.util.HashMap;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import edu.model.Course;
import edu.model.Student;
import edu.util.SessionUtil;

/*
*
* @author Varma 
*
*/
public class ManyToManyMapTest {
	public static void main(String[] args) throws Exception {
		Session session = SessionUtil.openSession();
		Transaction transaction = session.beginTransaction();
		try {
			// Step I
			Course courseOne = new Course();
			Course courseTwo = new Course();
			HashMap<String, Course> courseMap = new HashMap<String, Course>();
			Student studentOne = new Student();
			Student studentTwo = new Student();
			// Step II.
			courseOne.setCourseName("Java");
			courseTwo.setCourseName(".Net");
			// Step II.
			courseMap.put("Java", courseOne);
			courseMap.put(".Net", courseTwo);
			//Key	-	IDX
			// Step II.
			studentOne.setStudentName("Naresh It");
			studentOne.setCourseMap(courseMap);
			// Step II.
			studentTwo.setStudentName("Naresh It");
			studentTwo.setCourseMap(courseMap);
			// Step II.
			session.save(studentOne);
			session.save(studentTwo);
			transaction.commit();
			System.out.println(".SUCCESS.");
		} catch (HibernateException e) {
			transaction.rollback();
			System.err.println(".ManyToManyMapTest.main(String[])" + e);
		} finally {
			SessionUtil.closeSession(session);
		}
	}
}
