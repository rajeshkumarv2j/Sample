package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import edu.model.Student;
import edu.model.Course;
import edu.util.SessionUtil;

/*
*
* @author Varma 
*
*/
public class OneToManyUniArrayTest {
	public static void main(String[] args) {
		Session session = SessionUtil.openSession();
		Transaction transaction = session.beginTransaction();
		try {
			// Step I
			Student studentOne = new Student();
			Student studentTwo = new Student();
			Student[] studentArray = new Student[2];
			Course course = new Course();
			// Step II.1
			studentOne.setStudentName("N@It1");
			studentTwo.setStudentName("N@It2");
			// Step II.2
			studentArray = new Student[] { studentOne, studentTwo };
			// Step II.3
			course.setCourseName("MCA");
			// Step II.4
			course.setStudentArray(studentArray);
			// Step III
			session.save(course);
			transaction.commit();
			System.out.println(".SUCCESS.");
		} catch (HibernateException e) {
			transaction.rollback();
			System.err.println(".OneToManyUniArrayTest.main(String[])" + e);
		} finally {
			SessionUtil.closeSession(session);
		}
	}
}
