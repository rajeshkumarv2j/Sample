package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import edu.model.Student;
import edu.util.SessionUtil;

/*
*
* @author Varma 
*
*/
public class BasicHibernateTest {
	public static void main(String[] args) {
		Session session = SessionUtil.getSession();
		Transaction tx = session.beginTransaction();
		try {
			Object object = session.get(Student.class, "BNG065");
			System.out.println("..");
			tx.commit();
		} catch (HibernateException e) {
			System.err.println(".HibernateException." + e.getClass().getName()
					+ " -- " + e.getMessage());
			tx.rollback();
		}
	}
}
