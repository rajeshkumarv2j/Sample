package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import edu.model.Student;
import edu.util.SessionUtil;

/*
*
* @author Varma 
*
*/
public class FirstLevelCache {
	public static void main(String[] args) {
		Session sessionOne = SessionUtil.getSession();
		Session sessionTwo = SessionUtil.getSession();
		Transaction tx1 = sessionOne.beginTransaction();
		Transaction tx2 = sessionTwo.beginTransaction();
		Student student = null;
		try {
			student = (Student) sessionOne.load(Student.class, new Long(1));
			System.out.println(".sessionOne.1st Time.Student Name."
					+ student.getStudentName());
			System.out.println(".Break Point.Update DB Record.");
			student = (Student) sessionOne.load(Student.class, new Long(1));
			System.out.println(".sessionOne.2nd Time.Student Name."
					+ student.getStudentName());
			student = (Student) sessionTwo.load(Student.class, new Long(1));
			System.out.println(".sessionTwo.1st Time.Student Name."
					+ student.getStudentName());
			tx1.commit();
			tx2.commit();
			System.out.println("Check the Console There will be 2 DB Hits");
			System.out.println("Becaz There are Two Session's. So 2 DB Hits");
		} catch (HibernateException e) {
			tx1.rollback();
			tx2.rollback();
		} finally {
			SessionUtil.closeSession(sessionOne);
			SessionUtil.closeSession(sessionTwo);
		}
	}
}
