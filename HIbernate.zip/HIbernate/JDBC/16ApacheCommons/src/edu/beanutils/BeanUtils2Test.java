package edu.beanutils;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import org.apache.commons.beanutils.BeanUtils;

/*
*
* @author Varma 
*
*/
public class BeanUtils2Test {

	public static void main(String[] args) throws Exception {
		Student student = new Student();
		student.setStudentNo("1");
		StudentCopy studentCopy = new StudentCopy();
		// studentCopy.setStudentNo(student.getStudentNo());
		BeanUtils.copyProperties(studentCopy, student);
		System.out.println(".StudentNo :" + studentCopy.getStudentNo());
	}
}
