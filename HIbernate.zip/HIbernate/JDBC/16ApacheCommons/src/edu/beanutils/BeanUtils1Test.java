package edu.beanutils;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.beanutils.BeanUtils;

/*
*
* @author Varma 
*
*/
public class BeanUtils1Test {

	public static void main(String[] args) throws Exception {
		Map studentMap = new HashMap();
		studentMap.put("studentNo", "1");
		Student student = new Student();
		// student.setStudentNo((String)studentMap.get("studentNo"));
		BeanUtils.populate(student, studentMap);
		System.out.println(".StudentNo :" + student.getStudentNo());
	}
}
