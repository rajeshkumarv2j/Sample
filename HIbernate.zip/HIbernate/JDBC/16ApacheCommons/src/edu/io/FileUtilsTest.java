package edu.io;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.io.File;

import org.apache.commons.io.FileUtils;

/*
*
* @author Varma 
*
*/
public class FileUtilsTest {

	public static void main(String[] args) throws Exception {
		File location = new File("f:/test");
		FileUtils.deleteDirectory(location);
	}

}
