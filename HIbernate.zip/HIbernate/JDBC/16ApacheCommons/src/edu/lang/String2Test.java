package edu.lang;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

/*
*
* @author Varma 
*
*/
public class String2Test {

	public static void main(String[] args) {
		// Un known Value, Means get the value from DB..
		String studentName = "Value";
		if (studentName != null && studentName.equals("N@It")) {
			System.out.println(".Equals.");
		} else {
			System.out.println(".Not Equals.");
		}
	}

}
