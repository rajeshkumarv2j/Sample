package edu.lang;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import org.apache.commons.lang.StringUtils;

/*
*
* @author Varma 
*
*/
public class String5Test {

	public static void main(String[] args) {
		// If both are Un known Values, Means get the value from DB..
		String studentName1 = "Value";
		String studentName2 = "Value";
		if (StringUtils.equals(studentName1, studentName2)) {
			System.out.println(".Equals.");
		} else {
			System.out.println(".Not Equals.");
		}
	}
}
