package edu.lang;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

/*
*
* @author Varma 
*
*/
public class String4Test {

	public static void main(String[] args) {
		//If both are Un known Values, Means get the value from DB..
		String studentName1 = "Value";
		String studentName2 = "Value";
		if (studentName1 != null && studentName1.equals(studentName2)) {
			// Or if (studentName2 != null && studentName2.equals(studentName1))
			System.out.println(".Equals.");
		} else {
			System.out.println(".Not Equals.");
		}
	}
}
