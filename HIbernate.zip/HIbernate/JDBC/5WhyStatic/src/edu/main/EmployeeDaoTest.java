package edu.main;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import edu.dao.EmployeeDao;

/*
*
* @author Varma 
*
*/
public class EmployeeDaoTest {

	public static void main(String[] args) {
		EmployeeDao.insertEmployee();
		EmployeeDao.updateEmployee();
	}
}
