package edu.dao;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

/*
*
* @author Varma 
*
*/
public class EmployeeDao {
	// No Instance Variable
	public static void insertEmployee() {
		System.out.println(".EmployeeDao.insertEmployee()");
	}

	public static void updateEmployee() {
		System.out.println(".EmployeeDao.updateEmployee()");
	}
}
