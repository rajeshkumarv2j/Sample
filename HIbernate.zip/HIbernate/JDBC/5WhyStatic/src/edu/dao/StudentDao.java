package edu.dao;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

/*
*
* @author Varma 
*
*/
public class StudentDao {
	// No Instance Variable
	public void insertStudent() {
		System.out.println(".StudentDao.insertStudent()");
	}
	public void updateStudent() {
		System.out.println(".StudentDao.updateStudent()");
	}
}
