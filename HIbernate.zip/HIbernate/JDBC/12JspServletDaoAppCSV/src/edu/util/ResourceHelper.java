package edu.util;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import edu.dao.StudentDao;

/*
*
* @author Varma 
*
*/
public class ResourceHelper {
	private static String driverClass;
	private static String url;
	private static String userName;
	private static String password;
	static {
		Properties dbConfigProp = new Properties();
		try {
			dbConfigProp.load(StudentDao.class.getClassLoader()
					.getResourceAsStream("db-config.properties"));
			driverClass = (String) dbConfigProp.get("driverClass");
			url = (String) dbConfigProp.get("url");
			userName = (String) dbConfigProp.get("userName");
			password = (String) dbConfigProp.get("password");
			Class.forName(driverClass);
			// How to convert properties object to map object?
			// Map<Object, Object> dbConfigMap = new HashMap<Object, Object>();
			// dbConfigMap.putAll(dbConfigProp);
		} catch (IOException e) {
			System.err.println(".SQLException." + e);
			throw new ExceptionInInitializerError("Loading properties file.");
		} catch (ClassNotFoundException e) {
			System.err.println(".ClassNotFoundException." + e);
			throw new ExceptionInInitializerError("Loading properties file.");
		}
	}

	public static Connection getConnection() {
		Connection connection = null;
		try {
			connection = DriverManager.getConnection(url, userName, password);
		} catch (SQLException e) {
			System.err.println(".SQLException." + e);
		}
		return connection;
	}
}
