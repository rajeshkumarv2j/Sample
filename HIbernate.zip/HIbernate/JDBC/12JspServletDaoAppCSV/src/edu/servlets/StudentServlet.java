package edu.servlets;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.dao.StudentDao;

/*
*
* @author Varma 
*
*/
public class StudentServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		String studentNo = req.getParameter("studentNo");
		String studentName = req.getParameter("studentName");
		RequestDispatcher rd = null;
		StudentDao studentDao = new StudentDao();
		try {
			studentDao.insertStudent(studentNo, studentName);
			rd = req.getRequestDispatcher("/WEB-INF/student/success.jsp");
			rd.forward(req, resp);
		} catch (Exception e) {
			System.err.println(".SQLException." + e);
			rd = req.getRequestDispatcher("/WEB-INF/student/failure.jsp");
			rd.forward(req, resp);
		}
	}

}
