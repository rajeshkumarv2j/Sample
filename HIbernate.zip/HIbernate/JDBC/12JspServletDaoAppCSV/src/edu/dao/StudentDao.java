package edu.dao;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.commons.dbutils.DbUtils;

import edu.util.ResourceHelper;

/*
*
* @author Varma 
*
*/
public class StudentDao {

	public void insertStudent(String studentNo, String studentName) {
		String query = "INSERT INTO STUDENT VALUES(?,?)";
		Connection connection = ResourceHelper.getConnection();
		PreparedStatement ps = null;
		try {
			ps = connection.prepareStatement(query);
			ps.setLong(1, new Long(studentNo));
			ps.setString(2, studentName);
			ps.executeUpdate();
		} catch (SQLException e) {
			System.err.println(".SQLException." + e);
		} finally {
			DbUtils.closeQuietly(connection, ps, null);
		}
	}
}
