package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.Properties;

/*
*
* @author Varma 
*
*/
public class ReflectionTest {
	private static Properties reflectionProp = new Properties();
	static {
		try {
			reflectionProp.load(ReflectionTest.class.getClassLoader()
					.getResourceAsStream("reflection.properties"));
		} catch (IOException e) {
		}
	}

	public static void main(String[] args) {
		try {
			String className = reflectionProp.getProperty("className");
			String methodName = reflectionProp.getProperty("methodName");
			// Step 1
			Class class1 = Class.forName(className);
			Object object = class1.newInstance();
			System.out.println(".Object - points -> " + object);
			// Step 2.1
			Class[] parameter = new Class[2];
			parameter[0] = Integer.TYPE;
			parameter[1] = Integer.TYPE;
			// Step 2.2
			Method method = class1.getMethod(methodName, parameter);
			// Step 2.3
			Integer[] input = { new Integer(4), new Integer(4) };
			// Step 2.4
			Integer output = (Integer) method.invoke(object, input);
			System.out.println("Result : " + output.intValue());
			System.out.println(".ReturnType :" + method.getReturnType());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
