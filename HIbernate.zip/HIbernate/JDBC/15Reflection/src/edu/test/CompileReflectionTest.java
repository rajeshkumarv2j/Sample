package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import edu.math.Caliculation;

/*
*
* @author Varma 
*
*/
public class CompileReflectionTest {

	public static void main(String[] args) {
		Caliculation caliculation = new Caliculation();
		int sum = caliculation.add(4, 4);
		System.out.println(".SUM :" + sum);
	}

}
