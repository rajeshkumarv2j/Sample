package edu.servlets;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/*
*
* @author Varma 
*
*/
public class StudentServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	private Connection connection = null;

	public void init(ServletConfig config) throws ServletException {
		String driverClass = config.getInitParameter("driverClass");
		String url = config.getInitParameter("url");
		String userName = config.getInitParameter("userName");
		String password = config.getInitParameter("password");
		try {
			Class.forName(driverClass);
			connection = DriverManager.getConnection(url, userName, password);
		} catch (ClassNotFoundException e) {
			System.err.println(".ClassNotFoundException." + e);
		} catch (SQLException e) {
			System.err.println(".SQLException." + e);
		}
	}

	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		String studentNo = req.getParameter("studentNo");
		String studentName = req.getParameter("studentName");
		RequestDispatcher rd = null;
		String query = "INSERT INTO STUDENT VALUES(?,?)";
		PreparedStatement ps;
		if (connection != null) {
			try {
				ps = connection.prepareStatement(query);
				ps.setLong(1, new Long(studentNo));
				ps.setString(2, studentName);
				ps.executeUpdate();
				rd = req.getRequestDispatcher("/WEB-INF/student/success.jsp");
				rd.forward(req, resp);
			} catch (SQLException e) {
				System.err.println(".SQLException." + e);
				rd = req.getRequestDispatcher("/WEB-INF/student/failure.jsp");
				rd.forward(req, resp);
			}
		} else {
			rd = req.getRequestDispatcher("/WEB-INF/student/failure.jsp");
			rd.forward(req, resp);
		}
	}

	public void destroy() {
		try {
			if (connection != null)
				connection.close();
		} catch (SQLException e) {
			System.err.println(".SQLException." + e);
		}
	}
}
