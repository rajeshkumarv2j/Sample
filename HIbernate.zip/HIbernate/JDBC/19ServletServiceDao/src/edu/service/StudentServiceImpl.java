package edu.service;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.commons.dbutils.DbUtils;

import edu.dao.StudentDao;
import edu.exception.ResourceHelperException;
import edu.exception.StudentException;
import edu.factory.DaoFactory;
import edu.model.Student;
import edu.util.ResourceHelper;

/*
*
* @author Varma 
*
*/
public class StudentServiceImpl implements StudentService {

	public boolean insertStudent(Student student) throws StudentException {
		Connection connection = null;
		boolean status = false;
		try {
			connection = ResourceHelper.getConnection();
			connection.setAutoCommit(false);
			StudentDao studentDao = DaoFactory.getStudentDao();
			studentDao.setConnection(connection);
			status = studentDao.insertStudent(student);
			connection.commit();
		} catch (SQLException e) {
			DbUtils.rollbackAndCloseQuietly(connection);
			throw new StudentException(e.getMessage());
		} catch (ResourceHelperException e) {
			DbUtils.rollbackAndCloseQuietly(connection);
			throw new StudentException(e.getMessage());
		} finally {
			DbUtils.closeQuietly(connection);
		}
		return status;
	}
}
