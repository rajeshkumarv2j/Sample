package edu.servlets;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.exception.StudentException;
import edu.factory.ServiceFactory;
import edu.model.Student;
import edu.service.StudentService;

/*
*
* @author Varma 
*
*/
public class StudentServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Student student = new Student();
		student.setStudentNo(request.getParameter("studentNo"));
		student.setStudentName(request.getParameter("studentName"));
		StudentService studentService = ServiceFactory.getStudentService();
		RequestDispatcher rd = null;
		boolean status = false;
		try {
			status = studentService.insertStudent(student);
			if (status) {
				rd = request
						.getRequestDispatcher("/WEB-INF/student/success.jsp");
				rd.forward(request, response);
			} else {
				rd = request
						.getRequestDispatcher("/WEB-INF/student/failure.jsp");
				rd.forward(request, response);
			}
		} catch (StudentException e) {
			rd = request.getRequestDispatcher("/WEB-INF/student/error.jsp");
			rd.forward(request, response);
		}
	}
}
