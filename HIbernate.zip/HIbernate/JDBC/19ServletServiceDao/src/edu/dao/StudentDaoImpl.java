package edu.dao;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.commons.dbutils.DbUtils;

import edu.exception.StudentException;
import edu.model.Student;

/*
*
* @author Varma 
*
*/
public class StudentDaoImpl extends AbstractDaoImpl implements StudentDao {
	private static String sql = "INSERT INTO STUDENT VALUES(?,?)";

	public boolean insertStudent(Student student) throws StudentException {

		Connection connection = null;
		PreparedStatement ps = null;
		boolean status = false;
		try {
			connection = getConnection();
			ps = connection.prepareStatement(sql);
			ps.setString(1, student.getStudentNo());
			ps.setString(2, student.getStudentName());
			status = ps.executeUpdate() > 0 ? true : false;
		} catch (SQLException e) {
			throw new StudentException(
					".Exception occured in StudentDao. insertStudent" + e);
		} finally {
			DbUtils.closeQuietly(ps);
		}
		return status;
	}
}
