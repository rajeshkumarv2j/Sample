package edu.dao;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

/*
*
* @author Varma 
*
*/
public class StudentDao {

	// No Instance Variable

	// Step 1
	private StudentDao() {
	}

	// Step 2:
	private static StudentDao studentDao = new StudentDao();

	// Step 3
	public static StudentDao getInstance() {
		return studentDao;
	}

	public void insertStudent() {
		System.out.println(".StudentDao.insertStudent()");
	}

	public void updateStudent() {
		System.out.println(".StudentDao.updateStudent()");
	}

}
