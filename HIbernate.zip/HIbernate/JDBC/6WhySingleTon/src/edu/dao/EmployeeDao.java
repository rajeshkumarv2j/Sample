package edu.dao;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

/*
*
* @author Varma 
*
*/
public class EmployeeDao {
	// No Instance Variable

	// Step 1
	private EmployeeDao() {
	}

	// Step 2
	private static EmployeeDao employeeDao;

	// Step 3
	public static EmployeeDao getInstance() {
		if (employeeDao == null)
			employeeDao = new EmployeeDao();
		return employeeDao;
	}

	public void insertEmployee() {
		System.out.println(".EmployeeDao.insertEmployee()");
	}

	public void updateEmployee() {
		System.out.println(".EmployeeDao.updateEmployee()");
	}

}
