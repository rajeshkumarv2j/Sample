package edu.dao;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

/*
*
* @author Varma 
*
*/
public class EmployeeDao {
	// No Instance Variable
	public void insertEmployee() {
		System.out.println(".EmployeeDao.insertEmployee()");
	}

	public void updateEmployee() {
		System.out.println(".EmployeeDao.updateEmployee()");
	}

}
