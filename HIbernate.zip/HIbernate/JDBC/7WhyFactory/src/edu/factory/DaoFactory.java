package edu.factory;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import edu.dao.EmployeeDao;
import edu.dao.StudentDao;

/*
*
* @author Varma 
*
*/
public class DaoFactory {
	private static StudentDao studentDao = new StudentDao();
	private static EmployeeDao employeeDao = new EmployeeDao();

	private DaoFactory() {
	}

	public static StudentDao getStudentDao() {
		return studentDao;
	}

	public static EmployeeDao getEmployeeDao() {
		return employeeDao;
	}

}
