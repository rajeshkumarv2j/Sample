package edu.main;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import edu.dao.EmployeeDao;
import edu.factory.DaoFactory;

/*
*
* @author Varma 
*
*/
public class EmployeeDaoTest {

	public static void main(String[] args) {
		EmployeeDao employeeDaoOne = DaoFactory.getEmployeeDao();
		employeeDaoOne.insertEmployee();
		employeeDaoOne.updateEmployee();
		EmployeeDao employeeDaoTwo = DaoFactory.getEmployeeDao();
		System.out.println(".employeeDaoOne." + employeeDaoOne);
		System.out.println(".employeeDaoTwo." + employeeDaoTwo);
	}
}
