package edu.main;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import edu.dao.StudentDao;
import edu.factory.DaoFactory;

/*
*
* @author Varma 
*
*/
public class StudentDaoTest {
	public static void main(String[] args) {
		StudentDao studentDaoOne = DaoFactory.getStudentDao();
		studentDaoOne.insertStudent();
		studentDaoOne.updateStudent();
		StudentDao studentDaoTwo = DaoFactory.getStudentDao();
		System.out.println(".studentDaoOne." + studentDaoOne);
		System.out.println(".studentDaoTwo." + studentDaoTwo);
	}
}
