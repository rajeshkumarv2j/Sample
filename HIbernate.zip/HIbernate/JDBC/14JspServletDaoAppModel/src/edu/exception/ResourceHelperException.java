package edu.exception;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

/*
*
* @author Varma 
*
*/
public class ResourceHelperException extends Exception {
	private static final long serialVersionUID = 1L;
	String exceptionMessage = "";

	public ResourceHelperException() {
		super();
	}

	public ResourceHelperException(String exceptionMessage) {
		super(exceptionMessage);
		this.exceptionMessage = exceptionMessage;
	}

	public String toString() {
		return exceptionMessage;
	}
}
