package edu.exception;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

/*
*
* @author Varma 
*
*/
public class EmployeeException extends Exception {
	private static final long serialVersionUID = 1L;
	String exceptionMessage = "";

	public EmployeeException() {
		super();
	}

	public EmployeeException(String exceptionMessage) {
		super(exceptionMessage);
		this.exceptionMessage = exceptionMessage;
	}

	public String toString() {
		return exceptionMessage;
	}
}
