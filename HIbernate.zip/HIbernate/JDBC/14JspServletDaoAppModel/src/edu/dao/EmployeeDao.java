package edu.dao;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.commons.dbutils.DbUtils;

import edu.exception.EmployeeException;
import edu.exception.ResourceHelperException;
import edu.model.Employee;
import edu.util.ResourceHelper;

/*
*
* @author Varma 
*
*/
public class EmployeeDao {
	private static String query = "INSERT INTO EMPLOYEE VALUES(?,?)";

	public void insertEmployee(Employee employee) throws EmployeeException {
		PreparedStatement ps = null;
		Connection connection = null;
		try {
			connection = ResourceHelper.getStuConnection();
			ps = connection.prepareStatement(query);
			ps.setLong(1, employee.getEmployeeNo());
			ps.setString(2, employee.getEmployeeName());
			ps.executeUpdate();
		} catch (SQLException e) {
			System.err.println(".SQLException." + e);
			throw new EmployeeException(".EmployeeException." + e);
		} catch (ResourceHelperException e) {
			System.err.println(".ResourceHelperException." + e);
			throw new EmployeeException(".EmployeeException." + e);
		} finally {
			DbUtils.closeQuietly(ps);
			DbUtils.closeQuietly(connection);
		}
	}
}
