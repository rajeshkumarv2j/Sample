package edu.dao;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.commons.dbutils.DbUtils;

import edu.exception.ResourceHelperException;
import edu.exception.StudentException;
import edu.model.Student;
import edu.util.ResourceHelper;

/*
*
* @author Varma 
*
*/
public class StudentDao {
	private static String query = "INSERT INTO STUDENT VALUES(?,?)";

	public void insertStudent(Student student) throws StudentException {
		PreparedStatement ps = null;
		Connection connection = null;
		try {
			connection = ResourceHelper.getStuConnection();
			ps = connection.prepareStatement(query);
			ps.setLong(1, student.getStudentNo());
			ps.setString(2, student.getStudentName());
			ps.executeUpdate();
		} catch (SQLException e) {
			System.err.println(".SQLException." + e);
			throw new StudentException(".StudentException." + e);
		} catch (ResourceHelperException e) {
			System.err.println(".ResourceHelperException." + e);
			throw new StudentException(".StudentException." + e);
		} finally {
			DbUtils.closeQuietly(ps);
			DbUtils.closeQuietly(connection);
		}
	}
}
