package edu.servlets;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.dao.EmployeeDao;
import edu.exception.EmployeeException;
import edu.model.Employee;

/*
*
* @author Varma 
*
*/
public class EmployeeServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	private static final String EMPLOYEE = "employee";

	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		Employee employee = new Employee();
		employee.setEmployeeNo(new Long(req.getParameter("employeeNo")));
		employee.setEmployeeName(req.getParameter("employeeName"));
		RequestDispatcher rd = null;
		EmployeeDao employeeDao = new EmployeeDao();
		try {
			employeeDao.insertEmployee(employee);
			req.setAttribute(EmployeeServlet.EMPLOYEE, employee);
			rd = req.getRequestDispatcher("/WEB-INF/employee/employeeSuccess.jsp");
			rd.forward(req, resp);
		} catch (EmployeeException e) {
			System.err.println(".EmployeeException." + e);
			rd = req.getRequestDispatcher("/WEB-INF/common/failure.jsp");
			rd.forward(req, resp);
		}
	}
}
