package edu.util;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;

import edu.exception.ResourceHelperException;

/*
*
* @author Varma 
*
*/
public class ResourceHelper {

	private static String driverClass;
	private static String url;
	private static String userName;
	private static String password;
	static {
		SAXBuilder builder = new SAXBuilder();
		Document document = null;
		String env = null;
		try {
			document = builder.build((ResourceHelper.class.getClassLoader()
					.getResourceAsStream("db-config.xml")));
			env = System.getenv("STU.ENV");
			Element element = document.getRootElement().getChild(env).getChild(
					"StuSchema1");
			driverClass = element.getAttributeValue("driver");
			url = element.getAttributeValue("url");
			userName = element.getAttributeValue("user");
			password = element.getAttributeValue("password");
		} catch (IOException e) {
			System.err.println(".IOException." + e);
			throw new ExceptionInInitializerError("Loading XML file.");
		} catch (JDOMException e) {
			System.err.println(".JDOMException." + e);
			throw new ExceptionInInitializerError("Loading XML file.");
		}
	}

	public static Connection getStuConnection() throws ResourceHelperException {
		Connection connection = null;
		try {
			Class.forName(driverClass);
			connection = DriverManager.getConnection(url, userName, password);
		} catch (ClassNotFoundException e) {
			System.err.println(".ClassNotFoundException." + e);
			throw new ResourceHelperException(e.getMessage());
		} catch (SQLException e) {
			System.err.println(".SQLException." + e);
			throw new ResourceHelperException(e.getMessage());
		}
		return connection;
	}
}
