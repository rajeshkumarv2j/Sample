package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.util.HashMap;
import java.util.Map;

/*
*
* @author Varma 
*
*/
class Student3 {
	private String studentNo;

	public String getStudentNo() {
		return studentNo;
	}

	public void setStudentNo(String studentNo) {
		this.studentNo = studentNo;
	}

}

public class WhyEqualsHashCode3Test {

	public static void main(String[] args) {
		Student3 student = new Student3();
		student.setStudentNo("1");
		Map stuMap = new HashMap();
		stuMap.put(student, "N@It");
		// To retrieve the value..
		String studentName = (String) stuMap.get(student);
		System.out.println(".." + studentName);
	}

}
