package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.util.HashMap;
import java.util.Map;

/*
*
* @author Varma 
*
*/
class Student4 {
	private String studentNo;

	public String getStudentNo() {
		return studentNo;
	}

	public void setStudentNo(String studentNo) {
		this.studentNo = studentNo;
	}

}

public class WhyEqualsHashCode4Test {

	public static void main(String[] args) {
		Student4 student = new Student4();
		student.setStudentNo("1");
		Map stuMap = new HashMap();
		stuMap.put(student, "N@It");
		// To retrieve the value..
		// Here we are using diff REf...
		Student4 studentRef = new Student4();
		studentRef.setStudentNo("1");
		String studentName = (String) stuMap.get(studentRef);
		System.out.println(".." + studentName);
	}

}
