package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.util.HashMap;
import java.util.Map;

/*
*
* @author Varma 
*
*/
public class WhyEqualsHashCode2Test {

	public static void main(String[] args) {
		String studentNo = "1";
		Map stuMap = new HashMap();
		stuMap.put(studentNo, "N@It");
		// To retrieve the value..
		//Here we are using diff REf...
		String studentNoRef = "1";
		String studentName = (String) stuMap.get(studentNoRef);
		System.out.println(".." + studentName);
	}

}
