package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

/*
*
* @author Varma 
*
*/
class Student {
	private String studentNo;

	public String getStudentNo() {
		return studentNo;
	}

	public void setStudentNo(String studentNo) {
		this.studentNo = studentNo;
	}

	public final boolean equals(Object obj) {
		boolean isEqual = false;
		Student student = (Student) obj;
		isEqual = new EqualsBuilder().append(this.studentNo,
				student.getStudentNo()).isEquals();
		return isEqual;
	}

	public final int hashCode() {
		int hashCode = new HashCodeBuilder(17, 37).append(studentNo)
				.toHashCode();
		return hashCode;
	}
}

public class WhyEqualsHashCodeTest {

	public static void main(String[] args) {
		Student student = new Student();
		student.setStudentNo("1");
		Map stuMap = new HashMap();
		stuMap.put(student, "N@It");
		// To retrieve the value..
		// Here we are using diff REf...
		Student studentRef = new Student();
		studentRef.setStudentNo("1");
		String studentName = (String) stuMap.get(studentRef);
		System.out.println(".." + studentName);
	}

}
