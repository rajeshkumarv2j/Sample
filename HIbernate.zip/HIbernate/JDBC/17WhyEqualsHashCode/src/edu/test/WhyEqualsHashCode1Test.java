package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.util.HashMap;
import java.util.Map;

/*
*
* @author Varma 
*
*/
public class WhyEqualsHashCode1Test {

	public static void main(String[] args) {
		String studentNo = "1";
		Map stuMap = new HashMap();
		stuMap.put(studentNo, "N@It");
		// To retrieve the value..
		String studentName = (String) stuMap.get(studentNo);
		System.out.println(".." + studentName);
	}

}
