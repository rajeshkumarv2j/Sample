package edu.servlets;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.constants.StudentConstants;
import edu.dao.StudentDao;
import edu.dao.StudentDaoImpl;
import edu.exception.StudentException;
import edu.model.Student;

/*
*
* @author Varma 
*
*/
public class StudentServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		StudentDao studentDao = new StudentDaoImpl();
		List<Student> studentlist = null;
		RequestDispatcher rd = null;
		try {
			studentlist = studentDao.loadAllStudents();
			request.setAttribute(StudentConstants.STUDENT_LIST, studentlist);
			rd = request
					.getRequestDispatcher("/WEB-INF/student/displayStudents.jsp");
			rd.forward(request, response);
		} catch (StudentException e) {
			rd = request.getRequestDispatcher("/WEB-INF/student/failure.jsp");
			rd.forward(request, response);
		}
	}
}
