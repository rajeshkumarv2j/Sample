package edu.constants;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

/*
*
* @author Varma 
*
*/
public interface StudentConstants {
	public static final String STUDENT_LIST = "studentList";
	public static final String STUDENT = "student";
}
