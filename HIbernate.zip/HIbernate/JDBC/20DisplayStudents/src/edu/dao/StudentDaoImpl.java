package edu.dao;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.dbutils.DbUtils;

import edu.exception.ResourceHelperException;
import edu.exception.StudentException;
import edu.model.Student;
import edu.util.ResourceHelper;

/*
*
* @author Varma 
*
*/
public class StudentDaoImpl implements StudentDao {
	// the refresh period for the cache
	private static final long REFRESH_INTERVAL = (1000 * 1 * 30);
	private static List<Student> cacheStudentList = new ArrayList<Student>();
	private static Long timeStamp = new Long(System.currentTimeMillis());;

	public List<Student> loadAllStudents() throws StudentException {
		String stuQuery = "SELECT SNO, SNAME FROM STUDENT ";
		Connection connection = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<Student> studentList = new ArrayList<Student>();
		try {
			if (isStaleCache() && cacheStudentList.size() > 0) {
				return cacheStudentList;
			} else {
				cacheStudentList.clear();
				connection = ResourceHelper.getConnection();
				ps = connection.prepareStatement(stuQuery);
				rs = ps.executeQuery();
				if (rs != null && rs.getFetchSize() > 0) {
					Student student = null;
					while (rs.next()) {
						student = new Student();
						student.setStudentNo(rs.getInt("SNO"));
						student.setStudentName(rs.getString("SNAME"));
						studentList.add(student);
					}
					timeStamp = new Long(System.currentTimeMillis());
					cacheStudentList = studentList;
				}
			}
		} catch (SQLException e) {
			throw new StudentException(e.getMessage());
		} catch (ResourceHelperException e) {
			throw new StudentException(e.getMessage());
		} finally {
			DbUtils.closeQuietly(connection, ps, null);
		}
		return cacheStudentList;
	}

	private boolean isStaleCache() {
		return (System.currentTimeMillis() - timeStamp.longValue()) < REFRESH_INTERVAL;
	}
}
