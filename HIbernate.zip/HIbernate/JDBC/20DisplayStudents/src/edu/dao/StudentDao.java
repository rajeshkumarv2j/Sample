package edu.dao;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.util.List;

import edu.exception.StudentException;
import edu.model.Student;

/*
*
* @author Varma 
*
*/
public interface StudentDao {

	public List<Student> loadAllStudents() throws StudentException;
}
