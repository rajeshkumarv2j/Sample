package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import edu.dao.StudentDao;
import edu.model.Student;

/*
*
* @author Varma 
*
*/
public class WhyJavaBeanTest {
	public static void main(String[] args) {
		Student student = new Student();
		student.setStudentNo(new String("1"));
		student.setStudentName(new String("N@It"));
		student.setStudentAge(new String("8"));
		student.setStudentQual( new String("BCA"));
		student.setStudentMarks(new String("75"));
		StudentDao studentDao = new StudentDao();
		studentDao.insertStudent(student);
	}
}
