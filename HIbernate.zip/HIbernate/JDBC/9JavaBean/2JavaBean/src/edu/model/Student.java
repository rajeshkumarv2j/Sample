package edu.model;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

// JavaBean/POJO/Model/Form/V.O./ D.T.O./ D.O....etc
/*
*
* @author Varma 
*
*/
public class Student {
	private String studentNo;
	private String studentName;
	private String studentAge;
	private String studentQual;
	private String studentMarks;

	public String getStudentNo() {
		return studentNo;
	}

	public void setStudentNo(String studentNo) {
		this.studentNo = studentNo;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public String getStudentAge() {
		return studentAge;
	}

	public void setStudentAge(String studentAge) {
		this.studentAge = studentAge;
	}

	public String getStudentQual() {
		return studentQual;
	}

	public void setStudentQual(String studentQual) {
		this.studentQual = studentQual;
	}

	public String getStudentMarks() {
		return studentMarks;
	}

	public void setStudentMarks(String studentMarks) {
		this.studentMarks = studentMarks;
	}

}
