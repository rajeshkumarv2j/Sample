package edu.dao;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import edu.model.Student;

/*
*
* @author Varma 
*
*/
public class StudentDao {
	public void insertStudent(Student studentRef) {
		// Jdbc Logic..
	}
}
