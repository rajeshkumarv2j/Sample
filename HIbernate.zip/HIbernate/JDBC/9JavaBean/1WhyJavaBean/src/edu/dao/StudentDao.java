package edu.dao;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

/*
*
* @author Varma 
*
*/
public class StudentDao {
	public void insertStudent(String studentNoRef, String studentNameRef,
			String studentAgeRef, String studentQualRef, String studentMarksRef) {
		// Jdbc Logic..
	}
}
