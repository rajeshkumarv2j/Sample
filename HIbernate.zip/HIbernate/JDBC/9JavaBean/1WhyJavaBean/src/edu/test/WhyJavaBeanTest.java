package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import edu.dao.StudentDao;

/*
*
* @author Varma 
*
*/
public class WhyJavaBeanTest {
	public static void main(String[] args) {
		String studentNo = new String("1");
		String studentName = new String("N@It");
		String studentAge = new String("8");
		String studentQual = new String("BCA");
		String studentMarks = new String("75");
		StudentDao studentDao = new StudentDao();
		studentDao.insertStudent(studentNo, studentName, studentAge,
				studentQual, studentMarks);
	}
	
}
