package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.io.IOException;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;

/*
*
* @author Varma 
*
*/
public class ReadXMLTest {
	private static Document document;
	static {
		SAXBuilder builder = new SAXBuilder(); // Properties
		try {
			document = builder.build(ReadXMLTest.class.getClassLoader()
					.getResourceAsStream("db-details.xml"));
			// properties.load();
		} catch (JDOMException e) {
		} catch (IOException e) {
		}
	}

	public static void main(String[] args) {
		String env = System.getenv("STU.ENV");
		Element element = document.getRootElement().getChild(env).getChild(
				"student1");
		String details = element.getAttributeValue("details");
		System.out.println(".details :" + details);
	}

}
