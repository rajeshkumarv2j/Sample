package edu.servlets;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import org.apache.commons.dbutils.DbUtils;

/*
*
* @author Varma 
*
*/
public class StudentServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Context context = null;
		DataSource dataSource = null;
		Connection connection = null;
		RequestDispatcher rd = null;
		try {
			context = new InitialContext();
			dataSource = (DataSource) context
					.lookup("java:comp/env/jdbc/nareshJNDI");
			connection = dataSource.getConnection();
			System.out.println(".dataSource." + dataSource);
			System.out.println(".Connection." + connection);
			rd = request.getRequestDispatcher("/WEB-INF/student/success.jsp");
			rd.forward(request, response);
		} catch (NamingException e) {
			System.err.println(e.getMessage());
			rd = request.getRequestDispatcher("/WEB-INF/student/failure.jsp");
			rd.forward(request, response);
		} catch (SQLException e) {
			System.err.println(e.getMessage());
			rd = request.getRequestDispatcher("/WEB-INF/student/failure.jsp");
			rd.forward(request, response);
		} finally {
			DbUtils.closeQuietly(connection);
		}
	}
}
