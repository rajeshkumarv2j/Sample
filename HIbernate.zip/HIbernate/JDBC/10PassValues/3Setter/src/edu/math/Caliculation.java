package edu.math;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

/*
*
* @author Varma 
*
*/
public class Caliculation {
	private int a;
	private int b;

	public void setA(int a) {
		this.a = a;
	}

	public void setB(int b) {
		this.b = b;
	}

	public void sum() {
		int sum = a + b;
		System.out.println(".sum :" + sum);
	}

	public void sub() {
		int sub = a - b;
		System.out.println(".sub :" + sub);
	}
}
