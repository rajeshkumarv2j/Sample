package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import edu.math.Caliculation;

/*
*
* @author Varma 
*
*/
public class SetterTest {
	public static void main(String[] args) {
		Caliculation caliculation = new Caliculation();
		caliculation.sum();
		caliculation.setA(4);
		caliculation.setB(4);
		caliculation.sum();
		caliculation.setA(12);
		caliculation.sub();
	}
}
