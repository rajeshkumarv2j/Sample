package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import edu.math.Caliculation;

/*
*
* @author Varma 
*
*/
public class ConstructorTest {
	public static void main(String[] args) {
		Caliculation caliculation = new Caliculation(4, 4);
		caliculation.sum();
		caliculation.sub();
	}
}
