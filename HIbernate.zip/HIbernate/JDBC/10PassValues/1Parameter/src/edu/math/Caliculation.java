package edu.math;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

/*
*
* @author Varma 
*
*/
public class Caliculation {
	public void sum(int a, int b) {
		int sum = a + b;
		System.out.println(".sum :" + sum);
	}

	public void sub(int a, int b) {
		int sub = a - b;
		System.out.println(".sub :" + sub);
	}
}
