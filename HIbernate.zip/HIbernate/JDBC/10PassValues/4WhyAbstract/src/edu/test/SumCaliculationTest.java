package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import edu.math.SumCaliculation;

/*
*
* @author Varma 
*
*/
public class SumCaliculationTest {
	public static void main(String[] args) {
		SumCaliculation sumCalc = new SumCaliculation();
		sumCalc.setA(4);
		sumCalc.setB(4);
		sumCalc.sum();
	}
}
