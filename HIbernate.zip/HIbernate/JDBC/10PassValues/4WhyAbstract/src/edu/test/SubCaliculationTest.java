package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import edu.math.SubCaliculation;

/*
*
* @author Varma 
*
*/
public class SubCaliculationTest {
	public static void main(String[] args) {
		SubCaliculation subCalc = new SubCaliculation();
		subCalc.setA(4);
		subCalc.setB(4);
		subCalc.sub();
	}
}
