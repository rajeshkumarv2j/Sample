package edu.math;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

/*
*
* @author Varma 
*
*/
public class SubCaliculation extends AbstractCaliculation {

	public void sub() {
		int sub = getA() - getB();
		System.out.println(".sub :" + sub);
	}
}
