package edu.math;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

/*
*
* @author Varma 
*
*/
public class SumCaliculation extends AbstractCaliculation {

	public void sum() {
		int sum = getA() + getB();
		System.out.println(".sum :" + sum);
	}
}
