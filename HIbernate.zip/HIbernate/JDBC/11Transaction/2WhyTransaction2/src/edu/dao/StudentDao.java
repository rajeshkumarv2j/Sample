package edu.dao;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.commons.dbutils.DbUtils;

import edu.exception.StudentException;
import edu.model.Student;
import edu.model.StudentXtra;
import edu.util.ResourceHelper;

/*
*
* @author Varma 
*
*/
public class StudentDao {
	private static String stuQuery = "INSERT INTO STUDENT VALUES(?,?)";
	private static String stuXtraQuery = "INSERT INTO STUDENTXTRA VALUES(?,?)";

	public void insert(Student student) {
		Connection connection = null;
		try {
			connection = ResourceHelper.getConnection();
			connection.setAutoCommit(false);
			insertStudent(student, connection);
			System.out.println(".Break Point.");
			insertStudentXtra(student.getStudentXtra(), connection);
			connection.commit();
		} catch (SQLException e) {
			System.err.println(".SQLException." + e);
			DbUtils.rollbackAndCloseQuietly(connection);
		} catch (StudentException e) {
			System.err.println(".StudentException." + e);
			DbUtils.rollbackAndCloseQuietly(connection);
		} finally {
			DbUtils.closeQuietly(connection);
		}
	}

	public void insertStudent(Student student, Connection connection)
			throws StudentException {
		PreparedStatement ps = null;
		try {
			ps = connection.prepareStatement(stuQuery);
			ps.setLong(1, student.getStudentNo());
			ps.setString(2, student.getStudentName());
			ps.executeUpdate();
		} catch (SQLException e) {
			System.err.println(".SQLException." + e);
			throw new StudentException(e.getMessage());
		} finally {
			DbUtils.closeQuietly(ps);
		}
	}

	public void insertStudentXtra(StudentXtra studentXtra, Connection connection)
			throws StudentException {
		PreparedStatement ps = null;
		try {
			ps = connection.prepareStatement(stuXtraQuery);
			ps.setLong(1, studentXtra.getStudentNo());
			ps.setString(2, studentXtra.getStudentAge());
			ps.executeUpdate();
		} catch (SQLException e) {
			System.err.println(".SQLException." + e);
			throw new StudentException(e.getMessage());
		} finally {
			DbUtils.closeQuietly(ps);
		}
	}
}
