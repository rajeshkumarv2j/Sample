package edu.exception;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

/*
*
* @author Varma 
*
*/
public class StudentException extends Exception {
	private static final long serialVersionUID = 1L;
	String exceptionMessage = "";

	public StudentException() {
		super();
	}

	public StudentException(String exceptionMessage) {
		super(exceptionMessage);
		this.exceptionMessage = exceptionMessage;
	}

	public String toString() {
		return exceptionMessage;
	}
}
