package edu.dao;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.commons.dbutils.DbUtils;

import edu.model.Student;

/*
*
* @author Varma 
*
*/
public class StudentDao {
	private static String stuQuery = "INSERT INTO STUDENT VALUES(?,?)";
	private Connection connection;

	public StudentDao(Connection connection) {
		this.connection = connection;
	}

	public void insertStudent(Student student) {
		PreparedStatement ps = null;
		try {
			ps = connection.prepareStatement(stuQuery);
			ps.setLong(1, student.getStudentNo());
			ps.setString(2, student.getStudentName());
			ps.executeUpdate();
		} catch (SQLException e) {
			System.err.println(".SQLException." + e);
		} finally {
			DbUtils.closeQuietly(ps);
		}
	}

}
