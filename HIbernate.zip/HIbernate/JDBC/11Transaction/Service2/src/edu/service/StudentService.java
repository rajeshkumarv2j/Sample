package edu.service;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.commons.dbutils.DbUtils;

import edu.dao.StudentDao;
import edu.model.Student;
import edu.util.ResourceHelper;

/*
*
* @author Varma 
*
*/
public class StudentService {
	public void insertStudent(Student student) {
		Connection connection = null;
		try {
			connection = ResourceHelper.getConnection();
			connection.setAutoCommit(false);
			StudentDao studentDao = new StudentDao(connection);
			studentDao.insertStudent(student);
			// If there is a different db connection, then again need to
			// create StudentDao object and has to pass the connection to
			// StudentDao Constructor
			// StudentDao studentDao = new StudentDao(connection);
			connection.commit();
		} catch (SQLException e) {
			System.err.println(".SQLException." + e);
			DbUtils.rollbackAndCloseQuietly(connection);
		} finally {
			DbUtils.closeQuietly(connection);
		}
	}
}
