package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import edu.dao.StudentDao;
import edu.model.Student;
import edu.model.StudentXtra;

/*
*
* @author Varma 
*
*/
public class WhyTransactionTest {

	public static void main(String[] args) {
		// Set StudentXtra
		StudentXtra studentXtra = new StudentXtra();
		studentXtra.setStudentNo(new Long(2));
		studentXtra.setStudentAge("7");
		// Set Student
		Student student = new Student();
		student.setStudentNo(studentXtra.getStudentNo());
		student.setStudentName("N@It");
		student.setStudentXtra(studentXtra);
		StudentDao studentDao = new StudentDao();
		studentDao.insert(student);
		System.out.println(".SUCCESS.");
	}
}
