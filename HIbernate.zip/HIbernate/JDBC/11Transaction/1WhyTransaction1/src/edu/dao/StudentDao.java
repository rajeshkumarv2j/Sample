package edu.dao;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.commons.dbutils.DbUtils;

import edu.model.Student;
import edu.model.StudentXtra;
import edu.util.ResourceHelper;

/*
*
* @author Varma 
*
*/
public class StudentDao {
	private static String stuQuery = "INSERT INTO STUDENT VALUES(?,?)";
	private static String stuXtraQuery = "INSERT INTO STUDENTXTRA VALUES(?,?)";

	public void insert(Student student) {
		insertStudent(student);
		System.out.println(".Break Point.");
		insertStudentXtra(student.getStudentXtra());
	}

	public void insertStudent(Student student) {
		Connection connection = ResourceHelper.getConnection();
		PreparedStatement ps = null;
		try {
			ps = connection.prepareStatement(stuQuery);
			ps.setLong(1, student.getStudentNo());
			ps.setString(2, student.getStudentName());
			ps.executeUpdate();
		} catch (SQLException e) {
			System.err.println(".SQLException." + e);
		} finally {
			DbUtils.closeQuietly(connection,ps,null);
		}
	}

	public void insertStudentXtra(StudentXtra studentXtra) {
		Connection connection = ResourceHelper.getConnection();
		PreparedStatement ps = null;
		try {
			ps = connection.prepareStatement(stuXtraQuery);
			ps.setLong(1, studentXtra.getStudentNo());
			ps.setString(2, studentXtra.getStudentAge());
			ps.executeUpdate();
		} catch (SQLException e) {
			System.err.println(".SQLException." + e);
		} finally {
			DbUtils.closeQuietly(connection,ps,null);
		}
	}
}
