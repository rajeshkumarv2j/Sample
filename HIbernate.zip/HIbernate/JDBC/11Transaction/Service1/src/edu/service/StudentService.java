package edu.service;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.commons.dbutils.DbUtils;

import edu.dao.StudentDao;
import edu.model.Student;
import edu.util.ResourceHelper;

/*
*
* @author Varma 
*
*/
public class StudentService {
	public void insertStudent(Student student) {
		Connection connection = null;
		try {
			connection = ResourceHelper.getConnection();
			connection.setAutoCommit(false);
			StudentDao studentDao = new StudentDao();
			studentDao.insertStudent(student, connection);
			connection.commit();
		} catch (SQLException e) {
			System.err.println(".SQLException." + e);
			DbUtils.rollbackAndCloseQuietly(connection);
		} finally {
			DbUtils.closeQuietly(connection);
		}
	}
}
