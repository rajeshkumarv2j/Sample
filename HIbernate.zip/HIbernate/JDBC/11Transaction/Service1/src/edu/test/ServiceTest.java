package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import edu.model.Student;
import edu.service.StudentService;

/*
*
* @author Varma 
*
*/
public class ServiceTest {

	public static void main(String[] args) {
		Student student = new Student();
		student.setStudentNo(new Long(1));
		student.setStudentName("N@It");
		StudentService studentService = new StudentService();
		studentService.insertStudent(student);
		System.out.println(".SUCCESS.");
	}
}
