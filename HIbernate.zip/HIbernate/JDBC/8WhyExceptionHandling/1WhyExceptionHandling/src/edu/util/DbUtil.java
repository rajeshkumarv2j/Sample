package edu.util;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/*
*
* @author Varma 
*
*/
public class DbUtil {
	private static Properties properties = new Properties();
	static {
		try {
			properties.load(DbUtil.class.getClassLoader().getResourceAsStream(
					"DBUtil.properties"));
		} catch (IOException e) {
			System.err.println(".SQLException." + e);
		}
	}

	public static Connection getConnection() {
		Connection connection = null;
		try {
			Class.forName(properties.getProperty("driverClass"));
			connection = DriverManager.getConnection(properties
					.getProperty("url"), properties.getProperty("userName"),
					properties.getProperty("password"));
		} catch (ClassNotFoundException e) {
			System.err.println(".ClassNotFoundException." + e);
		} catch (SQLException e) {
			System.err.println(".SQLException." + e);
		}
		return connection;
	}
}
