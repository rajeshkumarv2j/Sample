package edu.dao;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.commons.dbutils.DbUtils;

import edu.util.DbUtil;

/*
*
* @author Varma 
*
*/
public class StudentDao {
	private static String query = "INSERT INTO STUDENT_TEST VALUES(?,?)";

	public void insertStudent(String studentNo, String studentName) {
		Connection connection = null;
		PreparedStatement ps = null;
		try {
			connection = DbUtil.getConnection();
			ps = connection.prepareStatement(query);
			ps.setString(1, studentNo);
			ps.setString(2, studentName);
			ps.executeUpdate();
		} catch (SQLException e) {
			System.err.println(".SQLException." + e);
		} finally {
			DbUtils.closeQuietly(connection, ps, null);
		}
	}
}
