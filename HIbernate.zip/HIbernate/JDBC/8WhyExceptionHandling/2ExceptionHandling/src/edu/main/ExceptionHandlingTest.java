package edu.main;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import edu.dao.StudentDao;
import edu.exceptions.StudentException;

//It's like StudentServer
/*
*
* @author Varma 
*
*/
public class ExceptionHandlingTest {
	// It's like service/doGet/doPost
	public static void main(String[] args) {
		StudentDao studentDao = new StudentDao();
		try {
			studentDao.insertStudent("1", "N@It");
			System.out.println("Forward - To ->.SUCCESS.");
		} catch (StudentException e) {
			System.err.println("Forward - To ->.FAILURE.");
		}

	}
}
