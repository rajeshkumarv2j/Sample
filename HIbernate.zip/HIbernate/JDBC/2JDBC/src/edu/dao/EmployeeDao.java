package edu.dao;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/*
*
* @author Varma 
*
*/
public class EmployeeDao {
	public void insertEmployee(String employeeNo, String employeeName) {
		String query = "INSERT INTO EMPLOYEE VALUES(?,?)";
		Connection connection = null;
		PreparedStatement ps = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection(
					"jdbc:oracle:thin:@localhost:1521:XE", "SYSTEM", "MANAGER");
			ps = connection.prepareStatement(query);
			ps.setString(1, employeeNo);
			ps.setString(2, employeeName);
			ps.executeUpdate();
			System.out.println(".SUCCESS.");
		} catch (ClassNotFoundException e) {
			System.err.println(".ClassNotFoundException." + e);
		} catch (SQLException e) {
			System.err.println(".SQLException." + e);
		} finally {
			try {
				if (connection != null) {
					connection.close();
				}
				if (ps != null) {
					ps.close();
				}
			} catch (SQLException e) {
				System.err.println(".SQLException." + e);
			}
		}

	}
}
