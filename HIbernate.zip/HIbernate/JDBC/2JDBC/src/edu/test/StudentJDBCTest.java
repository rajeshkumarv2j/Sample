package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/*
*
* @author Varma 
*
*/
public class StudentJDBCTest {
	public static void main(String[] args) {
		String query = "INSERT INTO STUDENT VALUES(?,?)";
		Connection connection = null;
		PreparedStatement ps = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection(
					"jdbc:oracle:thin:@localhost:1521:XE", "SYSTEM", "MANAGER");
			ps = connection.prepareStatement(query);
			ps.setLong(1, new Long(1));
			ps.setString(2, "N@It");
			ps.executeUpdate();
			System.out.println(".SUCCESS.");
		} catch (ClassNotFoundException e) {
			System.err.println(".ClassNotFoundException." + e);
		} catch (SQLException e) {
			System.err.println(".SQLException." + e);
		} finally {
			try {
				if (connection != null) {
					connection.close();
				}
				if (ps != null) {
					ps.close();
				}
			} catch (SQLException e) {
				System.err.println(".SQLException." + e);
			}
		}

	}
}
