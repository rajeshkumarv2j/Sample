package edu.util;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

/*
*
* @author Varma 
*
*/
public class ConnectionUtil {
	private static Properties properties = new Properties();
	static {
		try {
			properties.load(ConnectionUtil.class.getClassLoader()
					.getResourceAsStream("db-config.properties"));
		} catch (IOException e) {
			System.err.println(".SQLException." + e);
		}
	}

	public static Connection getConnection() {
		Connection connection = null;
		try {
			Class.forName(properties.getProperty("driverClass"));
			connection = DriverManager.getConnection(properties
					.getProperty("url"), properties.getProperty("userName"),
					properties.getProperty("password"));
		} catch (ClassNotFoundException e) {
			System.err.println(".ClassNotFoundException." + e);
		} catch (SQLException e) {
			System.err.println(".SQLException." + e);
		}
		return connection;
	}

	public static void closeQuietly(Connection conn) {
		try {
			if (conn != null)
				conn.close();
		} catch (SQLException e) {
			System.err.println(".SQLException." + e);
		}
	}

	public static void closeQuietly(Statement stmt) {
		try {
			if (stmt != null)
				stmt.close();
		} catch (SQLException e) {
			System.err.println(".SQLException." + e);
		}
	}

	public static void closeQuietly(ResultSet rs) {
		try {
			if (rs != null)
				rs.close();
		} catch (SQLException e) {
			System.err.println(".SQLException." + e);
		}
	}
}
