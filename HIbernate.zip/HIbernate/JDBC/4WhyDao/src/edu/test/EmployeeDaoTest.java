package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import edu.dao.EmployeeDao;

/*
*
* @author Varma 
*
*/
public class EmployeeDaoTest {
	public static void main(String[] args) {
		EmployeeDao employeeDao = new EmployeeDao();
		employeeDao.insertEmployee(new Long(1), "N@It");
		System.out.println(".SUCCESS.");
	}
}
