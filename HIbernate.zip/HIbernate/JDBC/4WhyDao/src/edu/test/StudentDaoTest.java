package edu.test;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import edu.dao.StudentDao;

/*
*
* @author Varma 
*
*/
public class StudentDaoTest {

	public static void main(String[] args) {
		StudentDao studentDao = new StudentDao();
		studentDao.insertStudent(new Long(1), "N@It");
		System.out.println(".SUCCESS.");
	}

}
