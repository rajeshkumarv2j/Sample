package edu.dao;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import edu.util.ConnectionUtil;

/*
*
* @author Varma 
*
*/
public class EmployeeDao {
	private static String query = "INSERT INTO EMPLOYEE VALUES(?,?)";

	public void insertEmployee(Long employeeNo, String employeeName) {
		Connection connection = null;
		PreparedStatement ps = null;
		try {
			connection = ConnectionUtil.getConnection();
			ps = connection.prepareStatement(query);
			ps.setLong(1, employeeNo);
			ps.setString(2, employeeName);
			ps.executeUpdate();
		} catch (SQLException e) {
			System.err.println(".SQLException." + e);
		} finally {
			ConnectionUtil.closeQuietly(connection);
			ConnectionUtil.closeQuietly(ps);
		}
	}
}
