package edu.dao;
/*
* COPYRIGHT NOTICE 
* Copyright@2010 by Varma. All rights reserved.
*/

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import edu.util.ConnectionUtil;

/*
*
* @author Varma 
*
*/
public class StudentDao {
	private static String query = "INSERT INTO STUDENT VALUES(?,?)";

	public void insertStudent(Long studentNo, String studentName) {
		Connection connection = null;
		PreparedStatement ps = null;
		try {
			connection = ConnectionUtil.getConnection();
			ps = connection.prepareStatement(query);
			ps.setLong(1, studentNo);
			ps.setString(2, studentName);
			ps.executeUpdate();
		} catch (SQLException e) {
			System.err.println(".SQLException." + e);
		} finally {
			ConnectionUtil.closeQuietly(connection);
			ConnectionUtil.closeQuietly(ps);
		}
	}
}
